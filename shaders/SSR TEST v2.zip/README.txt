Welcome to this shader.
The shader is open source, allowed to be reworked or added to new works.

It can run on vgpu 1.3.4-1.4, zink, PC.

It contains two main effects: shadow and water.
By default, shadows use multisampling (3 times) soft shadows.
Water effects include simple 3D screen space reflections, fake sky reflections, simple noise waves (you can add custom more complex noise to achieve more realistic waves).

Not Added Bloom.