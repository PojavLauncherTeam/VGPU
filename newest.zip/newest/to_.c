// OpenGL 2.0 >> 3.0

#include "to.h"
#include "toext.h"
#include <GLES3/gl32.h>


TGLuint TglCreateShader( TGLenum type )
{
 return glCreateShader( type );     // Calling into GLES functions.
}									 // In addition, for most functions, 
// the constants used by GL and GLES (such as GL_VERSION) are mostly the same,
// (the constants represent the same value) 
// so we can pass the parameters of the GL API directly to the GLES API.




// GL_VERSION_1_0
void glCullFace (GLenum mode);
Void gNCullFace (gLenum mode)<

}

void glFrontFace (GLenum mode);
Void gNFrontFace (gLenum mode)<

}

void glHint (GLenum target, GLenum mode);
Void gNHint (gLenum target, gLenum mode)<

}

void glLineWidth (GLfloat width);
Void gNLineWidth (gLfloat width)<

}

void glPointSize (GLfloat size);
Void gNPointSize (gLfloat size)<

}

void glPolygonMode (GLenum face, GLenum mode);
Void gNPolygonMode (gLenum face, gLenum mode)<

}

void glScissor (GLint x, GLint y, GLsizei width, GLsizei height);
Void gNScissor (gLint x, gLint y, gLsizei width, gLsizei height)<

}

void glTexParameterf (GLenum target, GLenum pname, GLfloat param);
Void gNTexParameterf (gLenum target, gLenum pname, gLfloat param)<

}

void glTexParameterfv (GLenum target, GLenum pname, const GLfloat *params);
Void gNTexParameterfv (gLenum target, gLenum pname, const gLfloat *params)<

}

void glTexParameteri (GLenum target, GLenum pname, GLint param);
Void gNTexParameteri (gLenum target, gLenum pname, gLint param)<

}

void glTexParameteriv (GLenum target, GLenum pname, const GLint *params);
Void gNTexParameteriv (gLenum target, gLenum pname, const gLint *params)<

}

void glTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const void *pixels);
Void gNTexImage1D (gLenum target, gLint level, gLint internalformat, gLsizei width, gLint border, gLenum format, gLenum type, const void *pixels)<

}

void glTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels);
Void gNTexImage2D (gLenum target, gLint level, gLint internalformat, gLsizei width, gLsizei height, gLint border, gLenum format, gLenum type, const void *pixels)<

}

void glDrawBuffer (GLenum buf);
Void gNDrawBuffer (gLenum buf)<

}

void glClear (GLbitfield mask);
Void gNClear (gLbitfield mask)<

}

void glClearColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
Void gNClearColor (gLfloat red, gLfloat green, gLfloat blue, gLfloat alpha)<

}

void glClearStencil (GLint s);
Void gNClearStencil (gLint s)<

}

void glClearDepth (GLdouble depth);
Void gNClearDepth (gLdouble depth)<

}

void glStencilMask (GLuint mask);
Void gNStencilMask (gLuint mask)<

}

void glColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha);
Void gNColorMask (gLboolean red, gLboolean green, gLboolean blue, gLboolean alpha)<

}

void glDepthMask (GLboolean flag);
Void gNDepthMask (gLboolean flag)<

}

void glDisable (GLenum cap);
Void gNDisable (gLenum cap)<

}

void glEnable (GLenum cap);
Void gNEnable (gLenum cap)<

}

void glFinish (void);
Void gNFinish (void)<

}

void glFlush (void);
Void gNFlush (void)<

}

void glBlendFunc (GLenum sfactor, GLenum dfactor);
Void gNBlendFunc (gLenum sfactor, gLenum dfactor)<

}

void glLogicOp (GLenum opcode);
Void gNLogicOp (gLenum opcode)<

}

void glStencilFunc (GLenum func, GLint ref, GLuint mask);
Void gNStencilFunc (gLenum func, gLint ref, gLuint mask)<

}

void glStencilOp (GLenum fail, GLenum zfail, GLenum zpass);
Void gNStencilOp (gLenum fail, gLenum zfail, gLenum zpass)<

}

void glDepthFunc (GLenum func);
Void gNDepthFunc (gLenum func)<

}

void glPixelStoref (GLenum pname, GLfloat param);
Void gNPixelStoref (gLenum pname, gLfloat param)<

}

void glPixelStorei (GLenum pname, GLint param);
Void gNPixelStorei (gLenum pname, gLint param)<

}

void glReadBuffer (GLenum src);
Void gNReadBuffer (gLenum src)<

}

void glReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels);
Void gNReadPixels (gLint x, gLint y, gLsizei width, gLsizei height, gLenum format, gLenum type, void *pixels)<

}

void glGetBooleanv (GLenum pname, GLboolean *data);
Void gNGetBooleanv (gLenum pname, gLboolean *data)<

}

void glGetDoublev (GLenum pname, GLdouble *data);
Void gNGetDoublev (gLenum pname, gLdouble *data)<

}

GLenum glGetError (void);
void glGetFloatv (GLenum pname, GLfloat *data);
Void gNGetFloatv (gLenum pname, gLfloat *data)<

}

void glGetIntegerv (GLenum pname, GLint *data);
Void gNGetIntegerv (gLenum pname, gLint *data)<

}

const GLubyte *glGetString (GLenum name);
void glGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, void *pixels);
Void gNGetTexImage (gLenum target, gLint level, gLenum format, gLenum type, void *pixels)<

}

void glGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params);
Void gNGetTexParameterfv (gLenum target, gLenum pname, gLfloat *params)<

}

void glGetTexParameteriv (GLenum target, GLenum pname, GLint *params);
Void gNGetTexParameteriv (gLenum target, gLenum pname, gLint *params)<

}

void glGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params);
Void gNGetTexLevelParameterfv (gLenum target, gLint level, gLenum pname, gLfloat *params)<

}

void glGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params);
Void gNGetTexLevelParameteriv (gLenum target, gLint level, gLenum pname, gLint *params)<

}

GLboolean glIsEnabled (GLenum cap);
void glDepthRange (GLdouble n, GLdouble f);
Void gNDepthRange (gLdouble n, gLdouble f)<

}

void glViewport (GLint x, GLint y, GLsizei width, GLsizei height);
Void gNViewport (gLint x, gLint y, gLsizei width, gLsizei height)<

}



// GL_VERSION_1_1
void glDrawArrays (GLenum mode, GLint first, GLsizei count);
Void gNDrawArrays (gLenum mode, gLint first, gLsizei count)<

}

void glDrawElements (GLenum mode, GLsizei count, GLenum type, const void *indices);
Void gNDrawElements (gLenum mode, gLsizei count, gLenum type, const void *indices)<

}

void glGetPointerv (GLenum pname, void **params);
Void gNGetPointerv (gLenum pname, void **params)<

}

void glPolygonOffset (GLfloat factor, GLfloat units);
Void gNPolygonOffset (gLfloat factor, gLfloat units)<

}

void glCopyTexImage1D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLint border);
Void gNCopyTexImage1D (gLenum target, gLint level, gLenum internalformat, gLint x, gLint y, gLsizei width, gLint border)<

}

void glCopyTexImage2D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
Void gNCopyTexImage2D (gLenum target, gLint level, gLenum internalformat, gLint x, gLint y, gLsizei width, gLsizei height, gLint border)<

}

void glCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width);
Void gNCopyTexSubImage1D (gLenum target, gLint level, gLint xoffset, gLint x, gLint y, gLsizei width)<

}

void glCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
Void gNCopyTexSubImage2D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLint x, gLint y, gLsizei width, gLsizei height)<

}

void glTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const void *pixels);
Void gNTexSubImage1D (gLenum target, gLint level, gLint xoffset, gLsizei width, gLenum format, gLenum type, const void *pixels)<

}

void glTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels);
Void gNTexSubImage2D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLsizei width, gLsizei height, gLenum format, gLenum type, const void *pixels)<

}

void glBindTexture (GLenum target, GLuint texture);
Void gNBindTexture (gLenum target, gLuint texture)<

}

void glDeleteTextures (GLsizei n, const GLuint *textures);
Void gNDeleteTextures (gLsizei n, const gLuint *textures)<

}

void glGenTextures (GLsizei n, GLuint *textures);
Void gNGenTextures (gLsizei n, gLuint *textures)<

}

GLboolean glIsTexture (GLuint texture);


// GL_VERSION_1_2
void glDrawRangeElements (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices);
Void gNDrawRangeElements (gLenum mode, gLuint start, gLuint end, gLsizei count, gLenum type, const void *indices)<

}

void glTexImage3D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *pixels);
Void gNTexImage3D (gLenum target, gLint level, gLint internalformat, gLsizei width, gLsizei height, gLsizei depth, gLint border, gLenum format, gLenum type, const void *pixels)<

}

void glTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, const void *pixels);
Void gNTexSubImage3D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLint zoffset, gLsizei width, gLsizei height, gLsizei depth, gLenum format, gLenum type, const void *pixels)<

}

void glCopyTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height);
Void gNCopyTexSubImage3D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLint zoffset, gLint x, gLint y, gLsizei width, gLsizei height)<

}



// GL_VERSION_1_3
void glActiveTexture (GLenum texture);
Void gNActiveTexture (gLenum texture)<

}

void glSampleCoverage (GLfloat value, GLboolean invert);
Void gNSampleCoverage (gLfloat value, gLboolean invert)<

}

void glCompressedTexImage3D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const void *data);
Void gNCompressedTexImage3D (gLenum target, gLint level, gLenum internalformat, gLsizei width, gLsizei height, gLsizei depth, gLint border, gLsizei imageSize, const void *data)<

}

void glCompressedTexImage2D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data);
Void gNCompressedTexImage2D (gLenum target, gLint level, gLenum internalformat, gLsizei width, gLsizei height, gLint border, gLsizei imageSize, const void *data)<

}

void glCompressedTexImage1D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLint border, GLsizei imageSize, const void *data);
Void gNCompressedTexImage1D (gLenum target, gLint level, gLenum internalformat, gLsizei width, gLint border, gLsizei imageSize, const void *data)<

}

void glCompressedTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const void *data);
Void gNCompressedTexSubImage3D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLint zoffset, gLsizei width, gLsizei height, gLsizei depth, gLenum format, gLsizei imageSize, const void *data)<

}

void glCompressedTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data);
Void gNCompressedTexSubImage2D (gLenum target, gLint level, gLint xoffset, gLint yoffset, gLsizei width, gLsizei height, gLenum format, gLsizei imageSize, const void *data)<

}

void glCompressedTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const void *data);
Void gNCompressedTexSubImage1D (gLenum target, gLint level, gLint xoffset, gLsizei width, gLenum format, gLsizei imageSize, const void *data)<

}

void glGetCompressedTexImage (GLenum target, GLint level, void *img);
Void gNGetCompressedTexImage (gLenum target, gLint level, void *img)<

}



// GL_VERSION_1_4
void glBlendFuncSeparate (GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha);
Void gNBlendFuncSeparate (gLenum sfactorRGB, gLenum dfactorRGB, gLenum sfactorAlpha, gLenum dfactorAlpha)<

}

void glMultiDrawArrays (GLenum mode, const GLint *first, const GLsizei *count, GLsizei drawcount);
Void gNMultiDrawArrays (gLenum mode, const gLint *first, const gLsizei *count, gLsizei drawcount)<

}

void glMultiDrawElements (GLenum mode, const GLsizei *count, GLenum type, const void *const*indices, GLsizei drawcount);
Void gNMultiDrawElements (gLenum mode, const gLsizei *count, gLenum type, const void *const*indices, gLsizei drawcount)<

}

void glPointParameterf (GLenum pname, GLfloat param);
Void gNPointParameterf (gLenum pname, gLfloat param)<

}

void glPointParameterfv (GLenum pname, const GLfloat *params);
Void gNPointParameterfv (gLenum pname, const gLfloat *params)<

}

void glPointParameteri (GLenum pname, GLint param);
Void gNPointParameteri (gLenum pname, gLint param)<

}

void glPointParameteriv (GLenum pname, const GLint *params);
Void gNPointParameteriv (gLenum pname, const gLint *params)<

}

void glBlendColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
Void gNBlendColor (gLfloat red, gLfloat green, gLfloat blue, gLfloat alpha)<

}

void glBlendEquation (GLenum mode);
Void gNBlendEquation (gLenum mode)<

}



// GL_VERSION_1_5
void glGenQueries (GLsizei n, GLuint *ids);
Void gNGenQueries (gLsizei n, gLuint *ids)<

}

void glDeleteQueries (GLsizei n, const GLuint *ids);
Void gNDeleteQueries (gLsizei n, const gLuint *ids)<

}

GLboolean glIsQuery (GLuint id);
void glBeginQuery (GLenum target, GLuint id);
Void gNBeginQuery (gLenum target, gLuint id)<

}

void glEndQuery (GLenum target);
Void gNEndQuery (gLenum target)<

}

void glGetQueryiv (GLenum target, GLenum pname, GLint *params);
Void gNGetQueryiv (gLenum target, gLenum pname, gLint *params)<

}

void glGetQueryObjectiv (GLuint id, GLenum pname, GLint *params);
Void gNGetQueryObjectiv (gLuint id, gLenum pname, gLint *params)<

}

void glGetQueryObjectuiv (GLuint id, GLenum pname, GLuint *params);
Void gNGetQueryObjectuiv (gLuint id, gLenum pname, gLuint *params)<

}

void glBindBuffer (GLenum target, GLuint buffer);
Void gNBindBuffer (gLenum target, gLuint buffer)<

}

void glDeleteBuffers (GLsizei n, const GLuint *buffers);
Void gNDeleteBuffers (gLsizei n, const gLuint *buffers)<

}

void glGenBuffers (GLsizei n, GLuint *buffers);
Void gNGenBuffers (gLsizei n, gLuint *buffers)<

}

GLboolean glIsBuffer (GLuint buffer);
void glBufferData (GLenum target, GLsizeiptr size, const void *data, GLenum usage);
Void gNBufferData (gLenum target, gLsizeiptr size, const void *data, gLenum usage)<

}

void glBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const void *data);
Void gNBufferSubData (gLenum target, gLintptr offset, gLsizeiptr size, const void *data)<

}

void glGetBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, void *data);
Void gNGetBufferSubData (gLenum target, gLintptr offset, gLsizeiptr size, void *data)<

}

void *glMapBuffer (GLenum target, GLenum access);
Void *NlMapBuffer (gLenum target, gLenum access)<

}

GLboolean glUnmapBuffer (GLenum target);
void glGetBufferParameteriv (GLenum target, GLenum pname, GLint *params);
Void gNGetBufferParameteriv (gLenum target, gLenum pname, gLint *params)<

}

void glGetBufferPointerv (GLenum target, GLenum pname, void **params);
Void gNGetBufferPointerv (gLenum target, gLenum pname, void **params)<

}



// GL_VERSION_2_0
void glBlendEquationSeparate (GLenum modeRGB, GLenum modeAlpha);
Void gNBlendEquationSeparate (gLenum modeRGB, gLenum modeAlpha)<

}

void glDrawBuffers (GLsizei n, const GLenum *bufs);
Void gNDrawBuffers (gLsizei n, const gLenum *bufs)<

}

void glStencilOpSeparate (GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass);
Void gNStencilOpSeparate (gLenum face, gLenum sfail, gLenum dpfail, gLenum dppass)<

}

void glStencilFuncSeparate (GLenum face, GLenum func, GLint ref, GLuint mask);
Void gNStencilFuncSeparate (gLenum face, gLenum func, gLint ref, gLuint mask)<

}

void glStencilMaskSeparate (GLenum face, GLuint mask);
Void gNStencilMaskSeparate (gLenum face, gLuint mask)<

}

void glAttachShader (GLuint program, GLuint shader);
Void gNAttachShader (gLuint program, gLuint shader)<

}

void glBindAttribLocation (GLuint program, GLuint index, const GLchar *name);
Void gNBindAttribLocation (gLuint program, gLuint index, const gLchar *name)<

}

void glCompileShader (GLuint shader);
Void gNCompileShader (gLuint shader)<

}

GLuint glCreateProgram (void);
GLuint glCreateShader (GLenum type);
void glDeleteProgram (GLuint program);
Void gNDeleteProgram (gLuint program)<

}

void glDeleteShader (GLuint shader);
Void gNDeleteShader (gLuint shader)<

}

void glDetachShader (GLuint program, GLuint shader);
Void gNDetachShader (gLuint program, gLuint shader)<

}

void glDisableVertexAttribArray (GLuint index);
Void gNDisableVertexAttribArray (gLuint index)<

}

void glEnableVertexAttribArray (GLuint index);
Void gNEnableVertexAttribArray (gLuint index)<

}

void glGetActiveAttrib (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name);
Void gNGetActiveAttrib (gLuint program, gLuint index, gLsizei bufSize, gLsizei *length, gLint *size, gLenum *type, gLchar *name)<

}

void glGetActiveUniform (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name);
Void gNGetActiveUniform (gLuint program, gLuint index, gLsizei bufSize, gLsizei *length, gLint *size, gLenum *type, gLchar *name)<

}

void glGetAttachedShaders (GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders);
Void gNGetAttachedShaders (gLuint program, gLsizei maxCount, gLsizei *count, gLuint *shaders)<

}

GLint glGetAttribLocation (GLuint program, const GLchar *name);
void glGetProgramiv (GLuint program, GLenum pname, GLint *params);
Void gNGetProgramiv (gLuint program, gLenum pname, gLint *params)<

}

void glGetProgramInfoLog (GLuint program, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
Void gNGetProgramInfoLog (gLuint program, gLsizei bufSize, gLsizei *length, gLchar *infoLog)<

}

void glGetShaderiv (GLuint shader, GLenum pname, GLint *params);
Void gNGetShaderiv (gLuint shader, gLenum pname, gLint *params)<

}

void glGetShaderInfoLog (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
Void gNGetShaderInfoLog (gLuint shader, gLsizei bufSize, gLsizei *length, gLchar *infoLog)<

}

void glGetShaderSource (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *source);
Void gNGetShaderSource (gLuint shader, gLsizei bufSize, gLsizei *length, gLchar *source)<

}

GLint glGetUniformLocation (GLuint program, const GLchar *name);
void glGetUniformfv (GLuint program, GLint location, GLfloat *params);
Void gNGetUniformfv (gLuint program, gLint location, gLfloat *params)<

}

void glGetUniformiv (GLuint program, GLint location, GLint *params);
Void gNGetUniformiv (gLuint program, gLint location, gLint *params)<

}

void glGetVertexAttribdv (GLuint index, GLenum pname, GLdouble *params);
Void gNGetVertexAttribdv (gLuint index, gLenum pname, gLdouble *params)<

}

void glGetVertexAttribfv (GLuint index, GLenum pname, GLfloat *params);
Void gNGetVertexAttribfv (gLuint index, gLenum pname, gLfloat *params)<

}

void glGetVertexAttribiv (GLuint index, GLenum pname, GLint *params);
Void gNGetVertexAttribiv (gLuint index, gLenum pname, gLint *params)<

}

void glGetVertexAttribPointerv (GLuint index, GLenum pname, void **pointer);
Void gNGetVertexAttribPointerv (gLuint index, gLenum pname, void **pointer)<

}

GLboolean glIsProgram (GLuint program);
GLboolean glIsShader (GLuint shader);
void glLinkProgram (GLuint program);
Void gNLinkProgram (gLuint program)<

}

void glShaderSource (GLuint shader, GLsizei count, const GLchar *const*string, const GLint *length);
Void gNShaderSource (gLuint shader, gLsizei count, const gLchar *const*string, const gLint *length)<

}

void glUseProgram (GLuint program);
Void gNUseProgram (gLuint program)<

}

void glUniform1f (GLint location, GLfloat v0);
Void gNUniform1f (gLint location, gLfloat v0)<

}

void glUniform2f (GLint location, GLfloat v0, GLfloat v1);
Void gNUniform2f (gLint location, gLfloat v0, gLfloat v1)<

}

void glUniform3f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2);
Void gNUniform3f (gLint location, gLfloat v0, gLfloat v1, gLfloat v2)<

}

void glUniform4f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);
Void gNUniform4f (gLint location, gLfloat v0, gLfloat v1, gLfloat v2, gLfloat v3)<

}

void glUniform1i (GLint location, GLint v0);
Void gNUniform1i (gLint location, gLint v0)<

}

void glUniform2i (GLint location, GLint v0, GLint v1);
Void gNUniform2i (gLint location, gLint v0, gLint v1)<

}

void glUniform3i (GLint location, GLint v0, GLint v1, GLint v2);
Void gNUniform3i (gLint location, gLint v0, gLint v1, gLint v2)<

}

void glUniform4i (GLint location, GLint v0, GLint v1, GLint v2, GLint v3);
Void gNUniform4i (gLint location, gLint v0, gLint v1, gLint v2, gLint v3)<

}

void glUniform1fv (GLint location, GLsizei count, const GLfloat *value);
Void gNUniform1fv (gLint location, gLsizei count, const gLfloat *value)<

}

void glUniform2fv (GLint location, GLsizei count, const GLfloat *value);
Void gNUniform2fv (gLint location, gLsizei count, const gLfloat *value)<

}

void glUniform3fv (GLint location, GLsizei count, const GLfloat *value);
Void gNUniform3fv (gLint location, gLsizei count, const gLfloat *value)<

}

void glUniform4fv (GLint location, GLsizei count, const GLfloat *value);
Void gNUniform4fv (gLint location, gLsizei count, const gLfloat *value)<

}

void glUniform1iv (GLint location, GLsizei count, const GLint *value);
Void gNUniform1iv (gLint location, gLsizei count, const gLint *value)<

}

void glUniform2iv (GLint location, GLsizei count, const GLint *value);
Void gNUniform2iv (gLint location, gLsizei count, const gLint *value)<

}

void glUniform3iv (GLint location, GLsizei count, const GLint *value);
Void gNUniform3iv (gLint location, gLsizei count, const gLint *value)<

}

void glUniform4iv (GLint location, GLsizei count, const GLint *value);
Void gNUniform4iv (gLint location, gLsizei count, const gLint *value)<

}

void glUniformMatrix2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix2fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix3fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix4fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glValidateProgram (GLuint program);
Void gNValidateProgram (gLuint program)<

}

void glVertexAttrib1d (GLuint index, GLdouble x);
Void gNVertexAttrib1d (gLuint index, gLdouble x)<

}

void glVertexAttrib1dv (GLuint index, const GLdouble *v);
Void gNVertexAttrib1dv (gLuint index, const gLdouble *v)<

}

void glVertexAttrib1f (GLuint index, GLfloat x);
Void gNVertexAttrib1f (gLuint index, gLfloat x)<

}

void glVertexAttrib1fv (GLuint index, const GLfloat *v);
Void gNVertexAttrib1fv (gLuint index, const gLfloat *v)<

}

void glVertexAttrib1s (GLuint index, GLshort x);
Void gNVertexAttrib1s (gLuint index, gLshort x)<

}

void glVertexAttrib1sv (GLuint index, const GLshort *v);
Void gNVertexAttrib1sv (gLuint index, const gLshort *v)<

}

void glVertexAttrib2d (GLuint index, GLdouble x, GLdouble y);
Void gNVertexAttrib2d (gLuint index, gLdouble x, gLdouble y)<

}

void glVertexAttrib2dv (GLuint index, const GLdouble *v);
Void gNVertexAttrib2dv (gLuint index, const gLdouble *v)<

}

void glVertexAttrib2f (GLuint index, GLfloat x, GLfloat y);
Void gNVertexAttrib2f (gLuint index, gLfloat x, gLfloat y)<

}

void glVertexAttrib2fv (GLuint index, const GLfloat *v);
Void gNVertexAttrib2fv (gLuint index, const gLfloat *v)<

}

void glVertexAttrib2s (GLuint index, GLshort x, GLshort y);
Void gNVertexAttrib2s (gLuint index, gLshort x, gLshort y)<

}

void glVertexAttrib2sv (GLuint index, const GLshort *v);
Void gNVertexAttrib2sv (gLuint index, const gLshort *v)<

}

void glVertexAttrib3d (GLuint index, GLdouble x, GLdouble y, GLdouble z);
Void gNVertexAttrib3d (gLuint index, gLdouble x, gLdouble y, gLdouble z)<

}

void glVertexAttrib3dv (GLuint index, const GLdouble *v);
Void gNVertexAttrib3dv (gLuint index, const gLdouble *v)<

}

void glVertexAttrib3f (GLuint index, GLfloat x, GLfloat y, GLfloat z);
Void gNVertexAttrib3f (gLuint index, gLfloat x, gLfloat y, gLfloat z)<

}

void glVertexAttrib3fv (GLuint index, const GLfloat *v);
Void gNVertexAttrib3fv (gLuint index, const gLfloat *v)<

}

void glVertexAttrib3s (GLuint index, GLshort x, GLshort y, GLshort z);
Void gNVertexAttrib3s (gLuint index, gLshort x, gLshort y, gLshort z)<

}

void glVertexAttrib3sv (GLuint index, const GLshort *v);
Void gNVertexAttrib3sv (gLuint index, const gLshort *v)<

}

void glVertexAttrib4Nbv (GLuint index, const GLbyte *v);
Void gNVertexAttrib4Nbv (gLuint index, const gLbyte *v)<

}

void glVertexAttrib4Niv (GLuint index, const GLint *v);
Void gNVertexAttrib4Niv (gLuint index, const gLint *v)<

}

void glVertexAttrib4Nsv (GLuint index, const GLshort *v);
Void gNVertexAttrib4Nsv (gLuint index, const gLshort *v)<

}

void glVertexAttrib4Nub (GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w);
Void gNVertexAttrib4Nub (gLuint index, gLubyte x, gLubyte y, gLubyte z, gLubyte w)<

}

void glVertexAttrib4Nubv (GLuint index, const GLubyte *v);
Void gNVertexAttrib4Nubv (gLuint index, const gLubyte *v)<

}

void glVertexAttrib4Nuiv (GLuint index, const GLuint *v);
Void gNVertexAttrib4Nuiv (gLuint index, const gLuint *v)<

}

void glVertexAttrib4Nusv (GLuint index, const GLushort *v);
Void gNVertexAttrib4Nusv (gLuint index, const gLushort *v)<

}

void glVertexAttrib4bv (GLuint index, const GLbyte *v);
Void gNVertexAttrib4bv (gLuint index, const gLbyte *v)<

}

void glVertexAttrib4d (GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
Void gNVertexAttrib4d (gLuint index, gLdouble x, gLdouble y, gLdouble z, gLdouble w)<

}

void glVertexAttrib4dv (GLuint index, const GLdouble *v);
Void gNVertexAttrib4dv (gLuint index, const gLdouble *v)<

}

void glVertexAttrib4f (GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
Void gNVertexAttrib4f (gLuint index, gLfloat x, gLfloat y, gLfloat z, gLfloat w)<

}

void glVertexAttrib4fv (GLuint index, const GLfloat *v);
Void gNVertexAttrib4fv (gLuint index, const gLfloat *v)<

}

void glVertexAttrib4iv (GLuint index, const GLint *v);
Void gNVertexAttrib4iv (gLuint index, const gLint *v)<

}

void glVertexAttrib4s (GLuint index, GLshort x, GLshort y, GLshort z, GLshort w);
Void gNVertexAttrib4s (gLuint index, gLshort x, gLshort y, gLshort z, gLshort w)<

}

void glVertexAttrib4sv (GLuint index, const GLshort *v);
Void gNVertexAttrib4sv (gLuint index, const gLshort *v)<

}

void glVertexAttrib4ubv (GLuint index, const GLubyte *v);
Void gNVertexAttrib4ubv (gLuint index, const gLubyte *v)<

}

void glVertexAttrib4uiv (GLuint index, const GLuint *v);
Void gNVertexAttrib4uiv (gLuint index, const gLuint *v)<

}

void glVertexAttrib4usv (GLuint index, const GLushort *v);
Void gNVertexAttrib4usv (gLuint index, const gLushort *v)<

}

void glVertexAttribPointer (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer);
Void gNVertexAttribPointer (gLuint index, gLint size, gLenum type, gLboolean normalized, gLsizei stride, const void *pointer)<

}



// GL_VERSION_2_1
void glUniformMatrix2x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix2x3fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix3x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix3x2fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix2x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix2x4fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix4x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix4x2fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix3x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix3x4fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}

void glUniformMatrix4x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
Void gNUniformMatrix4x3fv (gLint location, gLsizei count, gLboolean transpose, const gLfloat *value)<

}



// GL_VERSION_3_0
void glColorMaski (GLuint index, GLboolean r, GLboolean g, GLboolean b, GLboolean a);
Void gNColorMaski (gLuint index, gLboolean r, gLboolean g, gLboolean b, gLboolean a)<

}

void glGetBooleani_v (GLenum target, GLuint index, GLboolean *data);
Void gNGetBooleani_v (gLenum target, gLuint index, gLboolean *data)<

}

void glGetIntegeri_v (GLenum target, GLuint index, GLint *data);
Void gNGetIntegeri_v (gLenum target, gLuint index, gLint *data)<

}

void glEnablei (GLenum target, GLuint index);
Void gNEnablei (gLenum target, gLuint index)<

}

void glDisablei (GLenum target, GLuint index);
Void gNDisablei (gLenum target, gLuint index)<

}

GLboolean glIsEnabledi (GLenum target, GLuint index);
void glBeginTransformFeedback (GLenum primitiveMode);
Void gNBeginTransformFeedback (gLenum primitiveMode)<

}

void glEndTransformFeedback (void);
Void gNEndTransformFeedback (void)<

}

void glBindBufferRange (GLenum target, GLuint index, GLuint buffer, GLintptr offset, GLsizeiptr size);
Void gNBindBufferRange (gLenum target, gLuint index, gLuint buffer, gLintptr offset, gLsizeiptr size)<

}

void glBindBufferBase (GLenum target, GLuint index, GLuint buffer);
Void gNBindBufferBase (gLenum target, gLuint index, gLuint buffer)<

}

void glTransformFeedbackVaryings (GLuint program, GLsizei count, const GLchar *const*varyings, GLenum bufferMode);
Void gNTransformFeedbackVaryings (gLuint program, gLsizei count, const gLchar *const*varyings, gLenum bufferMode)<

}

void glGetTransformFeedbackVarying (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLsizei *size, GLenum *type, GLchar *name);
Void gNGetTransformFeedbackVarying (gLuint program, gLuint index, gLsizei bufSize, gLsizei *length, gLsizei *size, gLenum *type, gLchar *name)<

}

void glClampColor (GLenum target, GLenum clamp);
Void gNClampColor (gLenum target, gLenum clamp)<

}

void glBeginConditionalRender (GLuint id, GLenum mode);
Void gNBeginConditionalRender (gLuint id, gLenum mode)<

}

void glEndConditionalRender (void);
Void gNEndConditionalRender (void)<

}

void glVertexAttribIPointer (GLuint index, GLint size, GLenum type, GLsizei stride, const void *pointer);
Void gNVertexAttribIPointer (gLuint index, gLint size, gLenum type, gLsizei stride, const void *pointer)<

}

void glGetVertexAttribIiv (GLuint index, GLenum pname, GLint *params);
Void gNGetVertexAttribIiv (gLuint index, gLenum pname, gLint *params)<

}

void glGetVertexAttribIuiv (GLuint index, GLenum pname, GLuint *params);
Void gNGetVertexAttribIuiv (gLuint index, gLenum pname, gLuint *params)<

}

void glVertexAttribI1i (GLuint index, GLint x);
Void gNVertexAttribI1i (gLuint index, gLint x)<

}

void glVertexAttribI2i (GLuint index, GLint x, GLint y);
Void gNVertexAttribI2i (gLuint index, gLint x, gLint y)<

}

void glVertexAttribI3i (GLuint index, GLint x, GLint y, GLint z);
Void gNVertexAttribI3i (gLuint index, gLint x, gLint y, gLint z)<

}

void glVertexAttribI4i (GLuint index, GLint x, GLint y, GLint z, GLint w);
Void gNVertexAttribI4i (gLuint index, gLint x, gLint y, gLint z, gLint w)<

}

void glVertexAttribI1ui (GLuint index, GLuint x);
Void gNVertexAttribI1ui (gLuint index, gLuint x)<

}

void glVertexAttribI2ui (GLuint index, GLuint x, GLuint y);
Void gNVertexAttribI2ui (gLuint index, gLuint x, gLuint y)<

}

void glVertexAttribI3ui (GLuint index, GLuint x, GLuint y, GLuint z);
Void gNVertexAttribI3ui (gLuint index, gLuint x, gLuint y, gLuint z)<

}

void glVertexAttribI4ui (GLuint index, GLuint x, GLuint y, GLuint z, GLuint w);
Void gNVertexAttribI4ui (gLuint index, gLuint x, gLuint y, gLuint z, gLuint w)<

}

void glVertexAttribI1iv (GLuint index, const GLint *v);
Void gNVertexAttribI1iv (gLuint index, const gLint *v)<

}

void glVertexAttribI2iv (GLuint index, const GLint *v);
Void gNVertexAttribI2iv (gLuint index, const gLint *v)<

}

void glVertexAttribI3iv (GLuint index, const GLint *v);
Void gNVertexAttribI3iv (gLuint index, const gLint *v)<

}

void glVertexAttribI4iv (GLuint index, const GLint *v);
Void gNVertexAttribI4iv (gLuint index, const gLint *v)<

}

void glVertexAttribI1uiv (GLuint index, const GLuint *v);
Void gNVertexAttribI1uiv (gLuint index, const gLuint *v)<

}

void glVertexAttribI2uiv (GLuint index, const GLuint *v);
Void gNVertexAttribI2uiv (gLuint index, const gLuint *v)<

}

void glVertexAttribI3uiv (GLuint index, const GLuint *v);
Void gNVertexAttribI3uiv (gLuint index, const gLuint *v)<

}

void glVertexAttribI4uiv (GLuint index, const GLuint *v);
Void gNVertexAttribI4uiv (gLuint index, const gLuint *v)<

}

void glVertexAttribI4bv (GLuint index, const GLbyte *v);
Void gNVertexAttribI4bv (gLuint index, const gLbyte *v)<

}

void glVertexAttribI4sv (GLuint index, const GLshort *v);
Void gNVertexAttribI4sv (gLuint index, const gLshort *v)<

}

void glVertexAttribI4ubv (GLuint index, const GLubyte *v);
Void gNVertexAttribI4ubv (gLuint index, const gLubyte *v)<

}

void glVertexAttribI4usv (GLuint index, const GLushort *v);
Void gNVertexAttribI4usv (gLuint index, const gLushort *v)<

}

void glGetUniformuiv (GLuint program, GLint location, GLuint *params);
Void gNGetUniformuiv (gLuint program, gLint location, gLuint *params)<

}

void glBindFragDataLocation (GLuint program, GLuint color, const GLchar *name);
Void gNBindFragDataLocation (gLuint program, gLuint color, const gLchar *name)<

}

GLint glGetFragDataLocation (GLuint program, const GLchar *name);
void glUniform1ui (GLint location, GLuint v0);
Void gNUniform1ui (gLint location, gLuint v0)<

}

void glUniform2ui (GLint location, GLuint v0, GLuint v1);
Void gNUniform2ui (gLint location, gLuint v0, gLuint v1)<

}

void glUniform3ui (GLint location, GLuint v0, GLuint v1, GLuint v2);
Void gNUniform3ui (gLint location, gLuint v0, gLuint v1, gLuint v2)<

}

void glUniform4ui (GLint location, GLuint v0, GLuint v1, GLuint v2, GLuint v3);
Void gNUniform4ui (gLint location, gLuint v0, gLuint v1, gLuint v2, gLuint v3)<

}

void glUniform1uiv (GLint location, GLsizei count, const GLuint *value);
Void gNUniform1uiv (gLint location, gLsizei count, const gLuint *value)<

}

void glUniform2uiv (GLint location, GLsizei count, const GLuint *value);
Void gNUniform2uiv (gLint location, gLsizei count, const gLuint *value)<

}

void glUniform3uiv (GLint location, GLsizei count, const GLuint *value);
Void gNUniform3uiv (gLint location, gLsizei count, const gLuint *value)<

}

void glUniform4uiv (GLint location, GLsizei count, const GLuint *value);
Void gNUniform4uiv (gLint location, gLsizei count, const gLuint *value)<

}

void glTexParameterIiv (GLenum target, GLenum pname, const GLint *params);
Void gNTexParameterIiv (gLenum target, gLenum pname, const gLint *params)<

}

void glTexParameterIuiv (GLenum target, GLenum pname, const GLuint *params);
Void gNTexParameterIuiv (gLenum target, gLenum pname, const gLuint *params)<

}

void glGetTexParameterIiv (GLenum target, GLenum pname, GLint *params);
Void gNGetTexParameterIiv (gLenum target, gLenum pname, gLint *params)<

}

void glGetTexParameterIuiv (GLenum target, GLenum pname, GLuint *params);
Void gNGetTexParameterIuiv (gLenum target, gLenum pname, gLuint *params)<

}

void glClearBufferiv (GLenum buffer, GLint drawbuffer, const GLint *value);
Void gNClearBufferiv (gLenum buffer, gLint drawbuffer, const gLint *value)<

}

void glClearBufferuiv (GLenum buffer, GLint drawbuffer, const GLuint *value);
Void gNClearBufferuiv (gLenum buffer, gLint drawbuffer, const gLuint *value)<

}

void glClearBufferfv (GLenum buffer, GLint drawbuffer, const GLfloat *value);
Void gNClearBufferfv (gLenum buffer, gLint drawbuffer, const gLfloat *value)<

}

void glClearBufferfi (GLenum buffer, GLint drawbuffer, GLfloat depth, GLint stencil);
Void gNClearBufferfi (gLenum buffer, gLint drawbuffer, gLfloat depth, gLint stencil)<

}

const GLubyte *glGetStringi (GLenum name, GLuint index);
GLboolean glIsRenderbuffer (GLuint renderbuffer);
void glBindRenderbuffer (GLenum target, GLuint renderbuffer);
Void gNBindRenderbuffer (gLenum target, gLuint renderbuffer)<

}

void glDeleteRenderbuffers (GLsizei n, const GLuint *renderbuffers);
Void gNDeleteRenderbuffers (gLsizei n, const gLuint *renderbuffers)<

}

void glGenRenderbuffers (GLsizei n, GLuint *renderbuffers);
Void gNGenRenderbuffers (gLsizei n, gLuint *renderbuffers)<

}

void glRenderbufferStorage (GLenum target, GLenum internalformat, GLsizei width, GLsizei height);
Void gNRenderbufferStorage (gLenum target, gLenum internalformat, gLsizei width, gLsizei height)<

}

void glGetRenderbufferParameteriv (GLenum target, GLenum pname, GLint *params);
Void gNGetRenderbufferParameteriv (gLenum target, gLenum pname, gLint *params)<

}

GLboolean glIsFramebuffer (GLuint framebuffer);
void glBindFramebuffer (GLenum target, GLuint framebuffer);
Void gNBindFramebuffer (gLenum target, gLuint framebuffer)<

}

void glDeleteFramebuffers (GLsizei n, const GLuint *framebuffers);
Void gNDeleteFramebuffers (gLsizei n, const gLuint *framebuffers)<

}

void glGenFramebuffers (GLsizei n, GLuint *framebuffers);
Void gNGenFramebuffers (gLsizei n, gLuint *framebuffers)<

}

GLenum glCheckFramebufferStatus (GLenum target);
void glFramebufferTexture1D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
Void gNFramebufferTexture1D (gLenum target, gLenum attachment, gLenum textarget, gLuint texture, gLint level)<

}

void glFramebufferTexture2D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
Void gNFramebufferTexture2D (gLenum target, gLenum attachment, gLenum textarget, gLuint texture, gLint level)<

}

void glFramebufferTexture3D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level, GLint zoffset);
Void gNFramebufferTexture3D (gLenum target, gLenum attachment, gLenum textarget, gLuint texture, gLint level, gLint zoffset)<

}

void glFramebufferRenderbuffer (GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer);
Void gNFramebufferRenderbuffer (gLenum target, gLenum attachment, gLenum renderbuffertarget, gLuint renderbuffer)<

}

void glGetFramebufferAttachmentParameteriv (GLenum target, GLenum attachment, GLenum pname, GLint *params);
Void gNGetFramebufferAttachmentParameteriv (gLenum target, gLenum attachment, gLenum pname, gLint *params)<

}

void glGenerateMipmap (GLenum target);
Void gNGenerateMipmap (gLenum target)<

}

void glBlitFramebuffer (GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter);
Void gNBlitFramebuffer (gLint srcX0, gLint srcY0, gLint srcX1, gLint srcY1, gLint dstX0, gLint dstY0, gLint dstX1, gLint dstY1, gLbitfield mask, gLenum filter)<

}

void glRenderbufferStorageMultisample (GLenum target, GLsizei samples, GLenum internalformat, GLsizei width, GLsizei height);
Void gNRenderbufferStorageMultisample (gLenum target, gLsizei samples, gLenum internalformat, gLsizei width, gLsizei height)<

}

void glFramebufferTextureLayer (GLenum target, GLenum attachment, GLuint texture, GLint level, GLint layer);
Void gNFramebufferTextureLayer (gLenum target, gLenum attachment, gLuint texture, gLint level, gLint layer)<

}

void *glMapBufferRange (GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access);
Void *NlMapBufferRange (gLenum target, gLintptr offset, gLsizeiptr length, gLbitfield access)<

}

void glFlushMappedBufferRange (GLenum target, GLintptr offset, GLsizeiptr length);
Void gNFlushMappedBufferRange (gLenum target, gLintptr offset, gLsizeiptr length)<

}

void glBindVertexArray (GLuint array);
Void gNBindVertexArray (gLuint array)<

}

void glDeleteVertexArrays (GLsizei n, const GLuint *arrays);
Void gNDeleteVertexArrays (gLsizei n, const gLuint *arrays)<

}

void glGenVertexArrays (GLsizei n, GLuint *arrays);
Void gNGenVertexArrays (gLsizei n, gLuint *arrays)<

}

GLboolean glIsVertexArray (GLuint array);





                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  