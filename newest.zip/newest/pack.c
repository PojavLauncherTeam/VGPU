// OpenGL 2.0 >> 3.0

#include "pack.h"
#include "pack1.h"


// GLuint glCreateShader( GLenum type )
// {
//  return TglCreateShader( type );     // Because TglFunc() has been declared as an external type in pack1.h,
// }								      // So you can use these TglFunc() directly here. 
									      // However, their function definitions are in to.c.




// GL_VERSION_1_0
void glCullFace (GLenum mode){
 TglCullFace (mode);

}

void glFrontFace (GLenum mode){
 TglFrontFace (mode);

}

void glHint (GLenum target, GLenum mode){
 TglHint (target, mode);

}

void glLineWidth (GLfloat width){
 TglLineWidth (width);

}

void glPointSize (GLfloat size){
 TglPointSize (size);

}

void glPolygonMode (GLenum face, GLenum mode){
 TglPolygonMode (face, mode);

}

void glScissor (GLint x, GLint y, GLsizei width, GLsizei height){
 TglScissor (x, y, width, height);

}

void glTexParameterf (GLenum target, GLenum pname, GLfloat param){
 TglTexParameterf (target, pname, param);

}

void glTexParameterfv (GLenum target, GLenum pname, const GLfloat *params){
 TglTexParameterfv (target, pname, params);

}

void glTexParameteri (GLenum target, GLenum pname, GLint param){
 TglTexParameteri (target, pname, param);

}

void glTexParameteriv (GLenum target, GLenum pname, const GLint *params){
 TglTexParameteriv (target, pname, params);

}

void glTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const void *pixels){
 TglTexImage1D (target, level, internalformat, width, border, format, type, pixels);

}

void glTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels){
 TglTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);

}

void glDrawBuffer (GLenum buf){
 TglDrawBuffer (buf);

}

void glClear (GLbitfield mask){
 TglClear (mask);

}

void glClearColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha){
 TglClearColor (red, green, blue, alpha);

}

void glClearStencil (GLint s){
 TglClearStencil (s);

}

void glClearDepth (GLdouble depth){
 TglClearDepth (depth);

}

void glStencilMask (GLuint mask){
 TglStencilMask (mask);

}

void glColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha){
 TglColorMask (red, green, blue, alpha);

}

void glDepthMask (GLboolean flag){
 TglDepthMask (flag);

}

void glDisable (GLenum cap){
 TglDisable (cap);

}

void glEnable (GLenum cap){
 TglEnable (cap);

}

void glFinish (void){
 TglFinish ();

}

void glFlush (void){
 TglFlush ();

}

void glBlendFunc (GLenum sfactor, GLenum dfactor){
 TglBlendFunc (sfactor, dfactor);

}

void glLogicOp (GLenum opcode){
 TglLogicOp (opcode);

}

void glStencilFunc (GLenum func, GLint ref, GLuint mask){
 TglStencilFunc (func, ref, mask);

}

void glStencilOp (GLenum fail, GLenum zfail, GLenum zpass){
 TglStencilOp (fail, zfail, zpass);

}

void glDepthFunc (GLenum func){
 TglDepthFunc (func);

}

void glPixelStoref (GLenum pname, GLfloat param){
 TglPixelStoref (pname, param);

}

void glPixelStorei (GLenum pname, GLint param){
 TglPixelStorei (pname, param);

}

void glReadBuffer (GLenum src){
 TglReadBuffer (src);

}

void glReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels){
 TglReadPixels (x, y, width, height, format, type, pixels);

}

void glGetBooleanv (GLenum pname, GLboolean *data){
 TglGetBooleanv (pname, data);

}

void glGetDoublev (GLenum pname, GLdouble *data){
 TglGetDoublev (pname, data);

}

GLenum glGetError (void){
 return TglGetError ();

}

void glGetFloatv (GLenum pname, GLfloat *data){
 TglGetFloatv (pname, data);

}

void glGetIntegerv (GLenum pname, GLint *data){
 TglGetIntegerv (pname, data);

}

const GLubyte *glGetString (GLenum name){
 return TglGetString (name);

}

void glGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, void *pixels){
 TglGetTexImage (target, level, format, type, pixels);

}

void glGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params){
 TglGetTexParameterfv (target, pname, params);

}

void glGetTexParameteriv (GLenum target, GLenum pname, GLint *params){
 TglGetTexParameteriv (target, pname, params);

}

void glGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params){
 TglGetTexLevelParameterfv (target, level, pname, params);

}

void glGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params){
 TglGetTexLevelParameteriv (target, level, pname, params);

}

GLboolean glIsEnabled (GLenum cap){
 return TglIsEnabled (cap);

}

void glDepthRange (GLdouble n, GLdouble f){
 TglDepthRange (n, f);

}

void glViewport (GLint x, GLint y, GLsizei width, GLsizei height){
 TglViewport (x, y, width, height);

}



// GL_VERSION_1_1
void glDrawArrays (GLenum mode, GLint first, GLsizei count){
 TglDrawArrays (mode, first, count);

}

void glDrawElements (GLenum mode, GLsizei count, GLenum type, const void *indices){
 TglDrawElements (mode, count, type, indices);

}

void glGetPointerv (GLenum pname, void **params){
 TglGetPointerv (pname, params);

}

void glPolygonOffset (GLfloat factor, GLfloat units){
 TglPolygonOffset (factor, units);

}

void glCopyTexImage1D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLint border){
 TglCopyTexImage1D (target, level, internalformat, x, y, width, border);

}

void glCopyTexImage2D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border){
 TglCopyTexImage2D (target, level, internalformat, x, y, width, height, border);

}

void glCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width){
 TglCopyTexSubImage1D (target, level, xoffset, x, y, width);

}

void glCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height){
 TglCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);

}

void glTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const void *pixels){
 TglTexSubImage1D (target, level, xoffset, width, format, type, pixels);

}

void glTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels){
 TglTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);

}

void glBindTexture (GLenum target, GLuint texture){
 TglBindTexture (target, texture);

}

void glDeleteTextures (GLsizei n, const GLuint *textures){
 TglDeleteTextures (n, textures);

}

void glGenTextures (GLsizei n, GLuint *textures){
 TglGenTextures (n, textures);

}

GLboolean glIsTexture (GLuint texture){
 return TglIsTexture (texture);

}



// GL_VERSION_1_2
void glDrawRangeElements (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices){
 TglDrawRangeElements (mode, start, end, count, type, indices);

}

void glTexImage3D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *pixels){
 TglTexImage3D (target, level, internalformat, width, height, depth, border, format, type, pixels);

}

void glTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, const void *pixels){
 TglTexSubImage3D (target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels);

}

void glCopyTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height){
 TglCopyTexSubImage3D (target, level, xoffset, yoffset, zoffset, x, y, width, height);

}



// GL_VERSION_1_3
void glActiveTexture (GLenum texture){
 TglActiveTexture (texture);

}

void glSampleCoverage (GLfloat value, GLboolean invert){
 TglSampleCoverage (value, invert);

}

void glCompressedTexImage3D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const void *data){
 TglCompressedTexImage3D (target, level, internalformat, width, height, depth, border, imageSize, data);

}

void glCompressedTexImage2D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data){
 TglCompressedTexImage2D (target, level, internalformat, width, height, border, imageSize, data);

}

void glCompressedTexImage1D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLint border, GLsizei imageSize, const void *data){
 TglCompressedTexImage1D (target, level, internalformat, width, border, imageSize, data);

}

void glCompressedTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const void *data){
 TglCompressedTexSubImage3D (target, level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, data);

}

void glCompressedTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data){
 TglCompressedTexSubImage2D (target, level, xoffset, yoffset, width, height, format, imageSize, data);

}

void glCompressedTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const void *data){
 TglCompressedTexSubImage1D (target, level, xoffset, width, format, imageSize, data);

}

void glGetCompressedTexImage (GLenum target, GLint level, void *img){
 TglGetCompressedTexImage (target, level, img);

}



// GL_VERSION_1_4
void glBlendFuncSeparate (GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha){
 TglBlendFuncSeparate (sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha);

}

void glMultiDrawArrays (GLenum mode, const GLint *first, const GLsizei *count, GLsizei drawcount){
 TglMultiDrawArrays (mode, first, count, drawcount);

}

void glMultiDrawElements (GLenum mode, const GLsizei *count, GLenum type, const void *const*indices, GLsizei drawcount){
 TglMultiDrawElements (mode, count, type, indices, drawcount);

}

void glPointParameterf (GLenum pname, GLfloat param){
 TglPointParameterf (pname, param);

}

void glPointParameterfv (GLenum pname, const GLfloat *params){
 TglPointParameterfv (pname, params);

}

void glPointParameteri (GLenum pname, GLint param){
 TglPointParameteri (pname, param);

}

void glPointParameteriv (GLenum pname, const GLint *params){
 TglPointParameteriv (pname, params);

}

void glBlendColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha){
 TglBlendColor (red, green, blue, alpha);

}

void glBlendEquation (GLenum mode){
 TglBlendEquation (mode);

}



// GL_VERSION_1_5
void glGenQueries (GLsizei n, GLuint *ids){
 TglGenQueries (n, ids);

}

void glDeleteQueries (GLsizei n, const GLuint *ids){
 TglDeleteQueries (n, ids);

}

GLboolean glIsQuery (GLuint id){
 return TglIsQuery (id);

}

void glBeginQuery (GLenum target, GLuint id){
 TglBeginQuery (target, id);

}

void glEndQuery (GLenum target){
 TglEndQuery (target);

}

void glGetQueryiv (GLenum target, GLenum pname, GLint *params){
 TglGetQueryiv (target, pname, params);

}

void glGetQueryObjectiv (GLuint id, GLenum pname, GLint *params){
 TglGetQueryObjectiv (id, pname, params);

}

void glGetQueryObjectuiv (GLuint id, GLenum pname, GLuint *params){
 TglGetQueryObjectuiv (id, pname, params);

}

void glBindBuffer (GLenum target, GLuint buffer){
 TglBindBuffer (target, buffer);

}

void glDeleteBuffers (GLsizei n, const GLuint *buffers){
 TglDeleteBuffers (n, buffers);

}

void glGenBuffers (GLsizei n, GLuint *buffers){
 TglGenBuffers (n, buffers);

}

GLboolean glIsBuffer (GLuint buffer){
 return TglIsBuffer (buffer);

}

void glBufferData (GLenum target, GLsizeiptr size, const void *data, GLenum usage){
 TglBufferData (target, size, data, usage);

}

void glBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const void *data){
 TglBufferSubData (target, offset, size, data);

}

void glGetBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, void *data){
 TglGetBufferSubData (target, offset, size, data);

}

void *glMapBuffer (GLenum target, GLenum access){
 return TglMapBuffer (target, access);

}

GLboolean glUnmapBuffer (GLenum target){
 return TglUnmapBuffer (target);

}

void glGetBufferParameteriv (GLenum target, GLenum pname, GLint *params){
 TglGetBufferParameteriv (target, pname, params);

}

void glGetBufferPointerv (GLenum target, GLenum pname, void **params){
 TglGetBufferPointerv (target, pname, params);

}



// GL_VERSION_2_0
void glBlendEquationSeparate (GLenum modeRGB, GLenum modeAlpha){
 TglBlendEquationSeparate (modeRGB, modeAlpha);

}

void glDrawBuffers (GLsizei n, const GLenum *bufs){
 TglDrawBuffers (n, bufs);

}

void glStencilOpSeparate (GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass){
 TglStencilOpSeparate (face, sfail, dpfail, dppass);

}

void glStencilFuncSeparate (GLenum face, GLenum func, GLint ref, GLuint mask){
 TglStencilFuncSeparate (face, func, ref, mask);

}

void glStencilMaskSeparate (GLenum face, GLuint mask){
 TglStencilMaskSeparate (face, mask);

}

void glAttachShader (GLuint program, GLuint shader){
 TglAttachShader (program, shader);

}

void glBindAttribLocation (GLuint program, GLuint index, const GLchar *name){
 TglBindAttribLocation (program, index, name);

}

void glCompileShader (GLuint shader){
 TglCompileShader (shader);

}

GLuint glCreateProgram (void){
 return TglCreateProgram ();

}

GLuint glCreateShader (GLenum type){
 return TglCreateShader (type);

}

void glDeleteProgram (GLuint program){
 TglDeleteProgram (program);

}

void glDeleteShader (GLuint shader){
 TglDeleteShader (shader);

}

void glDetachShader (GLuint program, GLuint shader){
 TglDetachShader (program, shader);

}

void glDisableVertexAttribArray (GLuint index){
 TglDisableVertexAttribArray (index);

}

void glEnableVertexAttribArray (GLuint index){
 TglEnableVertexAttribArray (index);

}

void glGetActiveAttrib (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name){
 TglGetActiveAttrib (program, index, bufSize, length, size, type, name);

}

void glGetActiveUniform (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name){
 TglGetActiveUniform (program, index, bufSize, length, size, type, name);

}

void glGetAttachedShaders (GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders){
 TglGetAttachedShaders (program, maxCount, count, shaders);

}

GLint glGetAttribLocation (GLuint program, const GLchar *name){
 return TglGetAttribLocation (program, name);

}

void glGetProgramiv (GLuint program, GLenum pname, GLint *params){
 TglGetProgramiv (program, pname, params);

}

void glGetProgramInfoLog (GLuint program, GLsizei bufSize, GLsizei *length, GLchar *infoLog){
 TglGetProgramInfoLog (program, bufSize, length, infoLog);

}

void glGetShaderiv (GLuint shader, GLenum pname, GLint *params){
 TglGetShaderiv (shader, pname, params);

}

void glGetShaderInfoLog (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *infoLog){
 TglGetShaderInfoLog (shader, bufSize, length, infoLog);

}

void glGetShaderSource (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *source){
 TglGetShaderSource (shader, bufSize, length, source);

}

GLint glGetUniformLocation (GLuint program, const GLchar *name){
 return TglGetUniformLocation (program, name);

}

void glGetUniformfv (GLuint program, GLint location, GLfloat *params){
 TglGetUniformfv (program, location, params);

}

void glGetUniformiv (GLuint program, GLint location, GLint *params){
 TglGetUniformiv (program, location, params);

}

void glGetVertexAttribdv (GLuint index, GLenum pname, GLdouble *params){
 TglGetVertexAttribdv (index, pname, params);

}

void glGetVertexAttribfv (GLuint index, GLenum pname, GLfloat *params){
 TglGetVertexAttribfv (index, pname, params);

}

void glGetVertexAttribiv (GLuint index, GLenum pname, GLint *params){
 TglGetVertexAttribiv (index, pname, params);

}

void glGetVertexAttribPointerv (GLuint index, GLenum pname, void **pointer){
 TglGetVertexAttribPointerv (index, pname, pointer);

}

GLboolean glIsProgram (GLuint program){
 return TglIsProgram (program);

}

GLboolean glIsShader (GLuint shader){
 return TglIsShader (shader);

}

void glLinkProgram (GLuint program){
 TglLinkProgram (program);

}

void glShaderSource (GLuint shader, GLsizei count, const GLchar *const*string, const GLint *length){
 TglShaderSource (shader, count, string, length);

}

void glUseProgram (GLuint program){
 TglUseProgram (program);

}

void glUniform1f (GLint location, GLfloat v0){
 TglUniform1f (location, v0);

}

void glUniform2f (GLint location, GLfloat v0, GLfloat v1){
 TglUniform2f (location, v0, v1);

}

void glUniform3f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2){
 TglUniform3f (location, v0, v1, v2);

}

void glUniform4f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3){
 TglUniform4f (location, v0, v1, v2, v3);

}

void glUniform1i (GLint location, GLint v0){
 TglUniform1i (location, v0);

}

void glUniform2i (GLint location, GLint v0, GLint v1){
 TglUniform2i (location, v0, v1);

}

void glUniform3i (GLint location, GLint v0, GLint v1, GLint v2){
 TglUniform3i (location, v0, v1, v2);

}

void glUniform4i (GLint location, GLint v0, GLint v1, GLint v2, GLint v3){
 TglUniform4i (location, v0, v1, v2, v3);

}

void glUniform1fv (GLint location, GLsizei count, const GLfloat *value){
 TglUniform1fv (location, count, value);

}

void glUniform2fv (GLint location, GLsizei count, const GLfloat *value){
 TglUniform2fv (location, count, value);

}

void glUniform3fv (GLint location, GLsizei count, const GLfloat *value){
 TglUniform3fv (location, count, value);

}

void glUniform4fv (GLint location, GLsizei count, const GLfloat *value){
 TglUniform4fv (location, count, value);

}

void glUniform1iv (GLint location, GLsizei count, const GLint *value){
 TglUniform1iv (location, count, value);

}

void glUniform2iv (GLint location, GLsizei count, const GLint *value){
 TglUniform2iv (location, count, value);

}

void glUniform3iv (GLint location, GLsizei count, const GLint *value){
 TglUniform3iv (location, count, value);

}

void glUniform4iv (GLint location, GLsizei count, const GLint *value){
 TglUniform4iv (location, count, value);

}

void glUniformMatrix2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix2fv (location, count, transpose, value);

}

void glUniformMatrix3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix3fv (location, count, transpose, value);

}

void glUniformMatrix4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix4fv (location, count, transpose, value);

}

void glValidateProgram (GLuint program){
 TglValidateProgram (program);

}

void glVertexAttrib1d (GLuint index, GLdouble x){
 TglVertexAttrib1d (index, x);

}

void glVertexAttrib1dv (GLuint index, const GLdouble *v){
 TglVertexAttrib1dv (index, v);

}

void glVertexAttrib1f (GLuint index, GLfloat x){
 TglVertexAttrib1f (index, x);

}

void glVertexAttrib1fv (GLuint index, const GLfloat *v){
 TglVertexAttrib1fv (index, v);

}

void glVertexAttrib1s (GLuint index, GLshort x){
 TglVertexAttrib1s (index, x);

}

void glVertexAttrib1sv (GLuint index, const GLshort *v){
 TglVertexAttrib1sv (index, v);

}

void glVertexAttrib2d (GLuint index, GLdouble x, GLdouble y){
 TglVertexAttrib2d (index, x, y);

}

void glVertexAttrib2dv (GLuint index, const GLdouble *v){
 TglVertexAttrib2dv (index, v);

}

void glVertexAttrib2f (GLuint index, GLfloat x, GLfloat y){
 TglVertexAttrib2f (index, x, y);

}

void glVertexAttrib2fv (GLuint index, const GLfloat *v){
 TglVertexAttrib2fv (index, v);

}

void glVertexAttrib2s (GLuint index, GLshort x, GLshort y){
 TglVertexAttrib2s (index, x, y);

}

void glVertexAttrib2sv (GLuint index, const GLshort *v){
 TglVertexAttrib2sv (index, v);

}

void glVertexAttrib3d (GLuint index, GLdouble x, GLdouble y, GLdouble z){
 TglVertexAttrib3d (index, x, y, z);

}

void glVertexAttrib3dv (GLuint index, const GLdouble *v){
 TglVertexAttrib3dv (index, v);

}

void glVertexAttrib3f (GLuint index, GLfloat x, GLfloat y, GLfloat z){
 TglVertexAttrib3f (index, x, y, z);

}

void glVertexAttrib3fv (GLuint index, const GLfloat *v){
 TglVertexAttrib3fv (index, v);

}

void glVertexAttrib3s (GLuint index, GLshort x, GLshort y, GLshort z){
 TglVertexAttrib3s (index, x, y, z);

}

void glVertexAttrib3sv (GLuint index, const GLshort *v){
 TglVertexAttrib3sv (index, v);

}

void glVertexAttrib4Nbv (GLuint index, const GLbyte *v){
 TglVertexAttrib4Nbv (index, v);

}

void glVertexAttrib4Niv (GLuint index, const GLint *v){
 TglVertexAttrib4Niv (index, v);

}

void glVertexAttrib4Nsv (GLuint index, const GLshort *v){
 TglVertexAttrib4Nsv (index, v);

}

void glVertexAttrib4Nub (GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w){
 TglVertexAttrib4Nub (index, x, y, z, w);

}

void glVertexAttrib4Nubv (GLuint index, const GLubyte *v){
 TglVertexAttrib4Nubv (index, v);

}

void glVertexAttrib4Nuiv (GLuint index, const GLuint *v){
 TglVertexAttrib4Nuiv (index, v);

}

void glVertexAttrib4Nusv (GLuint index, const GLushort *v){
 TglVertexAttrib4Nusv (index, v);

}

void glVertexAttrib4bv (GLuint index, const GLbyte *v){
 TglVertexAttrib4bv (index, v);

}

void glVertexAttrib4d (GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w){
 TglVertexAttrib4d (index, x, y, z, w);

}

void glVertexAttrib4dv (GLuint index, const GLdouble *v){
 TglVertexAttrib4dv (index, v);

}

void glVertexAttrib4f (GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w){
 TglVertexAttrib4f (index, x, y, z, w);

}

void glVertexAttrib4fv (GLuint index, const GLfloat *v){
 TglVertexAttrib4fv (index, v);

}

void glVertexAttrib4iv (GLuint index, const GLint *v){
 TglVertexAttrib4iv (index, v);

}

void glVertexAttrib4s (GLuint index, GLshort x, GLshort y, GLshort z, GLshort w){
 TglVertexAttrib4s (index, x, y, z, w);

}

void glVertexAttrib4sv (GLuint index, const GLshort *v){
 TglVertexAttrib4sv (index, v);

}

void glVertexAttrib4ubv (GLuint index, const GLubyte *v){
 TglVertexAttrib4ubv (index, v);

}

void glVertexAttrib4uiv (GLuint index, const GLuint *v){
 TglVertexAttrib4uiv (index, v);

}

void glVertexAttrib4usv (GLuint index, const GLushort *v){
 TglVertexAttrib4usv (index, v);

}

void glVertexAttribPointer (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer){
 TglVertexAttribPointer (index, size, type, normalized, stride, pointer);

}



// GL_VERSION_2_1
void glUniformMatrix2x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix2x3fv (location, count, transpose, value);

}

void glUniformMatrix3x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix3x2fv (location, count, transpose, value);

}

void glUniformMatrix2x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix2x4fv (location, count, transpose, value);

}

void glUniformMatrix4x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix4x2fv (location, count, transpose, value);

}

void glUniformMatrix3x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix3x4fv (location, count, transpose, value);

}

void glUniformMatrix4x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 TglUniformMatrix4x3fv (location, count, transpose, value);

}



// GL_VERSION_3_0
void glColorMaski (GLuint index, GLboolean r, GLboolean g, GLboolean b, GLboolean a){
 TglColorMaski (index, r, g, b, a);

}

void glGetBooleani_v (GLenum target, GLuint index, GLboolean *data){
 TglGetBooleani_v (target, index, data);

}

void glGetIntegeri_v (GLenum target, GLuint index, GLint *data){
 TglGetIntegeri_v (target, index, data);

}

void glEnablei (GLenum target, GLuint index){
 TglEnablei (target, index);

}

void glDisablei (GLenum target, GLuint index){
 TglDisablei (target, index);

}

GLboolean glIsEnabledi (GLenum target, GLuint index){
 return TglIsEnabledi (target, index);

}

void glBeginTransformFeedback (GLenum primitiveMode){
 TglBeginTransformFeedback (primitiveMode);

}

void glEndTransformFeedback (void){
 TglEndTransformFeedback ();

}

void glBindBufferRange (GLenum target, GLuint index, GLuint buffer, GLintptr offset, GLsizeiptr size){
 TglBindBufferRange (target, index, buffer, offset, size);

}

void glBindBufferBase (GLenum target, GLuint index, GLuint buffer){
 TglBindBufferBase (target, index, buffer);

}

void glTransformFeedbackVaryings (GLuint program, GLsizei count, const GLchar *const*varyings, GLenum bufferMode){
 TglTransformFeedbackVaryings (program, count, varyings, bufferMode);

}

void glGetTransformFeedbackVarying (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLsizei *size, GLenum *type, GLchar *name){
 TglGetTransformFeedbackVarying (program, index, bufSize, length, size, type, name);

}

void glClampColor (GLenum target, GLenum clamp){
 TglClampColor (target, clamp);

}

void glBeginConditionalRender (GLuint id, GLenum mode){
 TglBeginConditionalRender (id, mode);

}

void glEndConditionalRender (void){
 TglEndConditionalRender ();

}

void glVertexAttribIPointer (GLuint index, GLint size, GLenum type, GLsizei stride, const void *pointer){
 TglVertexAttribIPointer (index, size, type, stride, pointer);

}

void glGetVertexAttribIiv (GLuint index, GLenum pname, GLint *params){
 TglGetVertexAttribIiv (index, pname, params);

}

void glGetVertexAttribIuiv (GLuint index, GLenum pname, GLuint *params){
 TglGetVertexAttribIuiv (index, pname, params);

}

void glVertexAttribI1i (GLuint index, GLint x){
 TglVertexAttribI1i (index, x);

}

void glVertexAttribI2i (GLuint index, GLint x, GLint y){
 TglVertexAttribI2i (index, x, y);

}

void glVertexAttribI3i (GLuint index, GLint x, GLint y, GLint z){
 TglVertexAttribI3i (index, x, y, z);

}

void glVertexAttribI4i (GLuint index, GLint x, GLint y, GLint z, GLint w){
 TglVertexAttribI4i (index, x, y, z, w);

}

void glVertexAttribI1ui (GLuint index, GLuint x){
 TglVertexAttribI1ui (index, x);

}

void glVertexAttribI2ui (GLuint index, GLuint x, GLuint y){
 TglVertexAttribI2ui (index, x, y);

}

void glVertexAttribI3ui (GLuint index, GLuint x, GLuint y, GLuint z){
 TglVertexAttribI3ui (index, x, y, z);

}

void glVertexAttribI4ui (GLuint index, GLuint x, GLuint y, GLuint z, GLuint w){
 TglVertexAttribI4ui (index, x, y, z, w);

}

void glVertexAttribI1iv (GLuint index, const GLint *v){
 TglVertexAttribI1iv (index, v);

}

void glVertexAttribI2iv (GLuint index, const GLint *v){
 TglVertexAttribI2iv (index, v);

}

void glVertexAttribI3iv (GLuint index, const GLint *v){
 TglVertexAttribI3iv (index, v);

}

void glVertexAttribI4iv (GLuint index, const GLint *v){
 TglVertexAttribI4iv (index, v);

}

void glVertexAttribI1uiv (GLuint index, const GLuint *v){
 TglVertexAttribI1uiv (index, v);

}

void glVertexAttribI2uiv (GLuint index, const GLuint *v){
 TglVertexAttribI2uiv (index, v);

}

void glVertexAttribI3uiv (GLuint index, const GLuint *v){
 TglVertexAttribI3uiv (index, v);

}

void glVertexAttribI4uiv (GLuint index, const GLuint *v){
 TglVertexAttribI4uiv (index, v);

}

void glVertexAttribI4bv (GLuint index, const GLbyte *v){
 TglVertexAttribI4bv (index, v);

}

void glVertexAttribI4sv (GLuint index, const GLshort *v){
 TglVertexAttribI4sv (index, v);

}

void glVertexAttribI4ubv (GLuint index, const GLubyte *v){
 TglVertexAttribI4ubv (index, v);

}

void glVertexAttribI4usv (GLuint index, const GLushort *v){
 TglVertexAttribI4usv (index, v);

}

void glGetUniformuiv (GLuint program, GLint location, GLuint *params){
 TglGetUniformuiv (program, location, params);

}

void glBindFragDataLocation (GLuint program, GLuint color, const GLchar *name){
 TglBindFragDataLocation (program, color, name);

}

GLint glGetFragDataLocation (GLuint program, const GLchar *name){
 return TglGetFragDataLocation (program, name);

}

void glUniform1ui (GLint location, GLuint v0){
 TglUniform1ui (location, v0);

}

void glUniform2ui (GLint location, GLuint v0, GLuint v1){
 TglUniform2ui (location, v0, v1);

}

void glUniform3ui (GLint location, GLuint v0, GLuint v1, GLuint v2){
 TglUniform3ui (location, v0, v1, v2);

}

void glUniform4ui (GLint location, GLuint v0, GLuint v1, GLuint v2, GLuint v3){
 TglUniform4ui (location, v0, v1, v2, v3);

}

void glUniform1uiv (GLint location, GLsizei count, const GLuint *value){
 TglUniform1uiv (location, count, value);

}

void glUniform2uiv (GLint location, GLsizei count, const GLuint *value){
 TglUniform2uiv (location, count, value);

}

void glUniform3uiv (GLint location, GLsizei count, const GLuint *value){
 TglUniform3uiv (location, count, value);

}

void glUniform4uiv (GLint location, GLsizei count, const GLuint *value){
 TglUniform4uiv (location, count, value);

}

void glTexParameterIiv (GLenum target, GLenum pname, const GLint *params){
 TglTexParameterIiv (target, pname, params);

}

void glTexParameterIuiv (GLenum target, GLenum pname, const GLuint *params){
 TglTexParameterIuiv (target, pname, params);

}

void glGetTexParameterIiv (GLenum target, GLenum pname, GLint *params){
 TglGetTexParameterIiv (target, pname, params);

}

void glGetTexParameterIuiv (GLenum target, GLenum pname, GLuint *params){
 TglGetTexParameterIuiv (target, pname, params);

}

void glClearBufferiv (GLenum buffer, GLint drawbuffer, const GLint *value){
 TglClearBufferiv (buffer, drawbuffer, value);

}

void glClearBufferuiv (GLenum buffer, GLint drawbuffer, const GLuint *value){
 TglClearBufferuiv (buffer, drawbuffer, value);

}

void glClearBufferfv (GLenum buffer, GLint drawbuffer, const GLfloat *value){
 TglClearBufferfv (buffer, drawbuffer, value);

}

void glClearBufferfi (GLenum buffer, GLint drawbuffer, GLfloat depth, GLint stencil){
 TglClearBufferfi (buffer, drawbuffer, depth, stencil);

}

const GLubyte *glGetStringi (GLenum name, GLuint index){
 return TglGetStringi (name, index);

}

GLboolean glIsRenderbuffer (GLuint renderbuffer){
 return TglIsRenderbuffer (renderbuffer);

}

void glBindRenderbuffer (GLenum target, GLuint renderbuffer){
 TglBindRenderbuffer (target, renderbuffer);

}

void glDeleteRenderbuffers (GLsizei n, const GLuint *renderbuffers){
 TglDeleteRenderbuffers (n, renderbuffers);

}

void glGenRenderbuffers (GLsizei n, GLuint *renderbuffers){
 TglGenRenderbuffers (n, renderbuffers);

}

void glRenderbufferStorage (GLenum target, GLenum internalformat, GLsizei width, GLsizei height){
 TglRenderbufferStorage (target, internalformat, width, height);

}

void glGetRenderbufferParameteriv (GLenum target, GLenum pname, GLint *params){
 TglGetRenderbufferParameteriv (target, pname, params);

}

GLboolean glIsFramebuffer (GLuint framebuffer){
 return TglIsFramebuffer (framebuffer);

}

void glBindFramebuffer (GLenum target, GLuint framebuffer){
 TglBindFramebuffer (target, framebuffer);

}

void glDeleteFramebuffers (GLsizei n, const GLuint *framebuffers){
 TglDeleteFramebuffers (n, framebuffers);

}

void glGenFramebuffers (GLsizei n, GLuint *framebuffers){
 TglGenFramebuffers (n, framebuffers);

}

GLenum glCheckFramebufferStatus (GLenum target){
 return TglCheckFramebufferStatus (target);

}

void glFramebufferTexture1D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level){
 TglFramebufferTexture1D (target, attachment, textarget, texture, level);

}

void glFramebufferTexture2D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level){
 TglFramebufferTexture2D (target, attachment, textarget, texture, level);

}

void glFramebufferTexture3D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level, GLint zoffset){
 TglFramebufferTexture3D (target, attachment, textarget, texture, level, zoffset);

}

void glFramebufferRenderbuffer (GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer){
 TglFramebufferRenderbuffer (target, attachment, renderbuffertarget, renderbuffer);

}

void glGetFramebufferAttachmentParameteriv (GLenum target, GLenum attachment, GLenum pname, GLint *params){
 TglGetFramebufferAttachmentParameteriv (target, attachment, pname, params);

}

void glGenerateMipmap (GLenum target){
 TglGenerateMipmap (target);

}

void glBlitFramebuffer (GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter){
 TglBlitFramebuffer (srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);

}

void glRenderbufferStorageMultisample (GLenum target, GLsizei samples, GLenum internalformat, GLsizei width, GLsizei height){
 TglRenderbufferStorageMultisample (target, samples, internalformat, width, height);

}

void glFramebufferTextureLayer (GLenum target, GLenum attachment, GLuint texture, GLint level, GLint layer){
 TglFramebufferTextureLayer (target, attachment, texture, level, layer);

}

void *glMapBufferRange (GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access){
 return TglMapBufferRange (target, offset, length, access);

}

void glFlushMappedBufferRange (GLenum target, GLintptr offset, GLsizeiptr length){
 TglFlushMappedBufferRange (target, offset, length);

}

void glBindVertexArray (GLuint array){
 TglBindVertexArray (array);

}

void glDeleteVertexArrays (GLsizei n, const GLuint *arrays){
 TglDeleteVertexArrays (n, arrays);

}

void glGenVertexArrays (GLsizei n, GLuint *arrays){
 TglGenVertexArrays (n, arrays);

}

GLboolean glIsVertexArray (GLuint array){
 return TglIsVertexArray (array);

}






                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            