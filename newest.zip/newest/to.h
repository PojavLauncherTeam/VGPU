// OpenGL 2.0 >> 3.0

// Simplified version of the header file


#define TGLAPI extern


/* glcorearb.h is for use with OpenGL core profile implementations.
** It should should be placed in the same directory as gl.h and
** included as <GL/glcorearb.h>.
**
** glcorearb.h includes only APIs in the latest OpenGL core profile
** implementation together with APIs in newer ARB extensions which 
** can be supported by the core profile. It does not, and never will
** include functionality removed from the core profile, such as
** fixed-function vertex and fragment processing.
**
** Do not #include both <GL/glcorearb.h> and either of <GL/gl.h> or
** <GL/glext.h> in the same source file.
*/

/* Generated C header for:
 * API: gl
 * Profile: core
 * Versions considered: .*
 * Versions emitted: .*
 * Default extensions included: glcore
 * Additional extensions included: _nomatch_^
 * Extensions removed: _nomatch_^
 */


// GL_VERSION_1_0
typedef void TGLvoid;
typedef unsigned int TGLenum;
#include <KHR/khrplatform.h>
typedef khronos_float_t TGLfloat;
typedef int TGLint;
typedef int TGLsizei;
typedef unsigned int TGLbitfield;
typedef double TGLdouble;
typedef unsigned int TGLuint;
typedef unsigned char TGLboolean;
typedef khronos_uint8_t TGLubyte;
#define TGL_DEPTH_BUFFER_BIT               0x00000100
#define TGL_STENCIL_BUFFER_BIT             0x00000400
#define TGL_COLOR_BUFFER_BIT               0x00004000
#define TGL_FALSE                          0
#define TGL_TRUE                           1
#define TGL_POINTS                         0x0000
#define TGL_LINES                          0x0001
#define TGL_LINE_LOOP                      0x0002
#define TGL_LINE_STRIP                     0x0003
#define TGL_TRIANTGLES                      0x0004
#define TGL_TRIANTGLE_STRIP                 0x0005
#define TGL_TRIANTGLE_FAN                   0x0006
#define TGL_QUADS                          0x0007
#define TGL_NEVER                          0x0200
#define TGL_LESS                           0x0201
#define TGL_EQUAL                          0x0202
#define TGL_LEQUAL                         0x0203
#define TGL_GREATER                        0x0204
#define TGL_NOTEQUAL                       0x0205
#define TGL_GEQUAL                         0x0206
#define TGL_ALWAYS                         0x0207
#define TGL_ZERO                           0
#define TGL_ONE                            1
#define TGL_SRC_COLOR                      0x0300
#define TGL_ONE_MINUS_SRC_COLOR            0x0301
#define TGL_SRC_ALPHA                      0x0302
#define TGL_ONE_MINUS_SRC_ALPHA            0x0303
#define TGL_DST_ALPHA                      0x0304
#define TGL_ONE_MINUS_DST_ALPHA            0x0305
#define TGL_DST_COLOR                      0x0306
#define TGL_ONE_MINUS_DST_COLOR            0x0307
#define TGL_SRC_ALPHA_SATURATE             0x0308
#define TGL_NONE                           0
#define TGL_FRONT_LEFT                     0x0400
#define TGL_FRONT_RIGHT                    0x0401
#define TGL_BACK_LEFT                      0x0402
#define TGL_BACK_RIGHT                     0x0403
#define TGL_FRONT                          0x0404
#define TGL_BACK                           0x0405
#define TGL_LEFT                           0x0406
#define TGL_RIGHT                          0x0407
#define TGL_FRONT_AND_BACK                 0x0408
#define TGL_NO_ERROR                       0
#define TGL_INVALID_ENUM                   0x0500
#define TGL_INVALID_VALUE                  0x0501
#define TGL_INVALID_OPERATION              0x0502
#define TGL_OUT_OF_MEMORY                  0x0505
#define TGL_CW                             0x0900
#define TGL_CCW                            0x0901
#define TGL_POINT_SIZE                     0x0B11
#define TGL_POINT_SIZE_RANGE               0x0B12
#define TGL_POINT_SIZE_GRANULARITY         0x0B13
#define TGL_LINE_SMOOTH                    0x0B20
#define TGL_LINE_WIDTH                     0x0B21
#define TGL_LINE_WIDTH_RANGE               0x0B22
#define TGL_LINE_WIDTH_GRANULARITY         0x0B23
#define TGL_POLYGON_MODE                   0x0B40
#define TGL_POLYGON_SMOOTH                 0x0B41
#define TGL_CULL_FACE                      0x0B44
#define TGL_CULL_FACE_MODE                 0x0B45
#define TGL_FRONT_FACE                     0x0B46
#define TGL_DEPTH_RANGE                    0x0B70
#define TGL_DEPTH_TEST                     0x0B71
#define TGL_DEPTH_WRITEMASK                0x0B72
#define TGL_DEPTH_CLEAR_VALUE              0x0B73
#define TGL_DEPTH_FUNC                     0x0B74
#define TGL_STENCIL_TEST                   0x0B90
#define TGL_STENCIL_CLEAR_VALUE            0x0B91
#define TGL_STENCIL_FUNC                   0x0B92
#define TGL_STENCIL_VALUE_MASK             0x0B93
#define TGL_STENCIL_FAIL                   0x0B94
#define TGL_STENCIL_PASS_DEPTH_FAIL        0x0B95
#define TGL_STENCIL_PASS_DEPTH_PASS        0x0B96
#define TGL_STENCIL_REF                    0x0B97
#define TGL_STENCIL_WRITEMASK              0x0B98
#define TGL_VIEWPORT                       0x0BA2
#define TGL_DITHER                         0x0BD0
#define TGL_BLEND_DST                      0x0BE0
#define TGL_BLEND_SRC                      0x0BE1
#define TGL_BLEND                          0x0BE2
#define TGL_LOGIC_OP_MODE                  0x0BF0
#define TGL_DRAW_BUFFER                    0x0C01
#define TGL_READ_BUFFER                    0x0C02
#define TGL_SCISSOR_BOX                    0x0C10
#define TGL_SCISSOR_TEST                   0x0C11
#define TGL_COLOR_CLEAR_VALUE              0x0C22
#define TGL_COLOR_WRITEMASK                0x0C23
#define TGL_DOUBLEBUFFER                   0x0C32
#define TGL_STEREO                         0x0C33
#define TGL_LINE_SMOOTH_HINT               0x0C52
#define TGL_POLYGON_SMOOTH_HINT            0x0C53
#define TGL_UNPACK_SWAP_BYTES              0x0CF0
#define TGL_UNPACK_LSB_FIRST               0x0CF1
#define TGL_UNPACK_ROW_LENGTH              0x0CF2
#define TGL_UNPACK_SKIP_ROWS               0x0CF3
#define TGL_UNPACK_SKIP_PIXELS             0x0CF4
#define TGL_UNPACK_ALIGNMENT               0x0CF5
#define TGL_PACK_SWAP_BYTES                0x0D00
#define TGL_PACK_LSB_FIRST                 0x0D01
#define TGL_PACK_ROW_LENGTH                0x0D02
#define TGL_PACK_SKIP_ROWS                 0x0D03
#define TGL_PACK_SKIP_PIXELS               0x0D04
#define TGL_PACK_ALIGNMENT                 0x0D05
#define TGL_MAX_TEXTURE_SIZE               0x0D33
#define TGL_MAX_VIEWPORT_DIMS              0x0D3A
#define TGL_SUBPIXEL_BITS                  0x0D50
#define TGL_TEXTURE_1D                     0x0DE0
#define TGL_TEXTURE_2D                     0x0DE1
#define TGL_TEXTURE_WIDTH                  0x1000
#define TGL_TEXTURE_HEIGHT                 0x1001
#define TGL_TEXTURE_BORDER_COLOR           0x1004
#define TGL_DONT_CARE                      0x1100
#define TGL_FASTEST                        0x1101
#define TGL_NICEST                         0x1102
#define TGL_BYTE                           0x1400
#define TGL_UNSIGNED_BYTE                  0x1401
#define TGL_SHORT                          0x1402
#define TGL_UNSIGNED_SHORT                 0x1403
#define TGL_INT                            0x1404
#define TGL_UNSIGNED_INT                   0x1405
#define TGL_FLOAT                          0x1406
#define TGL_STACK_OVERFLOW                 0x0503
#define TGL_STACK_UNDERFLOW                0x0504
#define TGL_CLEAR                          0x1500
#define TGL_AND                            0x1501
#define TGL_AND_REVERSE                    0x1502
#define TGL_COPY                           0x1503
#define TGL_AND_INVERTED                   0x1504
#define TGL_NOOP                           0x1505
#define TGL_XOR                            0x1506
#define TGL_OR                             0x1507
#define TGL_NOR                            0x1508
#define TGL_EQUIV                          0x1509
#define TGL_INVERT                         0x150A
#define TGL_OR_REVERSE                     0x150B
#define TGL_COPY_INVERTED                  0x150C
#define TGL_OR_INVERTED                    0x150D
#define TGL_NAND                           0x150E
#define TGL_SET                            0x150F
#define TGL_TEXTURE                        0x1702
#define TGL_COLOR                          0x1800
#define TGL_DEPTH                          0x1801
#define TGL_STENCIL                        0x1802
#define TGL_STENCIL_INDEX                  0x1901
#define TGL_DEPTH_COMPONENT                0x1902
#define TGL_RED                            0x1903
#define TGL_GREEN                          0x1904
#define TGL_BLUE                           0x1905
#define TGL_ALPHA                          0x1906
#define TGL_RGB                            0x1907
#define TGL_RGBA                           0x1908
#define TGL_POINT                          0x1B00
#define TGL_LINE                           0x1B01
#define TGL_FILL                           0x1B02
#define TGL_KEEP                           0x1E00
#define TGL_REPLACE                        0x1E01
#define TGL_INCR                           0x1E02
#define TGL_DECR                           0x1E03
#define TGL_VENDOR                         0x1F00
#define TGL_RENDERER                       0x1F01
#define TGL_VERSION                        0x1F02
#define TGL_EXTENSIONS                     0x1F03
#define TGL_NEAREST                        0x2600
#define TGL_LINEAR                         0x2601
#define TGL_NEAREST_MIPMAP_NEAREST         0x2700
#define TGL_LINEAR_MIPMAP_NEAREST          0x2701
#define TGL_NEAREST_MIPMAP_LINEAR          0x2702
#define TGL_LINEAR_MIPMAP_LINEAR           0x2703
#define TGL_TEXTURE_MAG_FILTER             0x2800
#define TGL_TEXTURE_MIN_FILTER             0x2801
#define TGL_TEXTURE_WRAP_S                 0x2802
#define TGL_TEXTURE_WRAP_T                 0x2803
#define TGL_REPEAT                         0x2901

TGLAPI void TglCullFace (TGLenum mode);
TGLAPI void TglFrontFace (TGLenum mode);
TGLAPI void TglHint (TGLenum target, TGLenum mode);
TGLAPI void TglLineWidth (TGLfloat width);
TGLAPI void TglPointSize (TGLfloat size);
TGLAPI void TglPolygonMode (TGLenum face, TGLenum mode);
TGLAPI void TglScissor (TGLint x, TGLint y, TGLsizei width, TGLsizei height);
TGLAPI void TglTexParameterf (TGLenum target, TGLenum pname, TGLfloat param);
TGLAPI void TglTexParameterfv (TGLenum target, TGLenum pname, const TGLfloat *params);
TGLAPI void TglTexParameteri (TGLenum target, TGLenum pname, TGLint param);
TGLAPI void TglTexParameteriv (TGLenum target, TGLenum pname, const TGLint *params);
TGLAPI void TglTexImage1D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLint border, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglTexImage2D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLsizei height, TGLint border, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglDrawBuffer (TGLenum buf);
TGLAPI void TglClear (TGLbitfield mask);
TGLAPI void TglClearColor (TGLfloat red, TGLfloat green, TGLfloat blue, TGLfloat alpha);
TGLAPI void TglClearStencil (TGLint s);
TGLAPI void TglClearDepth (TGLdouble depth);
TGLAPI void TglStencilMask (TGLuint mask);
TGLAPI void TglColorMask (TGLboolean red, TGLboolean green, TGLboolean blue, TGLboolean alpha);
TGLAPI void TglDepthMask (TGLboolean flag);
TGLAPI void TglDisable (TGLenum cap);
TGLAPI void TglEnable (TGLenum cap);
TGLAPI void TglFinish (void);
TGLAPI void TglFlush (void);
TGLAPI void TglBlendFunc (TGLenum sfactor, TGLenum dfactor);
TGLAPI void TglLogicOp (TGLenum opcode);
TGLAPI void TglStencilFunc (TGLenum func, TGLint ref, TGLuint mask);
TGLAPI void TglStencilOp (TGLenum fail, TGLenum zfail, TGLenum zpass);
TGLAPI void TglDepthFunc (TGLenum func);
TGLAPI void TglPixelStoref (TGLenum pname, TGLfloat param);
TGLAPI void TglPixelStorei (TGLenum pname, TGLint param);
TGLAPI void TglReadBuffer (TGLenum src);
TGLAPI void TglReadPixels (TGLint x, TGLint y, TGLsizei width, TGLsizei height, TGLenum format, TGLenum type, void *pixels);
TGLAPI void TglGetBooleanv (TGLenum pname, TGLboolean *data);
TGLAPI void TglGetDoublev (TGLenum pname, TGLdouble *data);
TGLAPI TGLenum TglGetError (void);
TGLAPI void TglGetFloatv (TGLenum pname, TGLfloat *data);
TGLAPI void TglGetIntegerv (TGLenum pname, TGLint *data);
TGLAPI const TGLubyte *TglGetString (TGLenum name);
TGLAPI void TglGetTexImage (TGLenum target, TGLint level, TGLenum format, TGLenum type, void *pixels);
TGLAPI void TglGetTexParameterfv (TGLenum target, TGLenum pname, TGLfloat *params);
TGLAPI void TglGetTexParameteriv (TGLenum target, TGLenum pname, TGLint *params);
TGLAPI void TglGetTexLevelParameterfv (TGLenum target, TGLint level, TGLenum pname, TGLfloat *params);
TGLAPI void TglGetTexLevelParameteriv (TGLenum target, TGLint level, TGLenum pname, TGLint *params);
TGLAPI TGLboolean TglIsEnabled (TGLenum cap);
TGLAPI void TglDepthRange (TGLdouble n, TGLdouble f);
TGLAPI void TglViewport (TGLint x, TGLint y, TGLsizei width, TGLsizei height);


// GL_VERSION_1_1
typedef khronos_float_t TGLclampf;
typedef double TGLclampd;
#define TGL_COLOR_LOGIC_OP                 0x0BF2
#define TGL_POLYGON_OFFSET_UNITS           0x2A00
#define TGL_POLYGON_OFFSET_POINT           0x2A01
#define TGL_POLYGON_OFFSET_LINE            0x2A02
#define TGL_POLYGON_OFFSET_FILL            0x8037
#define TGL_POLYGON_OFFSET_FACTOR          0x8038
#define TGL_TEXTURE_BINDING_1D             0x8068
#define TGL_TEXTURE_BINDING_2D             0x8069
#define TGL_TEXTURE_INTERNAL_FORMAT        0x1003
#define TGL_TEXTURE_RED_SIZE               0x805C
#define TGL_TEXTURE_GREEN_SIZE             0x805D
#define TGL_TEXTURE_BLUE_SIZE              0x805E
#define TGL_TEXTURE_ALPHA_SIZE             0x805F
#define TGL_DOUBLE                         0x140A
#define TGL_PROXY_TEXTURE_1D               0x8063
#define TGL_PROXY_TEXTURE_2D               0x8064
#define TGL_R3_G3_B2                       0x2A10
#define TGL_RGB4                           0x804F
#define TGL_RGB5                           0x8050
#define TGL_RGB8                           0x8051
#define TGL_RGB10                          0x8052
#define TGL_RGB12                          0x8053
#define TGL_RGB16                          0x8054
#define TGL_RGBA2                          0x8055
#define TGL_RGBA4                          0x8056
#define TGL_RGB5_A1                        0x8057
#define TGL_RGBA8                          0x8058
#define TGL_RGB10_A2                       0x8059
#define TGL_RGBA12                         0x805A
#define TGL_RGBA16                         0x805B
#define TGL_VERTEX_ARRAY                   0x8074

TGLAPI void TglDrawArrays (TGLenum mode, TGLint first, TGLsizei count);
TGLAPI void TglDrawElements (TGLenum mode, TGLsizei count, TGLenum type, const void *indices);
TGLAPI void TglGetPointerv (TGLenum pname, void **params);
TGLAPI void TglPolygonOffset (TGLfloat factor, TGLfloat units);
TGLAPI void TglCopyTexImage1D (TGLenum target, TGLint level, TGLenum internalformat, TGLint x, TGLint y, TGLsizei width, TGLint border);
TGLAPI void TglCopyTexImage2D (TGLenum target, TGLint level, TGLenum internalformat, TGLint x, TGLint y, TGLsizei width, TGLsizei height, TGLint border);
TGLAPI void TglCopyTexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLint x, TGLint y, TGLsizei width);
TGLAPI void TglCopyTexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint x, TGLint y, TGLsizei width, TGLsizei height);
TGLAPI void TglTexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLsizei width, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglTexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLsizei width, TGLsizei height, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglBindTexture (TGLenum target, TGLuint texture);
TGLAPI void TglDeleteTextures (TGLsizei n, const TGLuint *textures);
TGLAPI void TglGenTextures (TGLsizei n, TGLuint *textures);
TGLAPI TGLboolean TglIsTexture (TGLuint texture);


// GL_VERSION_1_2
#define TGL_UNSIGNED_BYTE_3_3_2            0x8032
#define TGL_UNSIGNED_SHORT_4_4_4_4         0x8033
#define TGL_UNSIGNED_SHORT_5_5_5_1         0x8034
#define TGL_UNSIGNED_INT_8_8_8_8           0x8035
#define TGL_UNSIGNED_INT_10_10_10_2        0x8036
#define TGL_TEXTURE_BINDING_3D             0x806A
#define TGL_PACK_SKIP_IMAGES               0x806B
#define TGL_PACK_IMAGE_HEIGHT              0x806C
#define TGL_UNPACK_SKIP_IMAGES             0x806D
#define TGL_UNPACK_IMAGE_HEIGHT            0x806E
#define TGL_TEXTURE_3D                     0x806F
#define TGL_PROXY_TEXTURE_3D               0x8070
#define TGL_TEXTURE_DEPTH                  0x8071
#define TGL_TEXTURE_WRAP_R                 0x8072
#define TGL_MAX_3D_TEXTURE_SIZE            0x8073
#define TGL_UNSIGNED_BYTE_2_3_3_REV        0x8362
#define TGL_UNSIGNED_SHORT_5_6_5           0x8363
#define TGL_UNSIGNED_SHORT_5_6_5_REV       0x8364
#define TGL_UNSIGNED_SHORT_4_4_4_4_REV     0x8365
#define TGL_UNSIGNED_SHORT_1_5_5_5_REV     0x8366
#define TGL_UNSIGNED_INT_8_8_8_8_REV       0x8367
#define TGL_UNSIGNED_INT_2_10_10_10_REV    0x8368
#define TGL_BGR                            0x80E0
#define TGL_BGRA                           0x80E1
#define TGL_MAX_ELEMENTS_VERTICES          0x80E8
#define TGL_MAX_ELEMENTS_INDICES           0x80E9
#define TGL_CLAMP_TO_EDGE                  0x812F
#define TGL_TEXTURE_MIN_LOD                0x813A
#define TGL_TEXTURE_MAX_LOD                0x813B
#define TGL_TEXTURE_BASE_LEVEL             0x813C
#define TGL_TEXTURE_MAX_LEVEL              0x813D
#define TGL_SMOOTH_POINT_SIZE_RANGE        0x0B12
#define TGL_SMOOTH_POINT_SIZE_GRANULARITY  0x0B13
#define TGL_SMOOTH_LINE_WIDTH_RANGE        0x0B22
#define TGL_SMOOTH_LINE_WIDTH_GRANULARITY  0x0B23
#define TGL_ALIASED_LINE_WIDTH_RANGE       0x846E

TGLAPI void TglDrawRangeElements (TGLenum mode, TGLuint start, TGLuint end, TGLsizei count, TGLenum type, const void *indices);
TGLAPI void TglTexImage3D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLsizei height, TGLsizei depth, TGLint border, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglTexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLsizei width, TGLsizei height, TGLsizei depth, TGLenum format, TGLenum type, const void *pixels);
TGLAPI void TglCopyTexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLint x, TGLint y, TGLsizei width, TGLsizei height);


// GL_VERSION_1_3
#define TGL_TEXTURE0                       0x84C0
#define TGL_TEXTURE1                       0x84C1
#define TGL_TEXTURE2                       0x84C2
#define TGL_TEXTURE3                       0x84C3
#define TGL_TEXTURE4                       0x84C4
#define TGL_TEXTURE5                       0x84C5
#define TGL_TEXTURE6                       0x84C6
#define TGL_TEXTURE7                       0x84C7
#define TGL_TEXTURE8                       0x84C8
#define TGL_TEXTURE9                       0x84C9
#define TGL_TEXTURE10                      0x84CA
#define TGL_TEXTURE11                      0x84CB
#define TGL_TEXTURE12                      0x84CC
#define TGL_TEXTURE13                      0x84CD
#define TGL_TEXTURE14                      0x84CE
#define TGL_TEXTURE15                      0x84CF
#define TGL_TEXTURE16                      0x84D0
#define TGL_TEXTURE17                      0x84D1
#define TGL_TEXTURE18                      0x84D2
#define TGL_TEXTURE19                      0x84D3
#define TGL_TEXTURE20                      0x84D4
#define TGL_TEXTURE21                      0x84D5
#define TGL_TEXTURE22                      0x84D6
#define TGL_TEXTURE23                      0x84D7
#define TGL_TEXTURE24                      0x84D8
#define TGL_TEXTURE25                      0x84D9
#define TGL_TEXTURE26                      0x84DA
#define TGL_TEXTURE27                      0x84DB
#define TGL_TEXTURE28                      0x84DC
#define TGL_TEXTURE29                      0x84DD
#define TGL_TEXTURE30                      0x84DE
#define TGL_TEXTURE31                      0x84DF
#define TGL_ACTIVE_TEXTURE                 0x84E0
#define TGL_MULTISAMPLE                    0x809D
#define TGL_SAMPLE_ALPHA_TO_COVERAGE       0x809E
#define TGL_SAMPLE_ALPHA_TO_ONE            0x809F
#define TGL_SAMPLE_COVERAGE                0x80A0
#define TGL_SAMPLE_BUFFERS                 0x80A8
#define TGL_SAMPLES                        0x80A9
#define TGL_SAMPLE_COVERAGE_VALUE          0x80AA
#define TGL_SAMPLE_COVERAGE_INVERT         0x80AB
#define TGL_TEXTURE_CUBE_MAP               0x8513
#define TGL_TEXTURE_BINDING_CUBE_MAP       0x8514
#define TGL_TEXTURE_CUBE_MAP_POSITIVE_X    0x8515
#define TGL_TEXTURE_CUBE_MAP_NEGATIVE_X    0x8516
#define TGL_TEXTURE_CUBE_MAP_POSITIVE_Y    0x8517
#define TGL_TEXTURE_CUBE_MAP_NEGATIVE_Y    0x8518
#define TGL_TEXTURE_CUBE_MAP_POSITIVE_Z    0x8519
#define TGL_TEXTURE_CUBE_MAP_NEGATIVE_Z    0x851A
#define TGL_PROXY_TEXTURE_CUBE_MAP         0x851B
#define TGL_MAX_CUBE_MAP_TEXTURE_SIZE      0x851C
#define TGL_COMPRESSED_RGB                 0x84ED
#define TGL_COMPRESSED_RGBA                0x84EE
#define TGL_TEXTURE_COMPRESSION_HINT       0x84EF
#define TGL_TEXTURE_COMPRESSED_IMAGE_SIZE  0x86A0
#define TGL_TEXTURE_COMPRESSED             0x86A1
#define TGL_NUM_COMPRESSED_TEXTURE_FORMATS 0x86A2
#define TGL_COMPRESSED_TEXTURE_FORMATS     0x86A3
#define TGL_CLAMP_TO_BORDER                0x812D

TGLAPI void TglActiveTexture (TGLenum texture);
TGLAPI void TglSampleCoverage (TGLfloat value, TGLboolean invert);
TGLAPI void TglCompressedTexImage3D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLsizei height, TGLsizei depth, TGLint border, TGLsizei imageSize, const void *data);
TGLAPI void TglCompressedTexImage2D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLsizei height, TGLint border, TGLsizei imageSize, const void *data);
TGLAPI void TglCompressedTexImage1D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLint border, TGLsizei imageSize, const void *data);
TGLAPI void TglCompressedTexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLsizei width, TGLsizei height, TGLsizei depth, TGLenum format, TGLsizei imageSize, const void *data);
TGLAPI void TglCompressedTexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLsizei width, TGLsizei height, TGLenum format, TGLsizei imageSize, const void *data);
TGLAPI void TglCompressedTexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLsizei width, TGLenum format, TGLsizei imageSize, const void *data);
TGLAPI void TglGetCompressedTexImage (TGLenum target, TGLint level, void *img);


// GL_VERSION_1_4
#define TGL_BLEND_DST_RGB                  0x80C8
#define TGL_BLEND_SRC_RGB                  0x80C9
#define TGL_BLEND_DST_ALPHA                0x80CA
#define TGL_BLEND_SRC_ALPHA                0x80CB
#define TGL_POINT_FADE_THRESHOLD_SIZE      0x8128
#define TGL_DEPTH_COMPONENT16              0x81A5
#define TGL_DEPTH_COMPONENT24              0x81A6
#define TGL_DEPTH_COMPONENT32              0x81A7
#define TGL_MIRRORED_REPEAT                0x8370
#define TGL_MAX_TEXTURE_LOD_BIAS           0x84FD
#define TGL_TEXTURE_LOD_BIAS               0x8501
#define TGL_INCR_WRAP                      0x8507
#define TGL_DECR_WRAP                      0x8508
#define TGL_TEXTURE_DEPTH_SIZE             0x884A
#define TGL_TEXTURE_COMPARE_MODE           0x884C
#define TGL_TEXTURE_COMPARE_FUNC           0x884D
#define TGL_BLEND_COLOR                    0x8005
#define TGL_BLEND_EQUATION                 0x8009
#define TGL_CONSTANT_COLOR                 0x8001
#define TGL_ONE_MINUS_CONSTANT_COLOR       0x8002
#define TGL_CONSTANT_ALPHA                 0x8003
#define TGL_ONE_MINUS_CONSTANT_ALPHA       0x8004
#define TGL_FUNC_ADD                       0x8006
#define TGL_FUNC_REVERSE_SUBTRACT          0x800B
#define TGL_FUNC_SUBTRACT                  0x800A
#define TGL_MIN                            0x8007
#define TGL_MAX                            0x8008

TGLAPI void TglBlendFuncSeparate (TGLenum sfactorRGB, TGLenum dfactorRGB, TGLenum sfactorAlpha, TGLenum dfactorAlpha);
TGLAPI void TglMultiDrawArrays (TGLenum mode, const TGLint *first, const TGLsizei *count, TGLsizei drawcount);
TGLAPI void TglMultiDrawElements (TGLenum mode, const TGLsizei *count, TGLenum type, const void *const*indices, TGLsizei drawcount);
TGLAPI void TglPointParameterf (TGLenum pname, TGLfloat param);
TGLAPI void TglPointParameterfv (TGLenum pname, const TGLfloat *params);
TGLAPI void TglPointParameteri (TGLenum pname, TGLint param);
TGLAPI void TglPointParameteriv (TGLenum pname, const TGLint *params);
TGLAPI void TglBlendColor (TGLfloat red, TGLfloat green, TGLfloat blue, TGLfloat alpha);
TGLAPI void TglBlendEquation (TGLenum mode);


// GL_VERSION_1_5
typedef khronos_ssize_t TGLsizeiptr;
typedef khronos_intptr_t TGLintptr;
#define TGL_BUFFER_SIZE                    0x8764
#define TGL_BUFFER_USAGE                   0x8765
#define TGL_QUERY_COUNTER_BITS             0x8864
#define TGL_CURRENT_QUERY                  0x8865
#define TGL_QUERY_RESULT                   0x8866
#define TGL_QUERY_RESULT_AVAILABLE         0x8867
#define TGL_ARRAY_BUFFER                   0x8892
#define TGL_ELEMENT_ARRAY_BUFFER           0x8893
#define TGL_ARRAY_BUFFER_BINDING           0x8894
#define TGL_ELEMENT_ARRAY_BUFFER_BINDING   0x8895
#define TGL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING 0x889F
#define TGL_READ_ONLY                      0x88B8
#define TGL_WRITE_ONLY                     0x88B9
#define TGL_READ_WRITE                     0x88BA
#define TGL_BUFFER_ACCESS                  0x88BB
#define TGL_BUFFER_MAPPED                  0x88BC
#define TGL_BUFFER_MAP_POINTER             0x88BD
#define TGL_STREAM_DRAW                    0x88E0
#define TGL_STREAM_READ                    0x88E1
#define TGL_STREAM_COPY                    0x88E2
#define TGL_STATIC_DRAW                    0x88E4
#define TGL_STATIC_READ                    0x88E5
#define TGL_STATIC_COPY                    0x88E6
#define TGL_DYNAMIC_DRAW                   0x88E8
#define TGL_DYNAMIC_READ                   0x88E9
#define TGL_DYNAMIC_COPY                   0x88EA
#define TGL_SAMPLES_PASSED                 0x8914
#define TGL_SRC1_ALPHA                     0x8589

TGLAPI void TglGenQueries (TGLsizei n, TGLuint *ids);
TGLAPI void TglDeleteQueries (TGLsizei n, const TGLuint *ids);
TGLAPI TGLboolean TglIsQuery (TGLuint id);
TGLAPI void TglBeginQuery (TGLenum target, TGLuint id);
TGLAPI void TglEndQuery (TGLenum target);
TGLAPI void TglGetQueryiv (TGLenum target, TGLenum pname, TGLint *params);
TGLAPI void TglGetQueryObjectiv (TGLuint id, TGLenum pname, TGLint *params);
TGLAPI void TglGetQueryObjectuiv (TGLuint id, TGLenum pname, TGLuint *params);
TGLAPI void TglBindBuffer (TGLenum target, TGLuint buffer);
TGLAPI void TglDeleteBuffers (TGLsizei n, const TGLuint *buffers);
TGLAPI void TglGenBuffers (TGLsizei n, TGLuint *buffers);
TGLAPI TGLboolean TglIsBuffer (TGLuint buffer);
TGLAPI void TglBufferData (TGLenum target, TGLsizeiptr size, const void *data, TGLenum usage);
TGLAPI void TglBufferSubData (TGLenum target, TGLintptr offset, TGLsizeiptr size, const void *data);
TGLAPI void TglGetBufferSubData (TGLenum target, TGLintptr offset, TGLsizeiptr size, void *data);
TGLAPI void *TglMapBuffer (TGLenum target, TGLenum access);
TGLAPI TGLboolean TglUnmapBuffer (TGLenum target);
TGLAPI void TglGetBufferParameteriv (TGLenum target, TGLenum pname, TGLint *params);
TGLAPI void TglGetBufferPointerv (TGLenum target, TGLenum pname, void **params);


// GL_VERSION_2_0
typedef char TGLchar;
typedef khronos_int16_t TGLshort;
typedef khronos_int8_t TGLbyte;
typedef khronos_uint16_t TGLushort;
#define TGL_BLEND_EQUATION_RGB             0x8009
#define TGL_VERTEX_ATTRIB_ARRAY_ENABLED    0x8622
#define TGL_VERTEX_ATTRIB_ARRAY_SIZE       0x8623
#define TGL_VERTEX_ATTRIB_ARRAY_STRIDE     0x8624
#define TGL_VERTEX_ATTRIB_ARRAY_TYPE       0x8625
#define TGL_CURRENT_VERTEX_ATTRIB          0x8626
#define TGL_VERTEX_PROGRAM_POINT_SIZE      0x8642
#define TGL_VERTEX_ATTRIB_ARRAY_POINTER    0x8645
#define TGL_STENCIL_BACK_FUNC              0x8800
#define TGL_STENCIL_BACK_FAIL              0x8801
#define TGL_STENCIL_BACK_PASS_DEPTH_FAIL   0x8802
#define TGL_STENCIL_BACK_PASS_DEPTH_PASS   0x8803
#define TGL_MAX_DRAW_BUFFERS               0x8824
#define TGL_DRAW_BUFFER0                   0x8825
#define TGL_DRAW_BUFFER1                   0x8826
#define TGL_DRAW_BUFFER2                   0x8827
#define TGL_DRAW_BUFFER3                   0x8828
#define TGL_DRAW_BUFFER4                   0x8829
#define TGL_DRAW_BUFFER5                   0x882A
#define TGL_DRAW_BUFFER6                   0x882B
#define TGL_DRAW_BUFFER7                   0x882C
#define TGL_DRAW_BUFFER8                   0x882D
#define TGL_DRAW_BUFFER9                   0x882E
#define TGL_DRAW_BUFFER10                  0x882F
#define TGL_DRAW_BUFFER11                  0x8830
#define TGL_DRAW_BUFFER12                  0x8831
#define TGL_DRAW_BUFFER13                  0x8832
#define TGL_DRAW_BUFFER14                  0x8833
#define TGL_DRAW_BUFFER15                  0x8834
#define TGL_BLEND_EQUATION_ALPHA           0x883D
#define TGL_MAX_VERTEX_ATTRIBS             0x8869
#define TGL_VERTEX_ATTRIB_ARRAY_NORMALIZED 0x886A
#define TGL_MAX_TEXTURE_IMAGE_UNITS        0x8872
#define TGL_FRAGMENT_SHADER                0x8B30
#define TGL_VERTEX_SHADER                  0x8B31
#define TGL_MAX_FRAGMENT_UNIFORM_COMPONENTS 0x8B49
#define TGL_MAX_VERTEX_UNIFORM_COMPONENTS  0x8B4A
#define TGL_MAX_VARYING_FLOATS             0x8B4B
#define TGL_MAX_VERTEX_TEXTURE_IMAGE_UNITS 0x8B4C
#define TGL_MAX_COMBINED_TEXTURE_IMAGE_UNITS 0x8B4D
#define TGL_SHADER_TYPE                    0x8B4F
#define TGL_FLOAT_VEC2                     0x8B50
#define TGL_FLOAT_VEC3                     0x8B51
#define TGL_FLOAT_VEC4                     0x8B52
#define TGL_INT_VEC2                       0x8B53
#define TGL_INT_VEC3                       0x8B54
#define TGL_INT_VEC4                       0x8B55
#define TGL_BOOL                           0x8B56
#define TGL_BOOL_VEC2                      0x8B57
#define TGL_BOOL_VEC3                      0x8B58
#define TGL_BOOL_VEC4                      0x8B59
#define TGL_FLOAT_MAT2                     0x8B5A
#define TGL_FLOAT_MAT3                     0x8B5B
#define TGL_FLOAT_MAT4                     0x8B5C
#define TGL_SAMPLER_1D                     0x8B5D
#define TGL_SAMPLER_2D                     0x8B5E
#define TGL_SAMPLER_3D                     0x8B5F
#define TGL_SAMPLER_CUBE                   0x8B60
#define TGL_SAMPLER_1D_SHADOW              0x8B61
#define TGL_SAMPLER_2D_SHADOW              0x8B62
#define TGL_DELETE_STATUS                  0x8B80
#define TGL_COMPILE_STATUS                 0x8B81
#define TGL_LINK_STATUS                    0x8B82
#define TGL_VALIDATE_STATUS                0x8B83
#define TGL_INFO_LOG_LENGTH                0x8B84
#define TGL_ATTACHED_SHADERS               0x8B85
#define TGL_ACTIVE_UNIFORMS                0x8B86
#define TGL_ACTIVE_UNIFORM_MAX_LENGTH      0x8B87
#define TGL_SHADER_SOURCE_LENGTH           0x8B88
#define TGL_ACTIVE_ATTRIBUTES              0x8B89
#define TGL_ACTIVE_ATTRIBUTE_MAX_LENGTH    0x8B8A
#define TGL_FRAGMENT_SHADER_DERIVATIVE_HINT 0x8B8B
#define TGL_SHADING_LANGUAGE_VERSION       0x8B8C
#define TGL_CURRENT_PROGRAM                0x8B8D
#define TGL_POINT_SPRITE_COORD_ORIGIN      0x8CA0
#define TGL_LOWER_LEFT                     0x8CA1
#define TGL_UPPER_LEFT                     0x8CA2
#define TGL_STENCIL_BACK_REF               0x8CA3
#define TGL_STENCIL_BACK_VALUE_MASK        0x8CA4
#define TGL_STENCIL_BACK_WRITEMASK         0x8CA5

TGLAPI void TglBlendEquationSeparate (TGLenum modeRGB, TGLenum modeAlpha);
TGLAPI void TglDrawBuffers (TGLsizei n, const TGLenum *bufs);
TGLAPI void TglStencilOpSeparate (TGLenum face, TGLenum sfail, TGLenum dpfail, TGLenum dppass);
TGLAPI void TglStencilFuncSeparate (TGLenum face, TGLenum func, TGLint ref, TGLuint mask);
TGLAPI void TglStencilMaskSeparate (TGLenum face, TGLuint mask);
TGLAPI void TglAttachShader (TGLuint program, TGLuint shader);
TGLAPI void TglBindAttribLocation (TGLuint program, TGLuint index, const TGLchar *name);
TGLAPI void TglCompileShader (TGLuint shader);
TGLAPI TGLuint TglCreateProgram (void);
TGLAPI TGLuint TglCreateShader (TGLenum type);
TGLAPI void TglDeleteProgram (TGLuint program);
TGLAPI void TglDeleteShader (TGLuint shader);
TGLAPI void TglDetachShader (TGLuint program, TGLuint shader);
TGLAPI void TglDisableVertexAttribArray (TGLuint index);
TGLAPI void TglEnableVertexAttribArray (TGLuint index);
TGLAPI void TglGetActiveAttrib (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLint *size, TGLenum *type, TGLchar *name);
TGLAPI void TglGetActiveUniform (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLint *size, TGLenum *type, TGLchar *name);
TGLAPI void TglGetAttachedShaders (TGLuint program, TGLsizei maxCount, TGLsizei *count, TGLuint *shaders);
TGLAPI TGLint TglGetAttribLocation (TGLuint program, const TGLchar *name);
TGLAPI void TglGetProgramiv (TGLuint program, TGLenum pname, TGLint *params);
TGLAPI void TglGetProgramInfoLog (TGLuint program, TGLsizei bufSize, TGLsizei *length, TGLchar *infoLog);
TGLAPI void TglGetShaderiv (TGLuint shader, TGLenum pname, TGLint *params);
TGLAPI void TglGetShaderInfoLog (TGLuint shader, TGLsizei bufSize, TGLsizei *length, TGLchar *infoLog);
TGLAPI void TglGetShaderSource (TGLuint shader, TGLsizei bufSize, TGLsizei *length, TGLchar *source);
TGLAPI TGLint TglGetUniformLocation (TGLuint program, const TGLchar *name);
TGLAPI void TglGetUniformfv (TGLuint program, TGLint location, TGLfloat *params);
TGLAPI void TglGetUniformiv (TGLuint program, TGLint location, TGLint *params);
TGLAPI void TglGetVertexAttribdv (TGLuint index, TGLenum pname, TGLdouble *params);
TGLAPI void TglGetVertexAttribfv (TGLuint index, TGLenum pname, TGLfloat *params);
TGLAPI void TglGetVertexAttribiv (TGLuint index, TGLenum pname, TGLint *params);
TGLAPI void TglGetVertexAttribPointerv (TGLuint index, TGLenum pname, void **pointer);
TGLAPI TGLboolean TglIsProgram (TGLuint program);
TGLAPI TGLboolean TglIsShader (TGLuint shader);
TGLAPI void TglLinkProgram (TGLuint program);
TGLAPI void TglShaderSource (TGLuint shader, TGLsizei count, const TGLchar *const*string, const TGLint *length);
TGLAPI void TglUseProgram (TGLuint program);
TGLAPI void TglUniform1f (TGLint location, TGLfloat v0);
TGLAPI void TglUniform2f (TGLint location, TGLfloat v0, TGLfloat v1);
TGLAPI void TglUniform3f (TGLint location, TGLfloat v0, TGLfloat v1, TGLfloat v2);
TGLAPI void TglUniform4f (TGLint location, TGLfloat v0, TGLfloat v1, TGLfloat v2, TGLfloat v3);
TGLAPI void TglUniform1i (TGLint location, TGLint v0);
TGLAPI void TglUniform2i (TGLint location, TGLint v0, TGLint v1);
TGLAPI void TglUniform3i (TGLint location, TGLint v0, TGLint v1, TGLint v2);
TGLAPI void TglUniform4i (TGLint location, TGLint v0, TGLint v1, TGLint v2, TGLint v3);
TGLAPI void TglUniform1fv (TGLint location, TGLsizei count, const TGLfloat *value);
TGLAPI void TglUniform2fv (TGLint location, TGLsizei count, const TGLfloat *value);
TGLAPI void TglUniform3fv (TGLint location, TGLsizei count, const TGLfloat *value);
TGLAPI void TglUniform4fv (TGLint location, TGLsizei count, const TGLfloat *value);
TGLAPI void TglUniform1iv (TGLint location, TGLsizei count, const TGLint *value);
TGLAPI void TglUniform2iv (TGLint location, TGLsizei count, const TGLint *value);
TGLAPI void TglUniform3iv (TGLint location, TGLsizei count, const TGLint *value);
TGLAPI void TglUniform4iv (TGLint location, TGLsizei count, const TGLint *value);
TGLAPI void TglUniformMatrix2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglValidateProgram (TGLuint program);
TGLAPI void TglVertexAttrib1d (TGLuint index, TGLdouble x);
TGLAPI void TglVertexAttrib1dv (TGLuint index, const TGLdouble *v);
TGLAPI void TglVertexAttrib1f (TGLuint index, TGLfloat x);
TGLAPI void TglVertexAttrib1fv (TGLuint index, const TGLfloat *v);
TGLAPI void TglVertexAttrib1s (TGLuint index, TGLshort x);
TGLAPI void TglVertexAttrib1sv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttrib2d (TGLuint index, TGLdouble x, TGLdouble y);
TGLAPI void TglVertexAttrib2dv (TGLuint index, const TGLdouble *v);
TGLAPI void TglVertexAttrib2f (TGLuint index, TGLfloat x, TGLfloat y);
TGLAPI void TglVertexAttrib2fv (TGLuint index, const TGLfloat *v);
TGLAPI void TglVertexAttrib2s (TGLuint index, TGLshort x, TGLshort y);
TGLAPI void TglVertexAttrib2sv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttrib3d (TGLuint index, TGLdouble x, TGLdouble y, TGLdouble z);
TGLAPI void TglVertexAttrib3dv (TGLuint index, const TGLdouble *v);
TGLAPI void TglVertexAttrib3f (TGLuint index, TGLfloat x, TGLfloat y, TGLfloat z);
TGLAPI void TglVertexAttrib3fv (TGLuint index, const TGLfloat *v);
TGLAPI void TglVertexAttrib3s (TGLuint index, TGLshort x, TGLshort y, TGLshort z);
TGLAPI void TglVertexAttrib3sv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttrib4Nbv (TGLuint index, const TGLbyte *v);
TGLAPI void TglVertexAttrib4Niv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttrib4Nsv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttrib4Nub (TGLuint index, TGLubyte x, TGLubyte y, TGLubyte z, TGLubyte w);
TGLAPI void TglVertexAttrib4Nubv (TGLuint index, const TGLubyte *v);
TGLAPI void TglVertexAttrib4Nuiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttrib4Nusv (TGLuint index, const TGLushort *v);
TGLAPI void TglVertexAttrib4bv (TGLuint index, const TGLbyte *v);
TGLAPI void TglVertexAttrib4d (TGLuint index, TGLdouble x, TGLdouble y, TGLdouble z, TGLdouble w);
TGLAPI void TglVertexAttrib4dv (TGLuint index, const TGLdouble *v);
TGLAPI void TglVertexAttrib4f (TGLuint index, TGLfloat x, TGLfloat y, TGLfloat z, TGLfloat w);
TGLAPI void TglVertexAttrib4fv (TGLuint index, const TGLfloat *v);
TGLAPI void TglVertexAttrib4iv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttrib4s (TGLuint index, TGLshort x, TGLshort y, TGLshort z, TGLshort w);
TGLAPI void TglVertexAttrib4sv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttrib4ubv (TGLuint index, const TGLubyte *v);
TGLAPI void TglVertexAttrib4uiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttrib4usv (TGLuint index, const TGLushort *v);
TGLAPI void TglVertexAttribPointer (TGLuint index, TGLint size, TGLenum type, TGLboolean normalized, TGLsizei stride, const void *pointer);


// GL_VERSION_2_1
#define TGL_PIXEL_PACK_BUFFER              0x88EB
#define TGL_PIXEL_UNPACK_BUFFER            0x88EC
#define TGL_PIXEL_PACK_BUFFER_BINDING      0x88ED
#define TGL_PIXEL_UNPACK_BUFFER_BINDING    0x88EF
#define TGL_FLOAT_MAT2x3                   0x8B65
#define TGL_FLOAT_MAT2x4                   0x8B66
#define TGL_FLOAT_MAT3x2                   0x8B67
#define TGL_FLOAT_MAT3x4                   0x8B68
#define TGL_FLOAT_MAT4x2                   0x8B69
#define TGL_FLOAT_MAT4x3                   0x8B6A
#define TGL_SRGB                           0x8C40
#define TGL_SRGB8                          0x8C41
#define TGL_SRGB_ALPHA                     0x8C42
#define TGL_SRGB8_ALPHA8                   0x8C43
#define TGL_COMPRESSED_SRGB                0x8C48
#define TGL_COMPRESSED_SRGB_ALPHA          0x8C49

TGLAPI void TglUniformMatrix2x3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix3x2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix2x4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix4x2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix3x4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
TGLAPI void TglUniformMatrix4x3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);


// GL_VERSION_3_0
typedef khronos_uint16_t TGLhalf;
#define TGL_COMPARE_REF_TO_TEXTURE         0x884E
#define TGL_CLIP_DISTANCE0                 0x3000
#define TGL_CLIP_DISTANCE1                 0x3001
#define TGL_CLIP_DISTANCE2                 0x3002
#define TGL_CLIP_DISTANCE3                 0x3003
#define TGL_CLIP_DISTANCE4                 0x3004
#define TGL_CLIP_DISTANCE5                 0x3005
#define TGL_CLIP_DISTANCE6                 0x3006
#define TGL_CLIP_DISTANCE7                 0x3007
#define TGL_MAX_CLIP_DISTANCES             0x0D32
#define TGL_MAJOR_VERSION                  0x821B
#define TGL_MINOR_VERSION                  0x821C
#define TGL_NUM_EXTENSIONS                 0x821D
#define TGL_CONTEXT_FLAGS                  0x821E
#define TGL_COMPRESSED_RED                 0x8225
#define TGL_COMPRESSED_RG                  0x8226
#define TGL_CONTEXT_FLAG_FORWARD_COMPATIBLE_BIT 0x00000001
#define TGL_RGBA32F                        0x8814
#define TGL_RGB32F                         0x8815
#define TGL_RGBA16F                        0x881A
#define TGL_RGB16F                         0x881B
#define TGL_VERTEX_ATTRIB_ARRAY_INTEGER    0x88FD
#define TGL_MAX_ARRAY_TEXTURE_LAYERS       0x88FF
#define TGL_MIN_PROGRAM_TEXEL_OFFSET       0x8904
#define TGL_MAX_PROGRAM_TEXEL_OFFSET       0x8905
#define TGL_CLAMP_READ_COLOR               0x891C
#define TGL_FIXED_ONLY                     0x891D
#define TGL_MAX_VARYING_COMPONENTS         0x8B4B
#define TGL_TEXTURE_1D_ARRAY               0x8C18
#define TGL_PROXY_TEXTURE_1D_ARRAY         0x8C19
#define TGL_TEXTURE_2D_ARRAY               0x8C1A
#define TGL_PROXY_TEXTURE_2D_ARRAY         0x8C1B
#define TGL_TEXTURE_BINDING_1D_ARRAY       0x8C1C
#define TGL_TEXTURE_BINDING_2D_ARRAY       0x8C1D
#define TGL_R11F_G11F_B10F                 0x8C3A
#define TGL_UNSIGNED_INT_10F_11F_11F_REV   0x8C3B
#define TGL_RGB9_E5                        0x8C3D
#define TGL_UNSIGNED_INT_5_9_9_9_REV       0x8C3E
#define TGL_TEXTURE_SHARED_SIZE            0x8C3F
#define TGL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH 0x8C76
#define TGL_TRANSFORM_FEEDBACK_BUFFER_MODE 0x8C7F
#define TGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS 0x8C80
#define TGL_TRANSFORM_FEEDBACK_VARYINGS    0x8C83
#define TGL_TRANSFORM_FEEDBACK_BUFFER_START 0x8C84
#define TGL_TRANSFORM_FEEDBACK_BUFFER_SIZE 0x8C85
#define TGL_PRIMITIVES_GENERATED           0x8C87
#define TGL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN 0x8C88
#define TGL_RASTERIZER_DISCARD             0x8C89
#define TGL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS 0x8C8A
#define TGL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS 0x8C8B
#define TGL_INTERLEAVED_ATTRIBS            0x8C8C
#define TGL_SEPARATE_ATTRIBS               0x8C8D
#define TGL_TRANSFORM_FEEDBACK_BUFFER      0x8C8E
#define TGL_TRANSFORM_FEEDBACK_BUFFER_BINDING 0x8C8F
#define TGL_RGBA32UI                       0x8D70
#define TGL_RGB32UI                        0x8D71
#define TGL_RGBA16UI                       0x8D76
#define TGL_RGB16UI                        0x8D77
#define TGL_RGBA8UI                        0x8D7C
#define TGL_RGB8UI                         0x8D7D
#define TGL_RGBA32I                        0x8D82
#define TGL_RGB32I                         0x8D83
#define TGL_RGBA16I                        0x8D88
#define TGL_RGB16I                         0x8D89
#define TGL_RGBA8I                         0x8D8E
#define TGL_RGB8I                          0x8D8F
#define TGL_RED_INTEGER                    0x8D94
#define TGL_GREEN_INTEGER                  0x8D95
#define TGL_BLUE_INTEGER                   0x8D96
#define TGL_RGB_INTEGER                    0x8D98
#define TGL_RGBA_INTEGER                   0x8D99
#define TGL_BGR_INTEGER                    0x8D9A
#define TGL_BGRA_INTEGER                   0x8D9B
#define TGL_SAMPLER_1D_ARRAY               0x8DC0
#define TGL_SAMPLER_2D_ARRAY               0x8DC1
#define TGL_SAMPLER_1D_ARRAY_SHADOW        0x8DC3
#define TGL_SAMPLER_2D_ARRAY_SHADOW        0x8DC4
#define TGL_SAMPLER_CUBE_SHADOW            0x8DC5
#define TGL_UNSIGNED_INT_VEC2              0x8DC6
#define TGL_UNSIGNED_INT_VEC3              0x8DC7
#define TGL_UNSIGNED_INT_VEC4              0x8DC8
#define TGL_INT_SAMPLER_1D                 0x8DC9
#define TGL_INT_SAMPLER_2D                 0x8DCA
#define TGL_INT_SAMPLER_3D                 0x8DCB
#define TGL_INT_SAMPLER_CUBE               0x8DCC
#define TGL_INT_SAMPLER_1D_ARRAY           0x8DCE
#define TGL_INT_SAMPLER_2D_ARRAY           0x8DCF
#define TGL_UNSIGNED_INT_SAMPLER_1D        0x8DD1
#define TGL_UNSIGNED_INT_SAMPLER_2D        0x8DD2
#define TGL_UNSIGNED_INT_SAMPLER_3D        0x8DD3
#define TGL_UNSIGNED_INT_SAMPLER_CUBE      0x8DD4
#define TGL_UNSIGNED_INT_SAMPLER_1D_ARRAY  0x8DD6
#define TGL_UNSIGNED_INT_SAMPLER_2D_ARRAY  0x8DD7
#define TGL_QUERY_WAIT                     0x8E13
#define TGL_QUERY_NO_WAIT                  0x8E14
#define TGL_QUERY_BY_REGION_WAIT           0x8E15
#define TGL_QUERY_BY_REGION_NO_WAIT        0x8E16
#define TGL_BUFFER_ACCESS_FLAGS            0x911F
#define TGL_BUFFER_MAP_LENGTH              0x9120
#define TGL_BUFFER_MAP_OFFSET              0x9121
#define TGL_DEPTH_COMPONENT32F             0x8CAC
#define TGL_DEPTH32F_STENCIL8              0x8CAD
#define TGL_FLOAT_32_UNSIGNED_INT_24_8_REV 0x8DAD
#define TGL_INVALID_FRAMEBUFFER_OPERATION  0x0506
#define TGL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING 0x8210
#define TGL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE 0x8211
#define TGL_FRAMEBUFFER_ATTACHMENT_RED_SIZE 0x8212
#define TGL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE 0x8213
#define TGL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE 0x8214
#define TGL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE 0x8215
#define TGL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE 0x8216
#define TGL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE 0x8217
#define TGL_FRAMEBUFFER_DEFAULT            0x8218
#define TGL_FRAMEBUFFER_UNDEFINED          0x8219
#define TGL_DEPTH_STENCIL_ATTACHMENT       0x821A
#define TGL_MAX_RENDERBUFFER_SIZE          0x84E8
#define TGL_DEPTH_STENCIL                  0x84F9
#define TGL_UNSIGNED_INT_24_8              0x84FA
#define TGL_DEPTH24_STENCIL8               0x88F0
#define TGL_TEXTURE_STENCIL_SIZE           0x88F1
#define TGL_TEXTURE_RED_TYPE               0x8C10
#define TGL_TEXTURE_GREEN_TYPE             0x8C11
#define TGL_TEXTURE_BLUE_TYPE              0x8C12
#define TGL_TEXTURE_ALPHA_TYPE             0x8C13
#define TGL_TEXTURE_DEPTH_TYPE             0x8C16
#define TGL_UNSIGNED_NORMALIZED            0x8C17
#define TGL_FRAMEBUFFER_BINDING            0x8CA6
#define TGL_DRAW_FRAMEBUFFER_BINDING       0x8CA6
#define TGL_RENDERBUFFER_BINDING           0x8CA7
#define TGL_READ_FRAMEBUFFER               0x8CA8
#define TGL_DRAW_FRAMEBUFFER               0x8CA9
#define TGL_READ_FRAMEBUFFER_BINDING       0x8CAA
#define TGL_RENDERBUFFER_SAMPLES           0x8CAB
#define TGL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE 0x8CD0
#define TGL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME 0x8CD1
#define TGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL 0x8CD2
#define TGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE 0x8CD3
#define TGL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER 0x8CD4
#define TGL_FRAMEBUFFER_COMPLETE           0x8CD5
#define TGL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT 0x8CD6
#define TGL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT 0x8CD7
#define TGL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER 0x8CDB
#define TGL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER 0x8CDC
#define TGL_FRAMEBUFFER_UNSUPPORTED        0x8CDD
#define TGL_MAX_COLOR_ATTACHMENTS          0x8CDF
#define TGL_COLOR_ATTACHMENT0              0x8CE0
#define TGL_COLOR_ATTACHMENT1              0x8CE1
#define TGL_COLOR_ATTACHMENT2              0x8CE2
#define TGL_COLOR_ATTACHMENT3              0x8CE3
#define TGL_COLOR_ATTACHMENT4              0x8CE4
#define TGL_COLOR_ATTACHMENT5              0x8CE5
#define TGL_COLOR_ATTACHMENT6              0x8CE6
#define TGL_COLOR_ATTACHMENT7              0x8CE7
#define TGL_COLOR_ATTACHMENT8              0x8CE8
#define TGL_COLOR_ATTACHMENT9              0x8CE9
#define TGL_COLOR_ATTACHMENT10             0x8CEA
#define TGL_COLOR_ATTACHMENT11             0x8CEB
#define TGL_COLOR_ATTACHMENT12             0x8CEC
#define TGL_COLOR_ATTACHMENT13             0x8CED
#define TGL_COLOR_ATTACHMENT14             0x8CEE
#define TGL_COLOR_ATTACHMENT15             0x8CEF
#define TGL_COLOR_ATTACHMENT16             0x8CF0
#define TGL_COLOR_ATTACHMENT17             0x8CF1
#define TGL_COLOR_ATTACHMENT18             0x8CF2
#define TGL_COLOR_ATTACHMENT19             0x8CF3
#define TGL_COLOR_ATTACHMENT20             0x8CF4
#define TGL_COLOR_ATTACHMENT21             0x8CF5
#define TGL_COLOR_ATTACHMENT22             0x8CF6
#define TGL_COLOR_ATTACHMENT23             0x8CF7
#define TGL_COLOR_ATTACHMENT24             0x8CF8
#define TGL_COLOR_ATTACHMENT25             0x8CF9
#define TGL_COLOR_ATTACHMENT26             0x8CFA
#define TGL_COLOR_ATTACHMENT27             0x8CFB
#define TGL_COLOR_ATTACHMENT28             0x8CFC
#define TGL_COLOR_ATTACHMENT29             0x8CFD
#define TGL_COLOR_ATTACHMENT30             0x8CFE
#define TGL_COLOR_ATTACHMENT31             0x8CFF
#define TGL_DEPTH_ATTACHMENT               0x8D00
#define TGL_STENCIL_ATTACHMENT             0x8D20
#define TGL_FRAMEBUFFER                    0x8D40
#define TGL_RENDERBUFFER                   0x8D41
#define TGL_RENDERBUFFER_WIDTH             0x8D42
#define TGL_RENDERBUFFER_HEIGHT            0x8D43
#define TGL_RENDERBUFFER_INTERNAL_FORMAT   0x8D44
#define TGL_STENCIL_INDEX1                 0x8D46
#define TGL_STENCIL_INDEX4                 0x8D47
#define TGL_STENCIL_INDEX8                 0x8D48
#define TGL_STENCIL_INDEX16                0x8D49
#define TGL_RENDERBUFFER_RED_SIZE          0x8D50
#define TGL_RENDERBUFFER_GREEN_SIZE        0x8D51
#define TGL_RENDERBUFFER_BLUE_SIZE         0x8D52
#define TGL_RENDERBUFFER_ALPHA_SIZE        0x8D53
#define TGL_RENDERBUFFER_DEPTH_SIZE        0x8D54
#define TGL_RENDERBUFFER_STENCIL_SIZE      0x8D55
#define TGL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE 0x8D56
#define TGL_MAX_SAMPLES                    0x8D57
#define TGL_FRAMEBUFFER_SRGB               0x8DB9
#define TGL_HALF_FLOAT                     0x140B
#define TGL_MAP_READ_BIT                   0x0001
#define TGL_MAP_WRITE_BIT                  0x0002
#define TGL_MAP_INVALIDATE_RANGE_BIT       0x0004
#define TGL_MAP_INVALIDATE_BUFFER_BIT      0x0008
#define TGL_MAP_FLUSH_EXPLICIT_BIT         0x0010
#define TGL_MAP_UNSYNCHRONIZED_BIT         0x0020
#define TGL_COMPRESSED_RED_RGTC1           0x8DBB
#define TGL_COMPRESSED_SIGNED_RED_RGTC1    0x8DBC
#define TGL_COMPRESSED_RG_RGTC2            0x8DBD
#define TGL_COMPRESSED_SIGNED_RG_RGTC2     0x8DBE
#define TGL_RG                             0x8227
#define TGL_RG_INTEGER                     0x8228
#define TGL_R8                             0x8229
#define TGL_R16                            0x822A
#define TGL_RG8                            0x822B
#define TGL_RG16                           0x822C
#define TGL_R16F                           0x822D
#define TGL_R32F                           0x822E
#define TGL_RG16F                          0x822F
#define TGL_RG32F                          0x8230
#define TGL_R8I                            0x8231
#define TGL_R8UI                           0x8232
#define TGL_R16I                           0x8233
#define TGL_R16UI                          0x8234
#define TGL_R32I                           0x8235
#define TGL_R32UI                          0x8236
#define TGL_RG8I                           0x8237
#define TGL_RG8UI                          0x8238
#define TGL_RG16I                          0x8239
#define TGL_RG16UI                         0x823A
#define TGL_RG32I                          0x823B
#define TGL_RG32UI                         0x823C
#define TGL_VERTEX_ARRAY_BINDING           0x85B5

TGLAPI void TglColorMaski (TGLuint index, TGLboolean r, TGLboolean g, TGLboolean b, TGLboolean a);
TGLAPI void TglGetBooleani_v (TGLenum target, TGLuint index, TGLboolean *data);
TGLAPI void TglGetIntegeri_v (TGLenum target, TGLuint index, TGLint *data);
TGLAPI void TglEnablei (TGLenum target, TGLuint index);
TGLAPI void TglDisablei (TGLenum target, TGLuint index);
TGLAPI TGLboolean TglIsEnabledi (TGLenum target, TGLuint index);
TGLAPI void TglBeginTransformFeedback (TGLenum primitiveMode);
TGLAPI void TglEndTransformFeedback (void);
TGLAPI void TglBindBufferRange (TGLenum target, TGLuint index, TGLuint buffer, TGLintptr offset, TGLsizeiptr size);
TGLAPI void TglBindBufferBase (TGLenum target, TGLuint index, TGLuint buffer);
TGLAPI void TglTransformFeedbackVaryings (TGLuint program, TGLsizei count, const TGLchar *const*varyings, TGLenum bufferMode);
TGLAPI void TglGetTransformFeedbackVarying (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLsizei *size, TGLenum *type, TGLchar *name);
TGLAPI void TglClampColor (TGLenum target, TGLenum clamp);
TGLAPI void TglBeginConditionalRender (TGLuint id, TGLenum mode);
TGLAPI void TglEndConditionalRender (void);
TGLAPI void TglVertexAttribIPointer (TGLuint index, TGLint size, TGLenum type, TGLsizei stride, const void *pointer);
TGLAPI void TglGetVertexAttribIiv (TGLuint index, TGLenum pname, TGLint *params);
TGLAPI void TglGetVertexAttribIuiv (TGLuint index, TGLenum pname, TGLuint *params);
TGLAPI void TglVertexAttribI1i (TGLuint index, TGLint x);
TGLAPI void TglVertexAttribI2i (TGLuint index, TGLint x, TGLint y);
TGLAPI void TglVertexAttribI3i (TGLuint index, TGLint x, TGLint y, TGLint z);
TGLAPI void TglVertexAttribI4i (TGLuint index, TGLint x, TGLint y, TGLint z, TGLint w);
TGLAPI void TglVertexAttribI1ui (TGLuint index, TGLuint x);
TGLAPI void TglVertexAttribI2ui (TGLuint index, TGLuint x, TGLuint y);
TGLAPI void TglVertexAttribI3ui (TGLuint index, TGLuint x, TGLuint y, TGLuint z);
TGLAPI void TglVertexAttribI4ui (TGLuint index, TGLuint x, TGLuint y, TGLuint z, TGLuint w);
TGLAPI void TglVertexAttribI1iv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttribI2iv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttribI3iv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttribI4iv (TGLuint index, const TGLint *v);
TGLAPI void TglVertexAttribI1uiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttribI2uiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttribI3uiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttribI4uiv (TGLuint index, const TGLuint *v);
TGLAPI void TglVertexAttribI4bv (TGLuint index, const TGLbyte *v);
TGLAPI void TglVertexAttribI4sv (TGLuint index, const TGLshort *v);
TGLAPI void TglVertexAttribI4ubv (TGLuint index, const TGLubyte *v);
TGLAPI void TglVertexAttribI4usv (TGLuint index, const TGLushort *v);
TGLAPI void TglGetUniformuiv (TGLuint program, TGLint location, TGLuint *params);
TGLAPI void TglBindFragDataLocation (TGLuint program, TGLuint color, const TGLchar *name);
TGLAPI TGLint TglGetFragDataLocation (TGLuint program, const TGLchar *name);
TGLAPI void TglUniform1ui (TGLint location, TGLuint v0);
TGLAPI void TglUniform2ui (TGLint location, TGLuint v0, TGLuint v1);
TGLAPI void TglUniform3ui (TGLint location, TGLuint v0, TGLuint v1, TGLuint v2);
TGLAPI void TglUniform4ui (TGLint location, TGLuint v0, TGLuint v1, TGLuint v2, TGLuint v3);
TGLAPI void TglUniform1uiv (TGLint location, TGLsizei count, const TGLuint *value);
TGLAPI void TglUniform2uiv (TGLint location, TGLsizei count, const TGLuint *value);
TGLAPI void TglUniform3uiv (TGLint location, TGLsizei count, const TGLuint *value);
TGLAPI void TglUniform4uiv (TGLint location, TGLsizei count, const TGLuint *value);
TGLAPI void TglTexParameterIiv (TGLenum target, TGLenum pname, const TGLint *params);
TGLAPI void TglTexParameterIuiv (TGLenum target, TGLenum pname, const TGLuint *params);
TGLAPI void TglGetTexParameterIiv (TGLenum target, TGLenum pname, TGLint *params);
TGLAPI void TglGetTexParameterIuiv (TGLenum target, TGLenum pname, TGLuint *params);
TGLAPI void TglClearBufferiv (TGLenum buffer, TGLint drawbuffer, const TGLint *value);
TGLAPI void TglClearBufferuiv (TGLenum buffer, TGLint drawbuffer, const TGLuint *value);
TGLAPI void TglClearBufferfv (TGLenum buffer, TGLint drawbuffer, const TGLfloat *value);
TGLAPI void TglClearBufferfi (TGLenum buffer, TGLint drawbuffer, TGLfloat depth, TGLint stencil);
TGLAPI const TGLubyte *TglGetStringi (TGLenum name, TGLuint index);
TGLAPI TGLboolean TglIsRenderbuffer (TGLuint renderbuffer);
TGLAPI void TglBindRenderbuffer (TGLenum target, TGLuint renderbuffer);
TGLAPI void TglDeleteRenderbuffers (TGLsizei n, const TGLuint *renderbuffers);
TGLAPI void TglGenRenderbuffers (TGLsizei n, TGLuint *renderbuffers);
TGLAPI void TglRenderbufferStorage (TGLenum target, TGLenum internalformat, TGLsizei width, TGLsizei height);
TGLAPI void TglGetRenderbufferParameteriv (TGLenum target, TGLenum pname, TGLint *params);
TGLAPI TGLboolean TglIsFramebuffer (TGLuint framebuffer);
TGLAPI void TglBindFramebuffer (TGLenum target, TGLuint framebuffer);
TGLAPI void TglDeleteFramebuffers (TGLsizei n, const TGLuint *framebuffers);
TGLAPI void TglGenFramebuffers (TGLsizei n, TGLuint *framebuffers);
TGLAPI TGLenum TglCheckFramebufferStatus (TGLenum target);
TGLAPI void TglFramebufferTexture1D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level);
TGLAPI void TglFramebufferTexture2D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level);
TGLAPI void TglFramebufferTexture3D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level, TGLint zoffset);
TGLAPI void TglFramebufferRenderbuffer (TGLenum target, TGLenum attachment, TGLenum renderbuffertarget, TGLuint renderbuffer);
TGLAPI void TglGetFramebufferAttachmentParameteriv (TGLenum target, TGLenum attachment, TGLenum pname, TGLint *params);
TGLAPI void TglGenerateMipmap (TGLenum target);
TGLAPI void TglBlitFramebuffer (TGLint srcX0, TGLint srcY0, TGLint srcX1, TGLint srcY1, TGLint dstX0, TGLint dstY0, TGLint dstX1, TGLint dstY1, TGLbitfield mask, TGLenum filter);
TGLAPI void TglRenderbufferStorageMultisample (TGLenum target, TGLsizei samples, TGLenum internalformat, TGLsizei width, TGLsizei height);
TGLAPI void TglFramebufferTextureLayer (TGLenum target, TGLenum attachment, TGLuint texture, TGLint level, TGLint layer);
TGLAPI void *TglMapBufferRange (TGLenum target, TGLintptr offset, TGLsizeiptr length, TGLbitfield access);
TGLAPI void TglFlushMappedBufferRange (TGLenum target, TGLintptr offset, TGLsizeiptr length);
TGLAPI void TglBindVertexArray (TGLuint array);
TGLAPI void TglDeleteVertexArrays (TGLsizei n, const TGLuint *arrays);
TGLAPI void TglGenVertexArrays (TGLsizei n, TGLuint *arrays);
TGLAPI TGLboolean TglIsVertexArray (TGLuint array);

