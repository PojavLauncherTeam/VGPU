// OpenGL 2.0 >> 3.0

// Simplified version of the header file


#define GLAPI extern



// GL_VERSION_1_0
GLAPI void TglCullFace (GLenum mode);
GLAPI void TglFrontFace (GLenum mode);
GLAPI void TglHint (GLenum target, GLenum mode);
GLAPI void TglLineWidth (GLfloat width);
GLAPI void TglPointSize (GLfloat size);
GLAPI void TglPolygonMode (GLenum face, GLenum mode);
GLAPI void TglScissor (GLint x, GLint y, GLsizei width, GLsizei height);
GLAPI void TglTexParameterf (GLenum target, GLenum pname, GLfloat param);
GLAPI void TglTexParameterfv (GLenum target, GLenum pname, const GLfloat *params);
GLAPI void TglTexParameteri (GLenum target, GLenum pname, GLint param);
GLAPI void TglTexParameteriv (GLenum target, GLenum pname, const GLint *params);
GLAPI void TglTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const void *pixels);
GLAPI void TglTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels);
GLAPI void TglDrawBuffer (GLenum buf);
GLAPI void TglClear (GLbitfield mask);
GLAPI void TglClearColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
GLAPI void TglClearStencil (GLint s);
GLAPI void TglClearDepth (GLdouble depth);
GLAPI void TglStencilMask (GLuint mask);
GLAPI void TglColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha);
GLAPI void TglDepthMask (GLboolean flag);
GLAPI void TglDisable (GLenum cap);
GLAPI void TglEnable (GLenum cap);
GLAPI void TglFinish (void);
GLAPI void TglFlush (void);
GLAPI void TglBlendFunc (GLenum sfactor, GLenum dfactor);
GLAPI void TglLogicOp (GLenum opcode);
GLAPI void TglStencilFunc (GLenum func, GLint ref, GLuint mask);
GLAPI void TglStencilOp (GLenum fail, GLenum zfail, GLenum zpass);
GLAPI void TglDepthFunc (GLenum func);
GLAPI void TglPixelStoref (GLenum pname, GLfloat param);
GLAPI void TglPixelStorei (GLenum pname, GLint param);
GLAPI void TglReadBuffer (GLenum src);
GLAPI void TglReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels);
GLAPI void TglGetBooleanv (GLenum pname, GLboolean *data);
GLAPI void TglGetDoublev (GLenum pname, GLdouble *data);
GLAPI GLenum TglGetError (void);
GLAPI void TglGetFloatv (GLenum pname, GLfloat *data);
GLAPI void TglGetIntegerv (GLenum pname, GLint *data);
GLAPI const GLubyte *TglGetString (GLenum name);
GLAPI void TglGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, void *pixels);
GLAPI void TglGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params);
GLAPI void TglGetTexParameteriv (GLenum target, GLenum pname, GLint *params);
GLAPI void TglGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params);
GLAPI void TglGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params);
GLAPI GLboolean TglIsEnabled (GLenum cap);
GLAPI void TglDepthRange (GLdouble n, GLdouble f);
GLAPI void TglViewport (GLint x, GLint y, GLsizei width, GLsizei height);


// GL_VERSION_1_1
GLAPI void TglDrawArrays (GLenum mode, GLint first, GLsizei count);
GLAPI void TglDrawElements (GLenum mode, GLsizei count, GLenum type, const void *indices);
GLAPI void TglGetPointerv (GLenum pname, void **params);
GLAPI void TglPolygonOffset (GLfloat factor, GLfloat units);
GLAPI void TglCopyTexImage1D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLint border);
GLAPI void TglCopyTexImage2D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
GLAPI void TglCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width);
GLAPI void TglCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
GLAPI void TglTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const void *pixels);
GLAPI void TglTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels);
GLAPI void TglBindTexture (GLenum target, GLuint texture);
GLAPI void TglDeleteTextures (GLsizei n, const GLuint *textures);
GLAPI void TglGenTextures (GLsizei n, GLuint *textures);
GLAPI GLboolean TglIsTexture (GLuint texture);


// GL_VERSION_1_2
GLAPI void TglDrawRangeElements (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices);
GLAPI void TglTexImage3D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *pixels);
GLAPI void TglTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, const void *pixels);
GLAPI void TglCopyTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height);


// GL_VERSION_1_3
GLAPI void TglActiveTexture (GLenum texture);
GLAPI void TglSampleCoverage (GLfloat value, GLboolean invert);
GLAPI void TglCompressedTexImage3D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const void *data);
GLAPI void TglCompressedTexImage2D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data);
GLAPI void TglCompressedTexImage1D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLint border, GLsizei imageSize, const void *data);
GLAPI void TglCompressedTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const void *data);
GLAPI void TglCompressedTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data);
GLAPI void TglCompressedTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const void *data);
GLAPI void TglGetCompressedTexImage (GLenum target, GLint level, void *img);


// GL_VERSION_1_4
GLAPI void TglBlendFuncSeparate (GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha);
GLAPI void TglMultiDrawArrays (GLenum mode, const GLint *first, const GLsizei *count, GLsizei drawcount);
GLAPI void TglMultiDrawElements (GLenum mode, const GLsizei *count, GLenum type, const void *const*indices, GLsizei drawcount);
GLAPI void TglPointParameterf (GLenum pname, GLfloat param);
GLAPI void TglPointParameterfv (GLenum pname, const GLfloat *params);
GLAPI void TglPointParameteri (GLenum pname, GLint param);
GLAPI void TglPointParameteriv (GLenum pname, const GLint *params);
GLAPI void TglBlendColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
GLAPI void TglBlendEquation (GLenum mode);


// GL_VERSION_1_5
GLAPI void TglGenQueries (GLsizei n, GLuint *ids);
GLAPI void TglDeleteQueries (GLsizei n, const GLuint *ids);
GLAPI GLboolean TglIsQuery (GLuint id);
GLAPI void TglBeginQuery (GLenum target, GLuint id);
GLAPI void TglEndQuery (GLenum target);
GLAPI void TglGetQueryiv (GLenum target, GLenum pname, GLint *params);
GLAPI void TglGetQueryObjectiv (GLuint id, GLenum pname, GLint *params);
GLAPI void TglGetQueryObjectuiv (GLuint id, GLenum pname, GLuint *params);
GLAPI void TglBindBuffer (GLenum target, GLuint buffer);
GLAPI void TglDeleteBuffers (GLsizei n, const GLuint *buffers);
GLAPI void TglGenBuffers (GLsizei n, GLuint *buffers);
GLAPI GLboolean TglIsBuffer (GLuint buffer);
GLAPI void TglBufferData (GLenum target, GLsizeiptr size, const void *data, GLenum usage);
GLAPI void TglBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const void *data);
GLAPI void TglGetBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, void *data);
GLAPI void *TglMapBuffer (GLenum target, GLenum access);
GLAPI GLboolean TglUnmapBuffer (GLenum target);
GLAPI void TglGetBufferParameteriv (GLenum target, GLenum pname, GLint *params);
GLAPI void TglGetBufferPointerv (GLenum target, GLenum pname, void **params);


// GL_VERSION_2_0
GLAPI void TglBlendEquationSeparate (GLenum modeRGB, GLenum modeAlpha);
GLAPI void TglDrawBuffers (GLsizei n, const GLenum *bufs);
GLAPI void TglStencilOpSeparate (GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass);
GLAPI void TglStencilFuncSeparate (GLenum face, GLenum func, GLint ref, GLuint mask);
GLAPI void TglStencilMaskSeparate (GLenum face, GLuint mask);
GLAPI void TglAttachShader (GLuint program, GLuint shader);
GLAPI void TglBindAttribLocation (GLuint program, GLuint index, const GLchar *name);
GLAPI void TglCompileShader (GLuint shader);
GLAPI GLuint TglCreateProgram (void);
GLAPI GLuint TglCreateShader (GLenum type);
GLAPI void TglDeleteProgram (GLuint program);
GLAPI void TglDeleteShader (GLuint shader);
GLAPI void TglDetachShader (GLuint program, GLuint shader);
GLAPI void TglDisableVertexAttribArray (GLuint index);
GLAPI void TglEnableVertexAttribArray (GLuint index);
GLAPI void TglGetActiveAttrib (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name);
GLAPI void TglGetActiveUniform (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name);
GLAPI void TglGetAttachedShaders (GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders);
GLAPI GLint TglGetAttribLocation (GLuint program, const GLchar *name);
GLAPI void TglGetProgramiv (GLuint program, GLenum pname, GLint *params);
GLAPI void TglGetProgramInfoLog (GLuint program, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
GLAPI void TglGetShaderiv (GLuint shader, GLenum pname, GLint *params);
GLAPI void TglGetShaderInfoLog (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
GLAPI void TglGetShaderSource (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *source);
GLAPI GLint TglGetUniformLocation (GLuint program, const GLchar *name);
GLAPI void TglGetUniformfv (GLuint program, GLint location, GLfloat *params);
GLAPI void TglGetUniformiv (GLuint program, GLint location, GLint *params);
GLAPI void TglGetVertexAttribdv (GLuint index, GLenum pname, GLdouble *params);
GLAPI void TglGetVertexAttribfv (GLuint index, GLenum pname, GLfloat *params);
GLAPI void TglGetVertexAttribiv (GLuint index, GLenum pname, GLint *params);
GLAPI void TglGetVertexAttribPointerv (GLuint index, GLenum pname, void **pointer);
GLAPI GLboolean TglIsProgram (GLuint program);
GLAPI GLboolean TglIsShader (GLuint shader);
GLAPI void TglLinkProgram (GLuint program);
GLAPI void TglShaderSource (GLuint shader, GLsizei count, const GLchar *const*string, const GLint *length);
GLAPI void TglUseProgram (GLuint program);
GLAPI void TglUniform1f (GLint location, GLfloat v0);
GLAPI void TglUniform2f (GLint location, GLfloat v0, GLfloat v1);
GLAPI void TglUniform3f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2);
GLAPI void TglUniform4f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);
GLAPI void TglUniform1i (GLint location, GLint v0);
GLAPI void TglUniform2i (GLint location, GLint v0, GLint v1);
GLAPI void TglUniform3i (GLint location, GLint v0, GLint v1, GLint v2);
GLAPI void TglUniform4i (GLint location, GLint v0, GLint v1, GLint v2, GLint v3);
GLAPI void TglUniform1fv (GLint location, GLsizei count, const GLfloat *value);
GLAPI void TglUniform2fv (GLint location, GLsizei count, const GLfloat *value);
GLAPI void TglUniform3fv (GLint location, GLsizei count, const GLfloat *value);
GLAPI void TglUniform4fv (GLint location, GLsizei count, const GLfloat *value);
GLAPI void TglUniform1iv (GLint location, GLsizei count, const GLint *value);
GLAPI void TglUniform2iv (GLint location, GLsizei count, const GLint *value);
GLAPI void TglUniform3iv (GLint location, GLsizei count, const GLint *value);
GLAPI void TglUniform4iv (GLint location, GLsizei count, const GLint *value);
GLAPI void TglUniformMatrix2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglValidateProgram (GLuint program);
GLAPI void TglVertexAttrib1d (GLuint index, GLdouble x);
GLAPI void TglVertexAttrib1dv (GLuint index, const GLdouble *v);
GLAPI void TglVertexAttrib1f (GLuint index, GLfloat x);
GLAPI void TglVertexAttrib1fv (GLuint index, const GLfloat *v);
GLAPI void TglVertexAttrib1s (GLuint index, GLshort x);
GLAPI void TglVertexAttrib1sv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttrib2d (GLuint index, GLdouble x, GLdouble y);
GLAPI void TglVertexAttrib2dv (GLuint index, const GLdouble *v);
GLAPI void TglVertexAttrib2f (GLuint index, GLfloat x, GLfloat y);
GLAPI void TglVertexAttrib2fv (GLuint index, const GLfloat *v);
GLAPI void TglVertexAttrib2s (GLuint index, GLshort x, GLshort y);
GLAPI void TglVertexAttrib2sv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttrib3d (GLuint index, GLdouble x, GLdouble y, GLdouble z);
GLAPI void TglVertexAttrib3dv (GLuint index, const GLdouble *v);
GLAPI void TglVertexAttrib3f (GLuint index, GLfloat x, GLfloat y, GLfloat z);
GLAPI void TglVertexAttrib3fv (GLuint index, const GLfloat *v);
GLAPI void TglVertexAttrib3s (GLuint index, GLshort x, GLshort y, GLshort z);
GLAPI void TglVertexAttrib3sv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttrib4Nbv (GLuint index, const GLbyte *v);
GLAPI void TglVertexAttrib4Niv (GLuint index, const GLint *v);
GLAPI void TglVertexAttrib4Nsv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttrib4Nub (GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w);
GLAPI void TglVertexAttrib4Nubv (GLuint index, const GLubyte *v);
GLAPI void TglVertexAttrib4Nuiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttrib4Nusv (GLuint index, const GLushort *v);
GLAPI void TglVertexAttrib4bv (GLuint index, const GLbyte *v);
GLAPI void TglVertexAttrib4d (GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
GLAPI void TglVertexAttrib4dv (GLuint index, const GLdouble *v);
GLAPI void TglVertexAttrib4f (GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
GLAPI void TglVertexAttrib4fv (GLuint index, const GLfloat *v);
GLAPI void TglVertexAttrib4iv (GLuint index, const GLint *v);
GLAPI void TglVertexAttrib4s (GLuint index, GLshort x, GLshort y, GLshort z, GLshort w);
GLAPI void TglVertexAttrib4sv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttrib4ubv (GLuint index, const GLubyte *v);
GLAPI void TglVertexAttrib4uiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttrib4usv (GLuint index, const GLushort *v);
GLAPI void TglVertexAttribPointer (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer);


// GL_VERSION_2_1
GLAPI void TglUniformMatrix2x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix3x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix2x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix4x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix3x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
GLAPI void TglUniformMatrix4x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);


// GL_VERSION_3_0
GLAPI void TglColorMaski (GLuint index, GLboolean r, GLboolean g, GLboolean b, GLboolean a);
GLAPI void TglGetBooleani_v (GLenum target, GLuint index, GLboolean *data);
GLAPI void TglGetIntegeri_v (GLenum target, GLuint index, GLint *data);
GLAPI void TglEnablei (GLenum target, GLuint index);
GLAPI void TglDisablei (GLenum target, GLuint index);
GLAPI GLboolean TglIsEnabledi (GLenum target, GLuint index);
GLAPI void TglBeginTransformFeedback (GLenum primitiveMode);
GLAPI void TglEndTransformFeedback (void);
GLAPI void TglBindBufferRange (GLenum target, GLuint index, GLuint buffer, GLintptr offset, GLsizeiptr size);
GLAPI void TglBindBufferBase (GLenum target, GLuint index, GLuint buffer);
GLAPI void TglTransformFeedbackVaryings (GLuint program, GLsizei count, const GLchar *const*varyings, GLenum bufferMode);
GLAPI void TglGetTransformFeedbackVarying (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLsizei *size, GLenum *type, GLchar *name);
GLAPI void TglClampColor (GLenum target, GLenum clamp);
GLAPI void TglBeginConditionalRender (GLuint id, GLenum mode);
GLAPI void TglEndConditionalRender (void);
GLAPI void TglVertexAttribIPointer (GLuint index, GLint size, GLenum type, GLsizei stride, const void *pointer);
GLAPI void TglGetVertexAttribIiv (GLuint index, GLenum pname, GLint *params);
GLAPI void TglGetVertexAttribIuiv (GLuint index, GLenum pname, GLuint *params);
GLAPI void TglVertexAttribI1i (GLuint index, GLint x);
GLAPI void TglVertexAttribI2i (GLuint index, GLint x, GLint y);
GLAPI void TglVertexAttribI3i (GLuint index, GLint x, GLint y, GLint z);
GLAPI void TglVertexAttribI4i (GLuint index, GLint x, GLint y, GLint z, GLint w);
GLAPI void TglVertexAttribI1ui (GLuint index, GLuint x);
GLAPI void TglVertexAttribI2ui (GLuint index, GLuint x, GLuint y);
GLAPI void TglVertexAttribI3ui (GLuint index, GLuint x, GLuint y, GLuint z);
GLAPI void TglVertexAttribI4ui (GLuint index, GLuint x, GLuint y, GLuint z, GLuint w);
GLAPI void TglVertexAttribI1iv (GLuint index, const GLint *v);
GLAPI void TglVertexAttribI2iv (GLuint index, const GLint *v);
GLAPI void TglVertexAttribI3iv (GLuint index, const GLint *v);
GLAPI void TglVertexAttribI4iv (GLuint index, const GLint *v);
GLAPI void TglVertexAttribI1uiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttribI2uiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttribI3uiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttribI4uiv (GLuint index, const GLuint *v);
GLAPI void TglVertexAttribI4bv (GLuint index, const GLbyte *v);
GLAPI void TglVertexAttribI4sv (GLuint index, const GLshort *v);
GLAPI void TglVertexAttribI4ubv (GLuint index, const GLubyte *v);
GLAPI void TglVertexAttribI4usv (GLuint index, const GLushort *v);
GLAPI void TglGetUniformuiv (GLuint program, GLint location, GLuint *params);
GLAPI void TglBindFragDataLocation (GLuint program, GLuint color, const GLchar *name);
GLAPI GLint TglGetFragDataLocation (GLuint program, const GLchar *name);
GLAPI void TglUniform1ui (GLint location, GLuint v0);
GLAPI void TglUniform2ui (GLint location, GLuint v0, GLuint v1);
GLAPI void TglUniform3ui (GLint location, GLuint v0, GLuint v1, GLuint v2);
GLAPI void TglUniform4ui (GLint location, GLuint v0, GLuint v1, GLuint v2, GLuint v3);
GLAPI void TglUniform1uiv (GLint location, GLsizei count, const GLuint *value);
GLAPI void TglUniform2uiv (GLint location, GLsizei count, const GLuint *value);
GLAPI void TglUniform3uiv (GLint location, GLsizei count, const GLuint *value);
GLAPI void TglUniform4uiv (GLint location, GLsizei count, const GLuint *value);
GLAPI void TglTexParameterIiv (GLenum target, GLenum pname, const GLint *params);
GLAPI void TglTexParameterIuiv (GLenum target, GLenum pname, const GLuint *params);
GLAPI void TglGetTexParameterIiv (GLenum target, GLenum pname, GLint *params);
GLAPI void TglGetTexParameterIuiv (GLenum target, GLenum pname, GLuint *params);
GLAPI void TglClearBufferiv (GLenum buffer, GLint drawbuffer, const GLint *value);
GLAPI void TglClearBufferuiv (GLenum buffer, GLint drawbuffer, const GLuint *value);
GLAPI void TglClearBufferfv (GLenum buffer, GLint drawbuffer, const GLfloat *value);
GLAPI void TglClearBufferfi (GLenum buffer, GLint drawbuffer, GLfloat depth, GLint stencil);
GLAPI const GLubyte *TglGetStringi (GLenum name, GLuint index);
GLAPI GLboolean TglIsRenderbuffer (GLuint renderbuffer);
GLAPI void TglBindRenderbuffer (GLenum target, GLuint renderbuffer);
GLAPI void TglDeleteRenderbuffers (GLsizei n, const GLuint *renderbuffers);
GLAPI void TglGenRenderbuffers (GLsizei n, GLuint *renderbuffers);
GLAPI void TglRenderbufferStorage (GLenum target, GLenum internalformat, GLsizei width, GLsizei height);
GLAPI void TglGetRenderbufferParameteriv (GLenum target, GLenum pname, GLint *params);
GLAPI GLboolean TglIsFramebuffer (GLuint framebuffer);
GLAPI void TglBindFramebuffer (GLenum target, GLuint framebuffer);
GLAPI void TglDeleteFramebuffers (GLsizei n, const GLuint *framebuffers);
GLAPI void TglGenFramebuffers (GLsizei n, GLuint *framebuffers);
GLAPI GLenum TglCheckFramebufferStatus (GLenum target);
GLAPI void TglFramebufferTexture1D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
GLAPI void TglFramebufferTexture2D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
GLAPI void TglFramebufferTexture3D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level, GLint zoffset);
GLAPI void TglFramebufferRenderbuffer (GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer);
GLAPI void TglGetFramebufferAttachmentParameteriv (GLenum target, GLenum attachment, GLenum pname, GLint *params);
GLAPI void TglGenerateMipmap (GLenum target);
GLAPI void TglBlitFramebuffer (GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter);
GLAPI void TglRenderbufferStorageMultisample (GLenum target, GLsizei samples, GLenum internalformat, GLsizei width, GLsizei height);
GLAPI void TglFramebufferTextureLayer (GLenum target, GLenum attachment, GLuint texture, GLint level, GLint layer);
GLAPI void *TglMapBufferRange (GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access);
GLAPI void TglFlushMappedBufferRange (GLenum target, GLintptr offset, GLsizeiptr length);
GLAPI void TglBindVertexArray (GLuint array);
GLAPI void TglDeleteVertexArrays (GLsizei n, const GLuint *arrays);
GLAPI void TglGenVertexArrays (GLsizei n, GLuint *arrays);
GLAPI GLboolean TglIsVertexArray (GLuint array);





