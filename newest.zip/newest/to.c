// OpenGL 2.0 >> 3.0

#include "to.h"
#include "toext.h"
#include <GLES3/gl32.h>


// GLuint TglCreateShader( GLenum type )
// {
//  return glCreateShader( type );     // Calling into GLES functions.
// }									 // In addition, for most functions, 
// the constants used by GL and GLES (such as GL_VERSION) are mostly the same,
// (the constants represent the same value) 
// so we can pass the parameters of the GL API directly to the GLES API.




// GL_VERSION_1_0
void TglCullFace (GLenum mode){
 glCullFace (mode);

}

void TglFrontFace (GLenum mode){
 glFrontFace (mode);

}

void TglHint (GLenum target, GLenum mode){
 glHint (target, mode);

}

void TglLineWidth (GLfloat width){
 glLineWidth (width);

}

void TglPointSize (GLfloat size){
 glPointSize (size);

}

void TglPolygonMode (GLenum face, GLenum mode){
 glPolygonMode (face, mode);

}

void TglScissor (GLint x, GLint y, GLsizei width, GLsizei height){
 glScissor (x, y, width, height);

}

void TglTexParameterf (GLenum target, GLenum pname, GLfloat param){
 glTexParameterf (target, pname, param);

}

void TglTexParameterfv (GLenum target, GLenum pname, const GLfloat *params){
 glTexParameterfv (target, pname, params);

}

void TglTexParameteri (GLenum target, GLenum pname, GLint param){
 glTexParameteri (target, pname, param);

}

void TglTexParameteriv (GLenum target, GLenum pname, const GLint *params){
 glTexParameteriv (target, pname, params);

}

void TglTexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const void *pixels){
 glTexImage1D (target, level, internalformat, width, border, format, type, pixels);

}

void TglTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels){
 glTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);

}

void TglDrawBuffer (GLenum buf){
 glDrawBuffer (buf);

}

void TglClear (GLbitfield mask){
 glClear (mask);

}

void TglClearColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha){
 glClearColor (red, green, blue, alpha);

}

void TglClearStencil (GLint s){
 glClearStencil (s);

}

void TglClearDepth (GLdouble depth){
 glClearDepth (depth);

}

void TglStencilMask (GLuint mask){
 glStencilMask (mask);

}

void TglColorMask (GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha){
 glColorMask (red, green, blue, alpha);

}

void TglDepthMask (GLboolean flag){
 glDepthMask (flag);

}

void TglDisable (GLenum cap){
 glDisable (cap);

}

void TglEnable (GLenum cap){
 glEnable (cap);

}

void TglFinish (void){
 glFinish ();

}

void TglFlush (void){
 glFlush ();

}

void TglBlendFunc (GLenum sfactor, GLenum dfactor){
 glBlendFunc (sfactor, dfactor);

}

void TglLogicOp (GLenum opcode){
 glLogicOp (opcode);

}

void TglStencilFunc (GLenum func, GLint ref, GLuint mask){
 glStencilFunc (func, ref, mask);

}

void TglStencilOp (GLenum fail, GLenum zfail, GLenum zpass){
 glStencilOp (fail, zfail, zpass);

}

void TglDepthFunc (GLenum func){
 glDepthFunc (func);

}

void TglPixelStoref (GLenum pname, GLfloat param){
 glPixelStoref (pname, param);

}

void TglPixelStorei (GLenum pname, GLint param){
 glPixelStorei (pname, param);

}

void TglReadBuffer (GLenum src){
 glReadBuffer (src);

}

void TglReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, void *pixels){
 glReadPixels (x, y, width, height, format, type, pixels);

}

void TglGetBooleanv (GLenum pname, GLboolean *data){
 glGetBooleanv (pname, data);

}

void TglGetDoublev (GLenum pname, GLdouble *data){
 glGetDoublev (pname, data);

}

GLenum TglGetError (void){
 return glGetError ();

}

void TglGetFloatv (GLenum pname, GLfloat *data){
 glGetFloatv (pname, data);

}

void TglGetIntegerv (GLenum pname, GLint *data){
 glGetIntegerv (pname, data);

}

const GLubyte *TglGetString (GLenum name){
 return glGetString (name);

}

void TglGetTexImage (GLenum target, GLint level, GLenum format, GLenum type, void *pixels){
 glGetTexImage (target, level, format, type, pixels);

}

void TglGetTexParameterfv (GLenum target, GLenum pname, GLfloat *params){
 glGetTexParameterfv (target, pname, params);

}

void TglGetTexParameteriv (GLenum target, GLenum pname, GLint *params){
 glGetTexParameteriv (target, pname, params);

}

void TglGetTexLevelParameterfv (GLenum target, GLint level, GLenum pname, GLfloat *params){
 glGetTexLevelParameterfv (target, level, pname, params);

}

void TglGetTexLevelParameteriv (GLenum target, GLint level, GLenum pname, GLint *params){
 glGetTexLevelParameteriv (target, level, pname, params);

}

GLboolean TglIsEnabled (GLenum cap){
 return glIsEnabled (cap);

}

void TglDepthRange (GLdouble n, GLdouble f){
 glDepthRange (n, f);

}

void TglViewport (GLint x, GLint y, GLsizei width, GLsizei height){
 glViewport (x, y, width, height);

}



// GL_VERSION_1_1
void TglDrawArrays (GLenum mode, GLint first, GLsizei count){
 glDrawArrays (mode, first, count);

}

void TglDrawElements (GLenum mode, GLsizei count, GLenum type, const void *indices){
 glDrawElements (mode, count, type, indices);

}

void TglGetPointerv (GLenum pname, void **params){
 glGetPointerv (pname, params);

}

void TglPolygonOffset (GLfloat factor, GLfloat units){
 glPolygonOffset (factor, units);

}

void TglCopyTexImage1D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLint border){
 glCopyTexImage1D (target, level, internalformat, x, y, width, border);

}

void TglCopyTexImage2D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border){
 glCopyTexImage2D (target, level, internalformat, x, y, width, height, border);

}

void TglCopyTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width){
 glCopyTexSubImage1D (target, level, xoffset, x, y, width);

}

void TglCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height){
 glCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);

}

void TglTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const void *pixels){
 glTexSubImage1D (target, level, xoffset, width, format, type, pixels);

}

void TglTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const void *pixels){
 glTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);

}

void TglBindTexture (GLenum target, GLuint texture){
 glBindTexture (target, texture);

}

void TglDeleteTextures (GLsizei n, const GLuint *textures){
 glDeleteTextures (n, textures);

}

void TglGenTextures (GLsizei n, GLuint *textures){
 glGenTextures (n, textures);

}

GLboolean TglIsTexture (GLuint texture){
 return glIsTexture (texture);

}



// GL_VERSION_1_2
void TglDrawRangeElements (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const void *indices){
 glDrawRangeElements (mode, start, end, count, type, indices);

}

void TglTexImage3D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *pixels){
 glTexImage3D (target, level, internalformat, width, height, depth, border, format, type, pixels);

}

void TglTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, const void *pixels){
 glTexSubImage3D (target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels);

}

void TglCopyTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height){
 glCopyTexSubImage3D (target, level, xoffset, yoffset, zoffset, x, y, width, height);

}



// GL_VERSION_1_3
void TglActiveTexture (GLenum texture){
 glActiveTexture (texture);

}

void TglSampleCoverage (GLfloat value, GLboolean invert){
 glSampleCoverage (value, invert);

}

void TglCompressedTexImage3D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const void *data){
 glCompressedTexImage3D (target, level, internalformat, width, height, depth, border, imageSize, data);

}

void TglCompressedTexImage2D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data){
 glCompressedTexImage2D (target, level, internalformat, width, height, border, imageSize, data);

}

void TglCompressedTexImage1D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLint border, GLsizei imageSize, const void *data){
 glCompressedTexImage1D (target, level, internalformat, width, border, imageSize, data);

}

void TglCompressedTexSubImage3D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const void *data){
 glCompressedTexSubImage3D (target, level, xoffset, yoffset, zoffset, width, height, depth, format, imageSize, data);

}

void TglCompressedTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data){
 glCompressedTexSubImage2D (target, level, xoffset, yoffset, width, height, format, imageSize, data);

}

void TglCompressedTexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const void *data){
 glCompressedTexSubImage1D (target, level, xoffset, width, format, imageSize, data);

}

void TglGetCompressedTexImage (GLenum target, GLint level, void *img){
 glGetCompressedTexImage (target, level, img);

}



// GL_VERSION_1_4
void TglBlendFuncSeparate (GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha){
 glBlendFuncSeparate (sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha);

}

void TglMultiDrawArrays (GLenum mode, const GLint *first, const GLsizei *count, GLsizei drawcount){
 glMultiDrawArrays (mode, first, count, drawcount);

}

void TglMultiDrawElements (GLenum mode, const GLsizei *count, GLenum type, const void *const*indices, GLsizei drawcount){
 glMultiDrawElements (mode, count, type, indices, drawcount);

}

void TglPointParameterf (GLenum pname, GLfloat param){
 glPointParameterf (pname, param);

}

void TglPointParameterfv (GLenum pname, const GLfloat *params){
 glPointParameterfv (pname, params);

}

void TglPointParameteri (GLenum pname, GLint param){
 glPointParameteri (pname, param);

}

void TglPointParameteriv (GLenum pname, const GLint *params){
 glPointParameteriv (pname, params);

}

void TglBlendColor (GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha){
 glBlendColor (red, green, blue, alpha);

}

void TglBlendEquation (GLenum mode){
 glBlendEquation (mode);

}



// GL_VERSION_1_5
void TglGenQueries (GLsizei n, GLuint *ids){
 glGenQueries (n, ids);

}

void TglDeleteQueries (GLsizei n, const GLuint *ids){
 glDeleteQueries (n, ids);

}

GLboolean TglIsQuery (GLuint id){
 return glIsQuery (id);

}

void TglBeginQuery (GLenum target, GLuint id){
 glBeginQuery (target, id);

}

void TglEndQuery (GLenum target){
 glEndQuery (target);

}

void TglGetQueryiv (GLenum target, GLenum pname, GLint *params){
 glGetQueryiv (target, pname, params);

}

void TglGetQueryObjectiv (GLuint id, GLenum pname, GLint *params){
 glGetQueryObjectiv (id, pname, params);

}

void TglGetQueryObjectuiv (GLuint id, GLenum pname, GLuint *params){
 glGetQueryObjectuiv (id, pname, params);

}

void TglBindBuffer (GLenum target, GLuint buffer){
 glBindBuffer (target, buffer);

}

void TglDeleteBuffers (GLsizei n, const GLuint *buffers){
 glDeleteBuffers (n, buffers);

}

void TglGenBuffers (GLsizei n, GLuint *buffers){
 glGenBuffers (n, buffers);

}

GLboolean TglIsBuffer (GLuint buffer){
 return glIsBuffer (buffer);

}

void TglBufferData (GLenum target, GLsizeiptr size, const void *data, GLenum usage){
 glBufferData (target, size, data, usage);

}

void TglBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const void *data){
 glBufferSubData (target, offset, size, data);

}

void TglGetBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, void *data){
 glGetBufferSubData (target, offset, size, data);

}

void *TglMapBuffer (GLenum target, GLenum access){
 return glMapBuffer (target, access);

}

GLboolean TglUnmapBuffer (GLenum target){
 return glUnmapBuffer (target);

}

void TglGetBufferParameteriv (GLenum target, GLenum pname, GLint *params){
 glGetBufferParameteriv (target, pname, params);

}

void TglGetBufferPointerv (GLenum target, GLenum pname, void **params){
 glGetBufferPointerv (target, pname, params);

}



// GL_VERSION_2_0
void TglBlendEquationSeparate (GLenum modeRGB, GLenum modeAlpha){
 glBlendEquationSeparate (modeRGB, modeAlpha);

}

void TglDrawBuffers (GLsizei n, const GLenum *bufs){
 glDrawBuffers (n, bufs);

}

void TglStencilOpSeparate (GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass){
 glStencilOpSeparate (face, sfail, dpfail, dppass);

}

void TglStencilFuncSeparate (GLenum face, GLenum func, GLint ref, GLuint mask){
 glStencilFuncSeparate (face, func, ref, mask);

}

void TglStencilMaskSeparate (GLenum face, GLuint mask){
 glStencilMaskSeparate (face, mask);

}

void TglAttachShader (GLuint program, GLuint shader){
 glAttachShader (program, shader);

}

void TglBindAttribLocation (GLuint program, GLuint index, const GLchar *name){
 glBindAttribLocation (program, index, name);

}

void TglCompileShader (GLuint shader){
 glCompileShader (shader);

}

GLuint TglCreateProgram (void){
 return glCreateProgram ();

}

GLuint TglCreateShader (GLenum type){
 return glCreateShader (type);

}

void TglDeleteProgram (GLuint program){
 glDeleteProgram (program);

}

void TglDeleteShader (GLuint shader){
 glDeleteShader (shader);

}

void TglDetachShader (GLuint program, GLuint shader){
 glDetachShader (program, shader);

}

void TglDisableVertexAttribArray (GLuint index){
 glDisableVertexAttribArray (index);

}

void TglEnableVertexAttribArray (GLuint index){
 glEnableVertexAttribArray (index);

}

void TglGetActiveAttrib (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name){
 glGetActiveAttrib (program, index, bufSize, length, size, type, name);

}

void TglGetActiveUniform (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLint *size, GLenum *type, GLchar *name){
 glGetActiveUniform (program, index, bufSize, length, size, type, name);

}

void TglGetAttachedShaders (GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders){
 glGetAttachedShaders (program, maxCount, count, shaders);

}

GLint TglGetAttribLocation (GLuint program, const GLchar *name){
 return glGetAttribLocation (program, name);

}

void TglGetProgramiv (GLuint program, GLenum pname, GLint *params){
 glGetProgramiv (program, pname, params);

}

void TglGetProgramInfoLog (GLuint program, GLsizei bufSize, GLsizei *length, GLchar *infoLog){
 glGetProgramInfoLog (program, bufSize, length, infoLog);

}

void TglGetShaderiv (GLuint shader, GLenum pname, GLint *params){
 glGetShaderiv (shader, pname, params);

}

void TglGetShaderInfoLog (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *infoLog){
 glGetShaderInfoLog (shader, bufSize, length, infoLog);

}

void TglGetShaderSource (GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *source){
 glGetShaderSource (shader, bufSize, length, source);

}

GLint TglGetUniformLocation (GLuint program, const GLchar *name){
 return glGetUniformLocation (program, name);

}

void TglGetUniformfv (GLuint program, GLint location, GLfloat *params){
 glGetUniformfv (program, location, params);

}

void TglGetUniformiv (GLuint program, GLint location, GLint *params){
 glGetUniformiv (program, location, params);

}

void TglGetVertexAttribdv (GLuint index, GLenum pname, GLdouble *params){
 glGetVertexAttribdv (index, pname, params);

}

void TglGetVertexAttribfv (GLuint index, GLenum pname, GLfloat *params){
 glGetVertexAttribfv (index, pname, params);

}

void TglGetVertexAttribiv (GLuint index, GLenum pname, GLint *params){
 glGetVertexAttribiv (index, pname, params);

}

void TglGetVertexAttribPointerv (GLuint index, GLenum pname, void **pointer){
 glGetVertexAttribPointerv (index, pname, pointer);

}

GLboolean TglIsProgram (GLuint program){
 return glIsProgram (program);

}

GLboolean TglIsShader (GLuint shader){
 return glIsShader (shader);

}

void TglLinkProgram (GLuint program){
 glLinkProgram (program);

}

void TglShaderSource (GLuint shader, GLsizei count, const GLchar *const*string, const GLint *length){
 glShaderSource (shader, count, string, length);

}

void TglUseProgram (GLuint program){
 glUseProgram (program);

}

void TglUniform1f (GLint location, GLfloat v0){
 glUniform1f (location, v0);

}

void TglUniform2f (GLint location, GLfloat v0, GLfloat v1){
 glUniform2f (location, v0, v1);

}

void TglUniform3f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2){
 glUniform3f (location, v0, v1, v2);

}

void TglUniform4f (GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3){
 glUniform4f (location, v0, v1, v2, v3);

}

void TglUniform1i (GLint location, GLint v0){
 glUniform1i (location, v0);

}

void TglUniform2i (GLint location, GLint v0, GLint v1){
 glUniform2i (location, v0, v1);

}

void TglUniform3i (GLint location, GLint v0, GLint v1, GLint v2){
 glUniform3i (location, v0, v1, v2);

}

void TglUniform4i (GLint location, GLint v0, GLint v1, GLint v2, GLint v3){
 glUniform4i (location, v0, v1, v2, v3);

}

void TglUniform1fv (GLint location, GLsizei count, const GLfloat *value){
 glUniform1fv (location, count, value);

}

void TglUniform2fv (GLint location, GLsizei count, const GLfloat *value){
 glUniform2fv (location, count, value);

}

void TglUniform3fv (GLint location, GLsizei count, const GLfloat *value){
 glUniform3fv (location, count, value);

}

void TglUniform4fv (GLint location, GLsizei count, const GLfloat *value){
 glUniform4fv (location, count, value);

}

void TglUniform1iv (GLint location, GLsizei count, const GLint *value){
 glUniform1iv (location, count, value);

}

void TglUniform2iv (GLint location, GLsizei count, const GLint *value){
 glUniform2iv (location, count, value);

}

void TglUniform3iv (GLint location, GLsizei count, const GLint *value){
 glUniform3iv (location, count, value);

}

void TglUniform4iv (GLint location, GLsizei count, const GLint *value){
 glUniform4iv (location, count, value);

}

void TglUniformMatrix2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix2fv (location, count, transpose, value);

}

void TglUniformMatrix3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix3fv (location, count, transpose, value);

}

void TglUniformMatrix4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix4fv (location, count, transpose, value);

}

void TglValidateProgram (GLuint program){
 glValidateProgram (program);

}

void TglVertexAttrib1d (GLuint index, GLdouble x){
 glVertexAttrib1d (index, x);

}

void TglVertexAttrib1dv (GLuint index, const GLdouble *v){
 glVertexAttrib1dv (index, v);

}

void TglVertexAttrib1f (GLuint index, GLfloat x){
 glVertexAttrib1f (index, x);

}

void TglVertexAttrib1fv (GLuint index, const GLfloat *v){
 glVertexAttrib1fv (index, v);

}

void TglVertexAttrib1s (GLuint index, GLshort x){
 glVertexAttrib1s (index, x);

}

void TglVertexAttrib1sv (GLuint index, const GLshort *v){
 glVertexAttrib1sv (index, v);

}

void TglVertexAttrib2d (GLuint index, GLdouble x, GLdouble y){
 glVertexAttrib2d (index, x, y);

}

void TglVertexAttrib2dv (GLuint index, const GLdouble *v){
 glVertexAttrib2dv (index, v);

}

void TglVertexAttrib2f (GLuint index, GLfloat x, GLfloat y){
 glVertexAttrib2f (index, x, y);

}

void TglVertexAttrib2fv (GLuint index, const GLfloat *v){
 glVertexAttrib2fv (index, v);

}

void TglVertexAttrib2s (GLuint index, GLshort x, GLshort y){
 glVertexAttrib2s (index, x, y);

}

void TglVertexAttrib2sv (GLuint index, const GLshort *v){
 glVertexAttrib2sv (index, v);

}

void TglVertexAttrib3d (GLuint index, GLdouble x, GLdouble y, GLdouble z){
 glVertexAttrib3d (index, x, y, z);

}

void TglVertexAttrib3dv (GLuint index, const GLdouble *v){
 glVertexAttrib3dv (index, v);

}

void TglVertexAttrib3f (GLuint index, GLfloat x, GLfloat y, GLfloat z){
 glVertexAttrib3f (index, x, y, z);

}

void TglVertexAttrib3fv (GLuint index, const GLfloat *v){
 glVertexAttrib3fv (index, v);

}

void TglVertexAttrib3s (GLuint index, GLshort x, GLshort y, GLshort z){
 glVertexAttrib3s (index, x, y, z);

}

void TglVertexAttrib3sv (GLuint index, const GLshort *v){
 glVertexAttrib3sv (index, v);

}

void TglVertexAttrib4Nbv (GLuint index, const GLbyte *v){
 glVertexAttrib4Nbv (index, v);

}

void TglVertexAttrib4Niv (GLuint index, const GLint *v){
 glVertexAttrib4Niv (index, v);

}

void TglVertexAttrib4Nsv (GLuint index, const GLshort *v){
 glVertexAttrib4Nsv (index, v);

}

void TglVertexAttrib4Nub (GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w){
 glVertexAttrib4Nub (index, x, y, z, w);

}

void TglVertexAttrib4Nubv (GLuint index, const GLubyte *v){
 glVertexAttrib4Nubv (index, v);

}

void TglVertexAttrib4Nuiv (GLuint index, const GLuint *v){
 glVertexAttrib4Nuiv (index, v);

}

void TglVertexAttrib4Nusv (GLuint index, const GLushort *v){
 glVertexAttrib4Nusv (index, v);

}

void TglVertexAttrib4bv (GLuint index, const GLbyte *v){
 glVertexAttrib4bv (index, v);

}

void TglVertexAttrib4d (GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w){
 glVertexAttrib4d (index, x, y, z, w);

}

void TglVertexAttrib4dv (GLuint index, const GLdouble *v){
 glVertexAttrib4dv (index, v);

}

void TglVertexAttrib4f (GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w){
 glVertexAttrib4f (index, x, y, z, w);

}

void TglVertexAttrib4fv (GLuint index, const GLfloat *v){
 glVertexAttrib4fv (index, v);

}

void TglVertexAttrib4iv (GLuint index, const GLint *v){
 glVertexAttrib4iv (index, v);

}

void TglVertexAttrib4s (GLuint index, GLshort x, GLshort y, GLshort z, GLshort w){
 glVertexAttrib4s (index, x, y, z, w);

}

void TglVertexAttrib4sv (GLuint index, const GLshort *v){
 glVertexAttrib4sv (index, v);

}

void TglVertexAttrib4ubv (GLuint index, const GLubyte *v){
 glVertexAttrib4ubv (index, v);

}

void TglVertexAttrib4uiv (GLuint index, const GLuint *v){
 glVertexAttrib4uiv (index, v);

}

void TglVertexAttrib4usv (GLuint index, const GLushort *v){
 glVertexAttrib4usv (index, v);

}

void TglVertexAttribPointer (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const void *pointer){
 glVertexAttribPointer (index, size, type, normalized, stride, pointer);

}



// GL_VERSION_2_1
void TglUniformMatrix2x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix2x3fv (location, count, transpose, value);

}

void TglUniformMatrix3x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix3x2fv (location, count, transpose, value);

}

void TglUniformMatrix2x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix2x4fv (location, count, transpose, value);

}

void TglUniformMatrix4x2fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix4x2fv (location, count, transpose, value);

}

void TglUniformMatrix3x4fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix3x4fv (location, count, transpose, value);

}

void TglUniformMatrix4x3fv (GLint location, GLsizei count, GLboolean transpose, const GLfloat *value){
 glUniformMatrix4x3fv (location, count, transpose, value);

}



// GL_VERSION_3_0
void TglColorMaski (GLuint index, GLboolean r, GLboolean g, GLboolean b, GLboolean a){
 glColorMaski (index, r, g, b, a);

}

void TglGetBooleani_v (GLenum target, GLuint index, GLboolean *data){
 glGetBooleani_v (target, index, data);

}

void TglGetIntegeri_v (GLenum target, GLuint index, GLint *data){
 glGetIntegeri_v (target, index, data);

}

void TglEnablei (GLenum target, GLuint index){
 glEnablei (target, index);

}

void TglDisablei (GLenum target, GLuint index){
 glDisablei (target, index);

}

GLboolean TglIsEnabledi (GLenum target, GLuint index){
 return glIsEnabledi (target, index);

}

void TglBeginTransformFeedback (GLenum primitiveMode){
 glBeginTransformFeedback (primitiveMode);

}

void TglEndTransformFeedback (void){
 glEndTransformFeedback ();

}

void TglBindBufferRange (GLenum target, GLuint index, GLuint buffer, GLintptr offset, GLsizeiptr size){
 glBindBufferRange (target, index, buffer, offset, size);

}

void TglBindBufferBase (GLenum target, GLuint index, GLuint buffer){
 glBindBufferBase (target, index, buffer);

}

void TglTransformFeedbackVaryings (GLuint program, GLsizei count, const GLchar *const*varyings, GLenum bufferMode){
 glTransformFeedbackVaryings (program, count, varyings, bufferMode);

}

void TglGetTransformFeedbackVarying (GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLsizei *size, GLenum *type, GLchar *name){
 glGetTransformFeedbackVarying (program, index, bufSize, length, size, type, name);

}

void TglClampColor (GLenum target, GLenum clamp){
 glClampColor (target, clamp);

}

void TglBeginConditionalRender (GLuint id, GLenum mode){
 glBeginConditionalRender (id, mode);

}

void TglEndConditionalRender (void){
 glEndConditionalRender ();

}

void TglVertexAttribIPointer (GLuint index, GLint size, GLenum type, GLsizei stride, const void *pointer){
 glVertexAttribIPointer (index, size, type, stride, pointer);

}

void TglGetVertexAttribIiv (GLuint index, GLenum pname, GLint *params){
 glGetVertexAttribIiv (index, pname, params);

}

void TglGetVertexAttribIuiv (GLuint index, GLenum pname, GLuint *params){
 glGetVertexAttribIuiv (index, pname, params);

}

void TglVertexAttribI1i (GLuint index, GLint x){
 glVertexAttribI1i (index, x);

}

void TglVertexAttribI2i (GLuint index, GLint x, GLint y){
 glVertexAttribI2i (index, x, y);

}

void TglVertexAttribI3i (GLuint index, GLint x, GLint y, GLint z){
 glVertexAttribI3i (index, x, y, z);

}

void TglVertexAttribI4i (GLuint index, GLint x, GLint y, GLint z, GLint w){
 glVertexAttribI4i (index, x, y, z, w);

}

void TglVertexAttribI1ui (GLuint index, GLuint x){
 glVertexAttribI1ui (index, x);

}

void TglVertexAttribI2ui (GLuint index, GLuint x, GLuint y){
 glVertexAttribI2ui (index, x, y);

}

void TglVertexAttribI3ui (GLuint index, GLuint x, GLuint y, GLuint z){
 glVertexAttribI3ui (index, x, y, z);

}

void TglVertexAttribI4ui (GLuint index, GLuint x, GLuint y, GLuint z, GLuint w){
 glVertexAttribI4ui (index, x, y, z, w);

}

void TglVertexAttribI1iv (GLuint index, const GLint *v){
 glVertexAttribI1iv (index, v);

}

void TglVertexAttribI2iv (GLuint index, const GLint *v){
 glVertexAttribI2iv (index, v);

}

void TglVertexAttribI3iv (GLuint index, const GLint *v){
 glVertexAttribI3iv (index, v);

}

void TglVertexAttribI4iv (GLuint index, const GLint *v){
 glVertexAttribI4iv (index, v);

}

void TglVertexAttribI1uiv (GLuint index, const GLuint *v){
 glVertexAttribI1uiv (index, v);

}

void TglVertexAttribI2uiv (GLuint index, const GLuint *v){
 glVertexAttribI2uiv (index, v);

}

void TglVertexAttribI3uiv (GLuint index, const GLuint *v){
 glVertexAttribI3uiv (index, v);

}

void TglVertexAttribI4uiv (GLuint index, const GLuint *v){
 glVertexAttribI4uiv (index, v);

}

void TglVertexAttribI4bv (GLuint index, const GLbyte *v){
 glVertexAttribI4bv (index, v);

}

void TglVertexAttribI4sv (GLuint index, const GLshort *v){
 glVertexAttribI4sv (index, v);

}

void TglVertexAttribI4ubv (GLuint index, const GLubyte *v){
 glVertexAttribI4ubv (index, v);

}

void TglVertexAttribI4usv (GLuint index, const GLushort *v){
 glVertexAttribI4usv (index, v);

}

void TglGetUniformuiv (GLuint program, GLint location, GLuint *params){
 glGetUniformuiv (program, location, params);

}

void TglBindFragDataLocation (GLuint program, GLuint color, const GLchar *name){
 glBindFragDataLocation (program, color, name);

}

GLint TglGetFragDataLocation (GLuint program, const GLchar *name){
 return glGetFragDataLocation (program, name);

}

void TglUniform1ui (GLint location, GLuint v0){
 glUniform1ui (location, v0);

}

void TglUniform2ui (GLint location, GLuint v0, GLuint v1){
 glUniform2ui (location, v0, v1);

}

void TglUniform3ui (GLint location, GLuint v0, GLuint v1, GLuint v2){
 glUniform3ui (location, v0, v1, v2);

}

void TglUniform4ui (GLint location, GLuint v0, GLuint v1, GLuint v2, GLuint v3){
 glUniform4ui (location, v0, v1, v2, v3);

}

void TglUniform1uiv (GLint location, GLsizei count, const GLuint *value){
 glUniform1uiv (location, count, value);

}

void TglUniform2uiv (GLint location, GLsizei count, const GLuint *value){
 glUniform2uiv (location, count, value);

}

void TglUniform3uiv (GLint location, GLsizei count, const GLuint *value){
 glUniform3uiv (location, count, value);

}

void TglUniform4uiv (GLint location, GLsizei count, const GLuint *value){
 glUniform4uiv (location, count, value);

}

void TglTexParameterIiv (GLenum target, GLenum pname, const GLint *params){
 glTexParameterIiv (target, pname, params);

}

void TglTexParameterIuiv (GLenum target, GLenum pname, const GLuint *params){
 glTexParameterIuiv (target, pname, params);

}

void TglGetTexParameterIiv (GLenum target, GLenum pname, GLint *params){
 glGetTexParameterIiv (target, pname, params);

}

void TglGetTexParameterIuiv (GLenum target, GLenum pname, GLuint *params){
 glGetTexParameterIuiv (target, pname, params);

}

void TglClearBufferiv (GLenum buffer, GLint drawbuffer, const GLint *value){
 glClearBufferiv (buffer, drawbuffer, value);

}

void TglClearBufferuiv (GLenum buffer, GLint drawbuffer, const GLuint *value){
 glClearBufferuiv (buffer, drawbuffer, value);

}

void TglClearBufferfv (GLenum buffer, GLint drawbuffer, const GLfloat *value){
 glClearBufferfv (buffer, drawbuffer, value);

}

void TglClearBufferfi (GLenum buffer, GLint drawbuffer, GLfloat depth, GLint stencil){
 glClearBufferfi (buffer, drawbuffer, depth, stencil);

}

const GLubyte *TglGetStringi (GLenum name, GLuint index){
 return glGetStringi (name, index);

}

GLboolean TglIsRenderbuffer (GLuint renderbuffer){
 return glIsRenderbuffer (renderbuffer);

}

void TglBindRenderbuffer (GLenum target, GLuint renderbuffer){
 glBindRenderbuffer (target, renderbuffer);

}

void TglDeleteRenderbuffers (GLsizei n, const GLuint *renderbuffers){
 glDeleteRenderbuffers (n, renderbuffers);

}

void TglGenRenderbuffers (GLsizei n, GLuint *renderbuffers){
 glGenRenderbuffers (n, renderbuffers);

}

void TglRenderbufferStorage (GLenum target, GLenum internalformat, GLsizei width, GLsizei height){
 glRenderbufferStorage (target, internalformat, width, height);

}

void TglGetRenderbufferParameteriv (GLenum target, GLenum pname, GLint *params){
 glGetRenderbufferParameteriv (target, pname, params);

}

GLboolean TglIsFramebuffer (GLuint framebuffer){
 return glIsFramebuffer (framebuffer);

}

void TglBindFramebuffer (GLenum target, GLuint framebuffer){
 glBindFramebuffer (target, framebuffer);

}

void TglDeleteFramebuffers (GLsizei n, const GLuint *framebuffers){
 glDeleteFramebuffers (n, framebuffers);

}

void TglGenFramebuffers (GLsizei n, GLuint *framebuffers){
 glGenFramebuffers (n, framebuffers);

}

GLenum TglCheckFramebufferStatus (GLenum target){
 return glCheckFramebufferStatus (target);

}

void TglFramebufferTexture1D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level){
 glFramebufferTexture1D (target, attachment, textarget, texture, level);

}

void TglFramebufferTexture2D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level){
 glFramebufferTexture2D (target, attachment, textarget, texture, level);

}

void TglFramebufferTexture3D (GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level, GLint zoffset){
 glFramebufferTexture3D (target, attachment, textarget, texture, level, zoffset);

}

void TglFramebufferRenderbuffer (GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer){
 glFramebufferRenderbuffer (target, attachment, renderbuffertarget, renderbuffer);

}

void TglGetFramebufferAttachmentParameteriv (GLenum target, GLenum attachment, GLenum pname, GLint *params){
 glGetFramebufferAttachmentParameteriv (target, attachment, pname, params);

}

void TglGenerateMipmap (GLenum target){
 glGenerateMipmap (target);

}

void TglBlitFramebuffer (GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter){
 glBlitFramebuffer (srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);

}

void TglRenderbufferStorageMultisample (GLenum target, GLsizei samples, GLenum internalformat, GLsizei width, GLsizei height){
 glRenderbufferStorageMultisample (target, samples, internalformat, width, height);

}

void TglFramebufferTextureLayer (GLenum target, GLenum attachment, GLuint texture, GLint level, GLint layer){
 glFramebufferTextureLayer (target, attachment, texture, level, layer);

}

void *TglMapBufferRange (GLenum target, GLintptr offset, GLsizeiptr length, GLbitfield access){
 return glMapBufferRange (target, offset, length, access);

}

void TglFlushMappedBufferRange (GLenum target, GLintptr offset, GLsizeiptr length){
 glFlushMappedBufferRange (target, offset, length);

}

void TglBindVertexArray (GLuint array){
 glBindVertexArray (array);

}

void TglDeleteVertexArrays (GLsizei n, const GLuint *arrays){
 glDeleteVertexArrays (n, arrays);

}

void TglGenVertexArrays (GLsizei n, GLuint *arrays){
 glGenVertexArrays (n, arrays);

}

GLboolean TglIsVertexArray (GLuint array){
 return glIsVertexArray (array);

}






                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            