// OpenGL 2.0 >> 3.0

#include "to.h"
#include "toext.h"
#include <GLES3/gl32.h>


TGLuint TglCreateShader( TGLenum type )
{
 return glCreateShader( type );     // Calling into GLES functions.
}									 // In addition, for most functions, 
// the constants used by GL and GLES (such as GL_VERSION) are mostly the same,
// (the constants represent the same value) 
// so we can pass the parameters of the GL API directly to the GLES API.




// GL_VERSION_1_0
void CullFace (TGLenum mode);
void FrontFace (TGLenum mode);
void Hint (TGLenum target, TGLenum mode);
void LineWidth (TGLfloat width);
void PointSize (TGLfloat size);
void PolygonMode (TGLenum face, TGLenum mode);
void Scissor (TGLint x, TGLint y, TGLsizei width, TGLsizei height);
void TexParameterf (TGLenum target, TGLenum pname, TGLfloat param);
void TexParameterfv (TGLenum target, TGLenum pname, const TGLfloat *params);
void TexParameteri (TGLenum target, TGLenum pname, TGLint param);
void TexParameteriv (TGLenum target, TGLenum pname, const TGLint *params);
void TexImage1D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLint border, TGLenum format, TGLenum type, const void *pixels);
void TexImage2D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLsizei height, TGLint border, TGLenum format, TGLenum type, const void *pixels);
void DrawBuffer (TGLenum buf);
void Clear (TGLbitfield mask);
void ClearColor (TGLfloat red, TGLfloat green, TGLfloat blue, TGLfloat alpha);
void ClearStencil (TGLint s);
void ClearDepth (TGLdouble depth);
void StencilMask (TGLuint mask);
void ColorMask (TGLboolean red, TGLboolean green, TGLboolean blue, TGLboolean alpha);
void DepthMask (TGLboolean flag);
void Disable (TGLenum cap);
void Enable (TGLenum cap);
void Finish (void);
void Flush (void);
void BlendFunc (TGLenum sfactor, TGLenum dfactor);
void LogicOp (TGLenum opcode);
void StencilFunc (TGLenum func, TGLint ref, TGLuint mask);
void StencilOp (TGLenum fail, TGLenum zfail, TGLenum zpass);
void DepthFunc (TGLenum func);
void PixelStoref (TGLenum pname, TGLfloat param);
void PixelStorei (TGLenum pname, TGLint param);
void ReadBuffer (TGLenum src);
void ReadPixels (TGLint x, TGLint y, TGLsizei width, TGLsizei height, TGLenum format, TGLenum type, void *pixels);
void GetBooleanv (TGLenum pname, TGLboolean *data);
void GetDoublev (TGLenum pname, TGLdouble *data);
TGLenum GetError (void);
void GetFloatv (TGLenum pname, TGLfloat *data);
void GetIntegerv (TGLenum pname, TGLint *data);
const TGLubyte *GetString (TGLenum name);
void GetTexImage (TGLenum target, TGLint level, TGLenum format, TGLenum type, void *pixels);
void GetTexParameterfv (TGLenum target, TGLenum pname, TGLfloat *params);
void GetTexParameteriv (TGLenum target, TGLenum pname, TGLint *params);
void GetTexLevelParameterfv (TGLenum target, TGLint level, TGLenum pname, TGLfloat *params);
void GetTexLevelParameteriv (TGLenum target, TGLint level, TGLenum pname, TGLint *params);
TGLboolean IsEnabled (TGLenum cap);
void DepthRange (TGLdouble n, TGLdouble f);
void Viewport (TGLint x, TGLint y, TGLsizei width, TGLsizei height);


// GL_VERSION_1_1
void DrawArrays (TGLenum mode, TGLint first, TGLsizei count);
void DrawElements (TGLenum mode, TGLsizei count, TGLenum type, const void *indices);
void GetPointerv (TGLenum pname, void **params);
void PolygonOffset (TGLfloat factor, TGLfloat units);
void CopyTexImage1D (TGLenum target, TGLint level, TGLenum internalformat, TGLint x, TGLint y, TGLsizei width, TGLint border);
void CopyTexImage2D (TGLenum target, TGLint level, TGLenum internalformat, TGLint x, TGLint y, TGLsizei width, TGLsizei height, TGLint border);
void CopyTexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLint x, TGLint y, TGLsizei width);
void CopyTexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint x, TGLint y, TGLsizei width, TGLsizei height);
void TexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLsizei width, TGLenum format, TGLenum type, const void *pixels);
void TexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLsizei width, TGLsizei height, TGLenum format, TGLenum type, const void *pixels);
void BindTexture (TGLenum target, TGLuint texture);
void DeleteTextures (TGLsizei n, const TGLuint *textures);
void GenTextures (TGLsizei n, TGLuint *textures);
TGLboolean IsTexture (TGLuint texture);


// GL_VERSION_1_2
void DrawRangeElements (TGLenum mode, TGLuint start, TGLuint end, TGLsizei count, TGLenum type, const void *indices);
void TexImage3D (TGLenum target, TGLint level, TGLint internalformat, TGLsizei width, TGLsizei height, TGLsizei depth, TGLint border, TGLenum format, TGLenum type, const void *pixels);
void TexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLsizei width, TGLsizei height, TGLsizei depth, TGLenum format, TGLenum type, const void *pixels);
void CopyTexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLint x, TGLint y, TGLsizei width, TGLsizei height);


// GL_VERSION_1_3
void ActiveTexture (TGLenum texture);
void SampleCoverage (TGLfloat value, TGLboolean invert);
void CompressedTexImage3D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLsizei height, TGLsizei depth, TGLint border, TGLsizei imageSize, const void *data);
void CompressedTexImage2D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLsizei height, TGLint border, TGLsizei imageSize, const void *data);
void CompressedTexImage1D (TGLenum target, TGLint level, TGLenum internalformat, TGLsizei width, TGLint border, TGLsizei imageSize, const void *data);
void CompressedTexSubImage3D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLint zoffset, TGLsizei width, TGLsizei height, TGLsizei depth, TGLenum format, TGLsizei imageSize, const void *data);
void CompressedTexSubImage2D (TGLenum target, TGLint level, TGLint xoffset, TGLint yoffset, TGLsizei width, TGLsizei height, TGLenum format, TGLsizei imageSize, const void *data);
void CompressedTexSubImage1D (TGLenum target, TGLint level, TGLint xoffset, TGLsizei width, TGLenum format, TGLsizei imageSize, const void *data);
void GetCompressedTexImage (TGLenum target, TGLint level, void *img);


// GL_VERSION_1_4
void BlendFuncSeparate (TGLenum sfactorRGB, TGLenum dfactorRGB, TGLenum sfactorAlpha, TGLenum dfactorAlpha);
void MultiDrawArrays (TGLenum mode, const TGLint *first, const TGLsizei *count, TGLsizei drawcount);
void MultiDrawElements (TGLenum mode, const TGLsizei *count, TGLenum type, const void *const*indices, TGLsizei drawcount);
void PointParameterf (TGLenum pname, TGLfloat param);
void PointParameterfv (TGLenum pname, const TGLfloat *params);
void PointParameteri (TGLenum pname, TGLint param);
void PointParameteriv (TGLenum pname, const TGLint *params);
void BlendColor (TGLfloat red, TGLfloat green, TGLfloat blue, TGLfloat alpha);
void BlendEquation (TGLenum mode);


// GL_VERSION_1_5
void GenQueries (TGLsizei n, TGLuint *ids);
void DeleteQueries (TGLsizei n, const TGLuint *ids);
TGLboolean IsQuery (TGLuint id);
void BeginQuery (TGLenum target, TGLuint id);
void EndQuery (TGLenum target);
void GetQueryiv (TGLenum target, TGLenum pname, TGLint *params);
void GetQueryObjectiv (TGLuint id, TGLenum pname, TGLint *params);
void GetQueryObjectuiv (TGLuint id, TGLenum pname, TGLuint *params);
void BindBuffer (TGLenum target, TGLuint buffer);
void DeleteBuffers (TGLsizei n, const TGLuint *buffers);
void GenBuffers (TGLsizei n, TGLuint *buffers);
TGLboolean IsBuffer (TGLuint buffer);
void BufferData (TGLenum target, TGLsizeiptr size, const void *data, TGLenum usage);
void BufferSubData (TGLenum target, TGLintptr offset, TGLsizeiptr size, const void *data);
void GetBufferSubData (TGLenum target, TGLintptr offset, TGLsizeiptr size, void *data);
void *MapBuffer (TGLenum target, TGLenum access);
TGLboolean UnmapBuffer (TGLenum target);
void GetBufferParameteriv (TGLenum target, TGLenum pname, TGLint *params);
void GetBufferPointerv (TGLenum target, TGLenum pname, void **params);


// GL_VERSION_2_0
void BlendEquationSeparate (TGLenum modeRGB, TGLenum modeAlpha);
void DrawBuffers (TGLsizei n, const TGLenum *bufs);
void StencilOpSeparate (TGLenum face, TGLenum sfail, TGLenum dpfail, TGLenum dppass);
void StencilFuncSeparate (TGLenum face, TGLenum func, TGLint ref, TGLuint mask);
void StencilMaskSeparate (TGLenum face, TGLuint mask);
void AttachShader (TGLuint program, TGLuint shader);
void BindAttribLocation (TGLuint program, TGLuint index, const TGLchar *name);
void CompileShader (TGLuint shader);
TGLuint CreateProgram (void);
TGLuint CreateShader (TGLenum type);
void DeleteProgram (TGLuint program);
void DeleteShader (TGLuint shader);
void DetachShader (TGLuint program, TGLuint shader);
void DisableVertexAttribArray (TGLuint index);
void EnableVertexAttribArray (TGLuint index);
void GetActiveAttrib (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLint *size, TGLenum *type, TGLchar *name);
void GetActiveUniform (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLint *size, TGLenum *type, TGLchar *name);
void GetAttachedShaders (TGLuint program, TGLsizei maxCount, TGLsizei *count, TGLuint *shaders);
TGLint GetAttribLocation (TGLuint program, const TGLchar *name);
void GetProgramiv (TGLuint program, TGLenum pname, TGLint *params);
void GetProgramInfoLog (TGLuint program, TGLsizei bufSize, TGLsizei *length, TGLchar *infoLog);
void GetShaderiv (TGLuint shader, TGLenum pname, TGLint *params);
void GetShaderInfoLog (TGLuint shader, TGLsizei bufSize, TGLsizei *length, TGLchar *infoLog);
void GetShaderSource (TGLuint shader, TGLsizei bufSize, TGLsizei *length, TGLchar *source);
TGLint GetUniformLocation (TGLuint program, const TGLchar *name);
void GetUniformfv (TGLuint program, TGLint location, TGLfloat *params);
void GetUniformiv (TGLuint program, TGLint location, TGLint *params);
void GetVertexAttribdv (TGLuint index, TGLenum pname, TGLdouble *params);
void GetVertexAttribfv (TGLuint index, TGLenum pname, TGLfloat *params);
void GetVertexAttribiv (TGLuint index, TGLenum pname, TGLint *params);
void GetVertexAttribPointerv (TGLuint index, TGLenum pname, void **pointer);
TGLboolean IsProgram (TGLuint program);
TGLboolean IsShader (TGLuint shader);
void LinkProgram (TGLuint program);
void ShaderSource (TGLuint shader, TGLsizei count, const TGLchar *const*string, const TGLint *length);
void UseProgram (TGLuint program);
void Uniform1f (TGLint location, TGLfloat v0);
void Uniform2f (TGLint location, TGLfloat v0, TGLfloat v1);
void Uniform3f (TGLint location, TGLfloat v0, TGLfloat v1, TGLfloat v2);
void Uniform4f (TGLint location, TGLfloat v0, TGLfloat v1, TGLfloat v2, TGLfloat v3);
void Uniform1i (TGLint location, TGLint v0);
void Uniform2i (TGLint location, TGLint v0, TGLint v1);
void Uniform3i (TGLint location, TGLint v0, TGLint v1, TGLint v2);
void Uniform4i (TGLint location, TGLint v0, TGLint v1, TGLint v2, TGLint v3);
void Uniform1fv (TGLint location, TGLsizei count, const TGLfloat *value);
void Uniform2fv (TGLint location, TGLsizei count, const TGLfloat *value);
void Uniform3fv (TGLint location, TGLsizei count, const TGLfloat *value);
void Uniform4fv (TGLint location, TGLsizei count, const TGLfloat *value);
void Uniform1iv (TGLint location, TGLsizei count, const TGLint *value);
void Uniform2iv (TGLint location, TGLsizei count, const TGLint *value);
void Uniform3iv (TGLint location, TGLsizei count, const TGLint *value);
void Uniform4iv (TGLint location, TGLsizei count, const TGLint *value);
void UniformMatrix2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void ValidateProgram (TGLuint program);
void VertexAttrib1d (TGLuint index, TGLdouble x);
void VertexAttrib1dv (TGLuint index, const TGLdouble *v);
void VertexAttrib1f (TGLuint index, TGLfloat x);
void VertexAttrib1fv (TGLuint index, const TGLfloat *v);
void VertexAttrib1s (TGLuint index, TGLshort x);
void VertexAttrib1sv (TGLuint index, const TGLshort *v);
void VertexAttrib2d (TGLuint index, TGLdouble x, TGLdouble y);
void VertexAttrib2dv (TGLuint index, const TGLdouble *v);
void VertexAttrib2f (TGLuint index, TGLfloat x, TGLfloat y);
void VertexAttrib2fv (TGLuint index, const TGLfloat *v);
void VertexAttrib2s (TGLuint index, TGLshort x, TGLshort y);
void VertexAttrib2sv (TGLuint index, const TGLshort *v);
void VertexAttrib3d (TGLuint index, TGLdouble x, TGLdouble y, TGLdouble z);
void VertexAttrib3dv (TGLuint index, const TGLdouble *v);
void VertexAttrib3f (TGLuint index, TGLfloat x, TGLfloat y, TGLfloat z);
void VertexAttrib3fv (TGLuint index, const TGLfloat *v);
void VertexAttrib3s (TGLuint index, TGLshort x, TGLshort y, TGLshort z);
void VertexAttrib3sv (TGLuint index, const TGLshort *v);
void VertexAttrib4Nbv (TGLuint index, const TGLbyte *v);
void VertexAttrib4Niv (TGLuint index, const TGLint *v);
void VertexAttrib4Nsv (TGLuint index, const TGLshort *v);
void VertexAttrib4Nub (TGLuint index, TGLubyte x, TGLubyte y, TGLubyte z, TGLubyte w);
void VertexAttrib4Nubv (TGLuint index, const TGLubyte *v);
void VertexAttrib4Nuiv (TGLuint index, const TGLuint *v);
void VertexAttrib4Nusv (TGLuint index, const TGLushort *v);
void VertexAttrib4bv (TGLuint index, const TGLbyte *v);
void VertexAttrib4d (TGLuint index, TGLdouble x, TGLdouble y, TGLdouble z, TGLdouble w);
void VertexAttrib4dv (TGLuint index, const TGLdouble *v);
void VertexAttrib4f (TGLuint index, TGLfloat x, TGLfloat y, TGLfloat z, TGLfloat w);
void VertexAttrib4fv (TGLuint index, const TGLfloat *v);
void VertexAttrib4iv (TGLuint index, const TGLint *v);
void VertexAttrib4s (TGLuint index, TGLshort x, TGLshort y, TGLshort z, TGLshort w);
void VertexAttrib4sv (TGLuint index, const TGLshort *v);
void VertexAttrib4ubv (TGLuint index, const TGLubyte *v);
void VertexAttrib4uiv (TGLuint index, const TGLuint *v);
void VertexAttrib4usv (TGLuint index, const TGLushort *v);
void VertexAttribPointer (TGLuint index, TGLint size, TGLenum type, TGLboolean normalized, TGLsizei stride, const void *pointer);


// GL_VERSION_2_1
void UniformMatrix2x3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix3x2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix2x4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix4x2fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix3x4fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);
void UniformMatrix4x3fv (TGLint location, TGLsizei count, TGLboolean transpose, const TGLfloat *value);


// GL_VERSION_3_0
void ColorMaski (TGLuint index, TGLboolean r, TGLboolean g, TGLboolean b, TGLboolean a);
void GetBooleani_v (TGLenum target, TGLuint index, TGLboolean *data);
void GetIntegeri_v (TGLenum target, TGLuint index, TGLint *data);
void Enablei (TGLenum target, TGLuint index);
void Disablei (TGLenum target, TGLuint index);
TGLboolean IsEnabledi (TGLenum target, TGLuint index);
void BeginTransformFeedback (TGLenum primitiveMode);
void EndTransformFeedback (void);
void BindBufferRange (TGLenum target, TGLuint index, TGLuint buffer, TGLintptr offset, TGLsizeiptr size);
void BindBufferBase (TGLenum target, TGLuint index, TGLuint buffer);
void TransformFeedbackVaryings (TGLuint program, TGLsizei count, const TGLchar *const*varyings, TGLenum bufferMode);
void GetTransformFeedbackVarying (TGLuint program, TGLuint index, TGLsizei bufSize, TGLsizei *length, TGLsizei *size, TGLenum *type, TGLchar *name);
void ClampColor (TGLenum target, TGLenum clamp);
void BeginConditionalRender (TGLuint id, TGLenum mode);
void EndConditionalRender (void);
void VertexAttribIPointer (TGLuint index, TGLint size, TGLenum type, TGLsizei stride, const void *pointer);
void GetVertexAttribIiv (TGLuint index, TGLenum pname, TGLint *params);
void GetVertexAttribIuiv (TGLuint index, TGLenum pname, TGLuint *params);
void VertexAttribI1i (TGLuint index, TGLint x);
void VertexAttribI2i (TGLuint index, TGLint x, TGLint y);
void VertexAttribI3i (TGLuint index, TGLint x, TGLint y, TGLint z);
void VertexAttribI4i (TGLuint index, TGLint x, TGLint y, TGLint z, TGLint w);
void VertexAttribI1ui (TGLuint index, TGLuint x);
void VertexAttribI2ui (TGLuint index, TGLuint x, TGLuint y);
void VertexAttribI3ui (TGLuint index, TGLuint x, TGLuint y, TGLuint z);
void VertexAttribI4ui (TGLuint index, TGLuint x, TGLuint y, TGLuint z, TGLuint w);
void VertexAttribI1iv (TGLuint index, const TGLint *v);
void VertexAttribI2iv (TGLuint index, const TGLint *v);
void VertexAttribI3iv (TGLuint index, const TGLint *v);
void VertexAttribI4iv (TGLuint index, const TGLint *v);
void VertexAttribI1uiv (TGLuint index, const TGLuint *v);
void VertexAttribI2uiv (TGLuint index, const TGLuint *v);
void VertexAttribI3uiv (TGLuint index, const TGLuint *v);
void VertexAttribI4uiv (TGLuint index, const TGLuint *v);
void VertexAttribI4bv (TGLuint index, const TGLbyte *v);
void VertexAttribI4sv (TGLuint index, const TGLshort *v);
void VertexAttribI4ubv (TGLuint index, const TGLubyte *v);
void VertexAttribI4usv (TGLuint index, const TGLushort *v);
void GetUniformuiv (TGLuint program, TGLint location, TGLuint *params);
void BindFragDataLocation (TGLuint program, TGLuint color, const TGLchar *name);
TGLint GetFragDataLocation (TGLuint program, const TGLchar *name);
void Uniform1ui (TGLint location, TGLuint v0);
void Uniform2ui (TGLint location, TGLuint v0, TGLuint v1);
void Uniform3ui (TGLint location, TGLuint v0, TGLuint v1, TGLuint v2);
void Uniform4ui (TGLint location, TGLuint v0, TGLuint v1, TGLuint v2, TGLuint v3);
void Uniform1uiv (TGLint location, TGLsizei count, const TGLuint *value);
void Uniform2uiv (TGLint location, TGLsizei count, const TGLuint *value);
void Uniform3uiv (TGLint location, TGLsizei count, const TGLuint *value);
void Uniform4uiv (TGLint location, TGLsizei count, const TGLuint *value);
void TexParameterIiv (TGLenum target, TGLenum pname, const TGLint *params);
void TexParameterIuiv (TGLenum target, TGLenum pname, const TGLuint *params);
void GetTexParameterIiv (TGLenum target, TGLenum pname, TGLint *params);
void GetTexParameterIuiv (TGLenum target, TGLenum pname, TGLuint *params);
void ClearBufferiv (TGLenum buffer, TGLint drawbuffer, const TGLint *value);
void ClearBufferuiv (TGLenum buffer, TGLint drawbuffer, const TGLuint *value);
void ClearBufferfv (TGLenum buffer, TGLint drawbuffer, const TGLfloat *value);
void ClearBufferfi (TGLenum buffer, TGLint drawbuffer, TGLfloat depth, TGLint stencil);
const TGLubyte *GetStringi (TGLenum name, TGLuint index);
TGLboolean IsRenderbuffer (TGLuint renderbuffer);
void BindRenderbuffer (TGLenum target, TGLuint renderbuffer);
void DeleteRenderbuffers (TGLsizei n, const TGLuint *renderbuffers);
void GenRenderbuffers (TGLsizei n, TGLuint *renderbuffers);
void RenderbufferStorage (TGLenum target, TGLenum internalformat, TGLsizei width, TGLsizei height);
void GetRenderbufferParameteriv (TGLenum target, TGLenum pname, TGLint *params);
TGLboolean IsFramebuffer (TGLuint framebuffer);
void BindFramebuffer (TGLenum target, TGLuint framebuffer);
void DeleteFramebuffers (TGLsizei n, const TGLuint *framebuffers);
void GenFramebuffers (TGLsizei n, TGLuint *framebuffers);
TGLenum CheckFramebufferStatus (TGLenum target);
void FramebufferTexture1D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level);
void FramebufferTexture2D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level);
void FramebufferTexture3D (TGLenum target, TGLenum attachment, TGLenum textarget, TGLuint texture, TGLint level, TGLint zoffset);
void FramebufferRenderbuffer (TGLenum target, TGLenum attachment, TGLenum renderbuffertarget, TGLuint renderbuffer);
void GetFramebufferAttachmentParameteriv (TGLenum target, TGLenum attachment, TGLenum pname, TGLint *params);
void GenerateMipmap (TGLenum target);
void BlitFramebuffer (TGLint srcX0, TGLint srcY0, TGLint srcX1, TGLint srcY1, TGLint dstX0, TGLint dstY0, TGLint dstX1, TGLint dstY1, TGLbitfield mask, TGLenum filter);
void RenderbufferStorageMultisample (TGLenum target, TGLsizei samples, TGLenum internalformat, TGLsizei width, TGLsizei height);
void FramebufferTextureLayer (TGLenum target, TGLenum attachment, TGLuint texture, TGLint level, TGLint layer);
void *MapBufferRange (TGLenum target, TGLintptr offset, TGLsizeiptr length, TGLbitfield access);
void FlushMappedBufferRange (TGLenum target, TGLintptr offset, TGLsizeiptr length);
void BindVertexArray (TGLuint array);
void DeleteVertexArrays (TGLsizei n, const TGLuint *arrays);
void GenVertexArrays (TGLsizei n, TGLuint *arrays);
TGLboolean IsVertexArray (TGLuint array);





