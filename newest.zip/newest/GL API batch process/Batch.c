// This is where the GL APIs will be batched.

#include <stdio.h>
#include <stdlib.h>


int Get_length( char * );
void modify_M( char * , int );


int main(void){
 
 
 //  Reading the file.
 //  Here, A represents the text to be processed, 
 //  and B represents the text that has been processed.
 
 char * ptrA;
 int countA;
 FILE * fpA;
 size_t resultA;
 
 fpA = fopen ( "pack.c", "rb" );
 if (fpA == NULL)
 {
  fputs ("File error", stderr);
  exit (1);
 }
 
 fseek (fpA, 0, SEEK_END);
 countA = ftell (fpA);		// Getting the number of file bytes.
 rewind (fpA);
 
 ptrA = (char*) malloc (sizeof(char)*countA);	// Allocate A memory block.
 if (ptrA == NULL)
 {
  fputs ("Memory error", stderr); 
  exit (2);
 }
 
 resultA = fread (ptrA, 1, countA, fpA);		// Read the file to the A memory block.
 if (resultA != countA)
 {
  fputs ("Reading error", stderr);
  exit (3);
 }
 
 printf("%s \n %d \n", ptrA, countA);	// Print the text in the A memory block and the size.
 
 fclose (fpA);
 
 
 
 int countB = countA * 2 + 286 * 4;  // Size of the output file.
 
 // Each function will be copied once, so "countA*2" ;
 // the 286 functions will add 4 newline characters, so "+ 286*4" .
 
 
 
 
 char * ptrB;
 
 ptrB = (char *)malloc( countB * sizeof(char) );
 
 
 char * ptr_A;
 char * ptr_B;
 ptr_A = ptrA;		// Copy the original pointer to the A and B memory block.
 ptr_B = ptrB;
 
 
 // Start using loop processing. 
 // Process a function statement in a loop iteration.
 // The result of each processing is written to B memory block in real time.
 
 
 int x = 0;
 
 int i = 0;		// The length of a function statement.
 
 char * ptrM;	// Pointer to a small memory block.
 
 while( x < countA ){
  
  if(x > 0){
   while( !( *(ptrA-1) == '\n' && ( *ptrA == 'v' || *ptrA == 'G' ) ) ){		// Check whether the string at the current position is "void".
   
   // while( *(ptrA-1) != '\n' || ( *ptrA != 'v' && *ptrA != 'G' ) ){
    
    if( x >= countA )
     break;
    
    *ptrB = *ptrA;		// Because we need to process the GL functions that start with "void".
    ptrA++;			// So what we don't process is written directly to the B memory block.
    ptrB++;
    
    x++;
   }
  }
  
  if( *ptrA == 'v' || *ptrA == 'G' ){		// Begin formal processing.
   
   						// " void glCompileShader( GLuint shader );\n "
   						// will be :
   						// " void glCompileShader( GLuint shader );\nVoid gNCompileShader( gLuint shader )<\n\n}\n\n "
   						
   						// Next, use the file manager for batch processing.
   						// ";"  →  "{"
   						// "Void" → " void"
   						// "gN"  → "Tgl"
   						// "gLuint" → " "
   						// "<"  →  ";"
   						
   						
   i = Get_length( ptrA );			// Get the length of the string for the current pending function.
   
   char min_block[300]; 		// A small memory block, 
   									// It will be used to cache the string of the function to be processed.
   ptrM = min_block;
   
   memmove( ptrB, ptrA, i );	// Copy the original function string to B and M.
   
   memmove( ptrM, ptrA, i );
   
   ptrB += i;		// Update the B pointer.
   					// Because we're going to write the M string to the new location in B.
   
   modify_M( ptrM, i );		// Modify the string of the function.
   
   memmove( ptrB, ptrM, i + 4 );	// Copy the processed function string from M to B.
   
   
   ptrB += i + 4;		// Update A and B pointers to point to the next pending function.
   
   ptrA += i;
   
   
  }
  else{
   *ptrB = *ptrA;
   
   ptrA++;
   ptrB++;
   x++;
  }
  
  
 
 }
 
 
 
 
 FILE * fpB;
 size_t resultB;
 
 fpB = fopen ( "pack_.c", "wb" );
 if (fpB == NULL)
 {
  fputs ("File error", stderr);
  exit (4);
 }
 
 
 resultB = fwrite (ptr_B, 1, countB, fpB);		// Write the file from the B memory block.
 if (resultB != countB)
 {
  fputs ("Writing error", stderr);
  exit (5);
 }
 
 printf("%s \n %d \n", ptr_B, countB);	// Print the text in the B memory block and the size.
 
 fclose (fpB);
 
 
 
 free(ptr_A);
 free(ptr_B);
 
 return 0;
 
}
 
 
 
int Get_length( char * ptr ){
 
 int length = 0;
 
 while( *ptr != '\n' ){
  
  length++;
  ptr++;
 }
 
 return length + 1;		// The reason for "length + 1" is that we want the length to contain a '\n' .
 
}
 



void modify_M( char * ptrm, int len ){
 
 *ptrm = 'V';
 *(ptrm + len - 2) = '<';
 
 int t = 0;
 
 while( t < len ){
  
  if( *(ptrm + t) == 'g' ){
   
   *(ptrm + t + 1) = 'N';		// "gl" >> "gN"
   
   break;
  }
 
 t++;
 
 }
 
 							   // ↓     ↓			      ↓			    ↓ ↓↓↓↓
 *(ptrm + len) = '\n';			// Void gNCompileShader( gLuint shader )<\n\n}\n\n
 *(ptrm + len + 1) = '}';
 *(ptrm + len + 2) = '\n';
 *(ptrm + len + 3) = '\n';
 
 int z = 0;
 
 while( z < len ){
  
  if( *(ptrm + z) == 'G' && *(ptrm + z + 1) == 'L' )
   
   *(ptrm + z) = 'g';		// "GL" >> "gL"
  
  if( *(ptrm + z) == 'c' && *(ptrm + z + 1) == 'o' && *(ptrm + z + 2) == 'n' )
   
   *(ptrm + z) = 'C';		// "const" >> "Const"
  
  if( z > 4 ){
   
   if( *(ptrm + z) == 'v' && *(ptrm + z + 1) == 'o' )
    
    *(ptrm + z) = 'W';		// "void" >> "Woid"
  
  }
 
 z++;
 
 }
 
 return;
 
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 











