#ifndef _GL4ES_PLANES_H_
#define _GL4ES_PLANES_H_

#include "gles.h"

void gl4es_glClipPlanef(GLenum plane, const GLfloat *equation);

#endif // _GL4ES_PLANES_H_
