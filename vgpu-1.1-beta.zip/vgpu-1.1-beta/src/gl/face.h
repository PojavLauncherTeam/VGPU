#ifndef _GL4ES_FACE_H_
#define _GL4ES_FACE_H_

#include "gles.h"

void gl4es_glCullFace(GLenum mode);
void gl4es_glFrontFace(GLenum mode);

#endif // _GL4ES_FACE_H_
