#ifndef _GL4ES_BUILD_INFO_H_
#define _GL4ES_BUILD_INFO_H_

void print_build_infos();

#endif // _GL4ES_BUILD_INFO_H_
