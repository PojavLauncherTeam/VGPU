
#include <stdio.h>

int main(void)
{
 
 int a(int,int);
 
 printf("        %d     /n", a(2,1));
 
 return 0;
 
}










































