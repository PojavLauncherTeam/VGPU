

int a(m,n)
{
 return m+n;
}