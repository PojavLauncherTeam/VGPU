



extern void func_name_conv(char *, char **);