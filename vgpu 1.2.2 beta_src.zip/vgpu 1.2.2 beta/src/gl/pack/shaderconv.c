
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "shaderconv.h"
#include "shader.h"


#include <android/log.h>

#define Printf(...) __android_log_print(ANDROID_LOG_INFO, "LIBGL", __VA_ARGS__)


void func_name_conv(char *A, char **source){
	int pot = 0;
	int count = 0;
	int lenA = strlen(A);
	int lenS = strlen(*source);
	char ** ptrM = (char **)malloc( ((int)(lenS/lenA*0.3)+1)*sizeof(char *) );
	pot = find(A, A, source, ptrM, &count);
	
	char * conv = (char *)malloc(sizeof(char)*lenA+1);
	conv[lenA] = '\0';
	for(int x=0; x<lenA; x++){
		conv[x] = '#';
	}
	
	char * A_ = (char *)malloc(sizeof(char)*lenA+3);
	A_[lenA+2]='\0';
	A_[lenA+1]='_';
	A_[lenA]='_';				// Add '_' at the end of the variable name to avoid duplicate names, and you can add more.
	memmove(A_, A, lenA);
	
	int lenN;			// The length from ptrm to the end of source.
	char * ptrm;
	int isfunc = 0;
	for(int n=0; n<count; n++){
		ptrm = ptrM[n];
		ptrm += lenA;
		lenN = lenS - (ptrm - *source);
		for(int m=0; m<lenN; m++){
			if(ptrm[m]=='('){
				isfunc = 1;
				break;
    		}
			if(ptrm[m]==',' || ptrm[m]==';' || ptrm[m]=='=' || ptrm[m]=='\n'){
				isfunc = 0;
				break;
			}
			if(ptrm[m]=='+' || ptrm[m]=='-' || ptrm[m]=='*' || ptrm[m]=='/'){
				isfunc = 0;
				break;
			}
    	}
    	if(isfunc==0){
    		memmove(ptrM[n], conv, lenA);				// If it is not a function name, replace it with "####...".
    	}
    }
    pot = replace(conv, A_, source);					// "func_name" >> "func_name_"
    free(ptrM);
    free(conv);
    free(A_);
    return;
}


