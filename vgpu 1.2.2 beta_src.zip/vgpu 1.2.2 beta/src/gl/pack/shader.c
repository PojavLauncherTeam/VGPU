// Some extra functions

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// shader
//char * shaderconv(int, char **, char **, char *, int *, int *, int);
//int find(char *, char *, char **, char **, int *);
//int replace(char *, char *, char **);

#include "shader.h"

int Annotation_Detection(char *ptr, char *start_ptr, int mode){
	int len = ptr - start_ptr;
	for(int n=0; *(ptr-n) != '\n' && n<=len; n++){			// detect "//"
		if(*(ptr-n)=='/' && *(ptr-n-1)=='/'){
			return 1;
		}
	}
	if(mode==1){
		char *ptrm = ptr;
    	for(int m=0; m<=len; m++){				// detect "/*"
    		int lenblock = 0;
    		if(*(ptrm-1)=='*' && *ptrm=='/'){				// If found "*/", try to match "/*".
    			lenblock = Skip_Block(&ptrm, start_ptr);
    			if(lenblock){
    				m += lenblock;
    				continue;
    			}else{				// If a complete comment block cannot be found, 0 is returned.
    				return 0;
    			}
    		}
    		if(*(ptrm-1)=='/' && *ptrm=='*'){
    			return 1;
    		}
    		ptrm--;
    	}
	}
	return 0;
}


int Skip_Block(char **ptr, char *start_ptr){
	int len = *ptr - start_ptr;
	int pot = 0;
	int lenblock = 0;
	char *ptrm = *ptr;
	
	len -= 2;					// Skip "*/" to start loop.
	ptrm -= 2;
	lenblock = 2;
	for(int m=0; m<=len; m++){
		if(*(ptrm-1)=='*' && *ptrm=='/'){
			pot = Skip_Block(&ptrm, start_ptr);
			lenblock += pot;
			m += pot;
		}
		if(*(ptrm+1)=='/' && *(ptrm+2)=='*'){
			*ptr = ptrm;							// update *ptr, current location.
			return lenblock;
		}
		lenblock++;
		ptrm++;
	}
	return 0;
}
	




#define replace_N(n, N)  \
				pot = snprintf(c, 5, "%d", n); \
				if((ptr[m])[N]==c[0]){ \
    				pot = snprintf(str, 20, "gl_FragData[%d]", N); \
    				pot = replace(str, "FragData" #n "", converted); \
    				pot = replace_common("0 es", "0 es \nlayout(location = " #n ") out mediump vec4 FragData" #n "; ", converted, 1); \
    			}

int drawbuffer_fix(char *source, char **converted){
	int pot=0, count=0, len=0;
	char * ptr[20] = {NULL};
	pot = find("/* DRAWBUFFERS:", "/* DRAWBUFFERS:", &source, ptr, &count);
	for(int n=0; n<count; n++){
		if(Annotation_Detection(ptr[n], source, 0)){
			ptr[n] = NULL;						// If the string has been commented out, it is not processed.
		}
	}
	int ptr_num = 0;
	for(int x=0; x<count; x++){
		if(ptr[x] != NULL){
			ptr_num++;
		}
	}
	if(ptr_num){
    	len = strlen("/* DRAWBUFFERS:");
    	char str[20] = {' '};
    	char c[5] = {' '};
    	for(int m=0; m<count; m++){
    		if(ptr[m]==NULL){
    			continue;
    		}
    		ptr[m] += len;
    		if(*(ptr[m]) == ' '){
    			ptr[m]++;
    		}
    		for(int N=0; (ptr[m])[N] != ' ' && N<8; N++){
    			/*if((ptr[m])[N]=='0'){
    				pot = snprintf(str, 20, "gl_FragData[%d]", N);
    				pot = replace(str, "FragData0", source);
    				pot = replace_common("0 es", "0 es \nlayout(location = 0) out mediump vec4 FragData0; \n", source, 1);
    			}
    			*/
    			replace_N(0, N)
    			replace_N(1, N)
    			replace_N(2, N)
    			replace_N(3, N)
    			replace_N(4, N)
    			replace_N(5, N)
    			replace_N(6, N)
    			replace_N(7, N)									// The color buffer specified by the shader is processed by vgpu.
    		}
    	}
    	pot = replace("/* DRAWBUFFERS:", "/*", converted);				// Delete the shader declaration statement.
		return 1;
	}else{
		return 0;
	}
}





char * shaderconv(int number, char **A, char **B, char *string, int *length1, int *length, int count){
 
 char **ptrA;
 char *ptrA_;
 ptrA = &ptrA_;
 
 int islength1 = 0;
 if(length1 == NULL){
  length1 = (int *)malloc(count*sizeof(int));			// Create a temporary length1.
  islength1 = 1;
 }
 
 if(count == 1){	// In the case of a single shader source.
  
  if(length == NULL){
   *ptrA = (char *)malloc( (strlen(string)+1)*sizeof(char) );
   memmove(*ptrA, string, strlen(string));		// Copy the original shader source code to A memory block.
   (*ptrA)[strlen(string)] = '\0';
  }
  else{
   *ptrA = (char *)malloc( (*length+1)*sizeof(char) );
   memmove(*ptrA, string, *length);
   (*ptrA)[*length] = '\0';
  }
  
  
  for(int x = 0; x < number; x++){		// Replace one item by another.
   
   *length1 = replace(A[x], B[x], ptrA);	// Passes in the pointer to the string to be searched for, to be replaced, and the pointer to the original shader source code, and returns the length of the processed shader source code.
   										// Inside the function, the memory block pointed to by * ptrA is searched and modified.
   										// The result is then written to a new B memory block (created as A), and then free (* ptrA).
   										// Finally, the pointer to the B memory block is assigned to A * ptrA = ptrB.
   										// In this way, the next round of processing can access the results of the previous round.
  }
 }
 if(count > 1 && length != NULL){
  
  char *ptrA1;
  int all_len = 0;
  int all = 0;
  
  for(int i = 0; i < count; i++){		// For a number of different shader source code one by one.
   
   *ptrA = (char *)malloc( (length[i]+1)*sizeof(char) );
   memmove(*ptrA, string, length[i]);
   (*ptrA)[length[i]] = '\0';
   
   all_len += length[i];
   
   for(int x = 0; x < number; x++){		// Search item by item.
    int length1_ = 0;
    int count_ = 0;
    char * ptrM_[ (int)(strlen(*ptrA)/strlen(A[x]))+1 ];
    
    length1_ = find(A[x], B[x], ptrA, ptrM_, &count_);
    
    if(count_ != 0){
     length1[i] = length1_;
     all_len += length1_ - length[i];	// All _ len is updated each time with the difference (the length returned by the search-the original length).
    }
   }
   
   string += length[i];		// Update the source pointer to copy the correct source block to ptrA.
   all += length[i];
  }
  string -= all;
  all = 0;
  
  ptrA1 = (char *)malloc( (all_len+1)*sizeof(char) );		// Create the final output block.
  free(*ptrA);
  
  
  
  for(int i = 0; i < count; i++){		// For a number of different shader source code one by one.
   
   *ptrA = (char *)malloc( (length[i]+1)*sizeof(char) );
   memmove(*ptrA, string, length[i]);
   (*ptrA)[length[i]] = '\0';
   
   for(int x = 0; x < number; x++){		// Replace one item by another.
   
    length1[i] = replace(A[x], B[x], ptrA);
    
    
    
    
   }
   
   string += length[i];		// Update the source pointer to copy the correct source block to ptrA.
   all += length[i];
   
   memmove(ptrA1, *ptrA, length1[i]);	// Copy each processed shader source block to the total block.
   ptrA1 += length1[i];			// Update ptrA1.
  }
  string -= all;
  all = 0;
  
  free(*ptrA);
  ptrA1 -= all_len;
  *ptrA = ptrA1;
  (*ptrA)[all_len] = '\0';
 }
 
 if(islength1 == 1){		// Release the temporarily created length1.
  free(length1);
 }

 return *ptrA;		// Returns a pointer to the completed memory block.

}



int find(char *A, char *B, char **ptrA, char **ptr_M, int *count1){
  
 char **ptrM;
 int isptrM1 = 0;
 if(ptr_M != NULL){
  ptrM = ptr_M;
 }
 else{
  char ** ptrM1 = (char **)malloc( ((int)(strlen(*ptrA)/strlen(A))+1)*sizeof(char*) );
  ptrM = ptrM1;
  isptrM1 = 1;
 }
 
 int count = 0;
 char *ptr = NULL;
 int lenA, lenB, differ;
 lenA = strlen(A);
 lenB = strlen(B);
 differ = lenB - lenA;
 
 ptr = strstr(*ptrA, A);		// Gets the initial pointer.
 while(ptr != NULL){
  ptrM[count] = ptr;		// Assign the searched pointer to an array of external pointers.
  count++;
  for(int x = 0; x < lenA; x++){
   ptr[x] = '$';
  }
  ptr = strstr(*ptrA, A);
 }
 
 for(int i = 0; i < count; i++){
  memmove(ptrM[i], A, lenA);		// Replace the string back to the original.
 }
 
 if(count1 != NULL){
  *count1 = count;
 }
 
 if(isptrM1 == 1){
  free(ptrM);
 }
 
 return (int)strlen(*ptrA) + differ * count;		// Returns the modified length.
 
}



int replace(char *A, char *B, char **ptrA){
 
 int count = 0;
 char ** ptrM = (char **)malloc( ((int)(strlen(*ptrA)/strlen(A))+1)*sizeof(char*) );
 //char * ptrM[ (int)(strlen(*ptrA)/strlen(A))+1 ];
 int lenA, lenB, len_ptrA, len_ptrB;
 lenA = strlen(A);
 lenB = strlen(B);
 len_ptrA = strlen(*ptrA); 
 len_ptrB = find(A, B, ptrA, ptrM, &count);		// Obtain the length of the output block and the number of searched strings to be modified.
 
 if(count != 0){
  char *ptrB = (char *)malloc(len_ptrB + 1);
  ptrB[len_ptrB] = '\0';
  
  char *pA = *ptrA;
  char *pB = ptrB;			// Create an action pointer.
  int M_A;			// The difference between the pointer to the current ptrM array and the current pA.
  
  for(int x = 0; x < count; x++){
   
   M_A = ptrM[x] - pA;
   if(M_A > 0){
    memmove(pB, pA, M_A);		// Copy the previous block to ptrB.
    pA += M_A;
    pB += M_A;
   }
   memmove(pB, B, lenB);		// Copy B to ptrB.
   pA += lenA;
   pB += lenB;
  
  }
  if( (*ptrA+len_ptrA-1-pA) > 0 ){
   memmove(pB, pA, *ptrA+len_ptrA-pA);		// Copy the end block to ptrB.
  }
  
  free(ptrM);
  free(*ptrA);
  *ptrA = ptrB;
  return len_ptrB;
 
 }
 else{
  free(ptrM);
  return len_ptrB;		// Returns the modified length.
 }

}




int replace_common(char *A, char *B, char **ptrA, int number){
 
 int count = 0;
 char ** ptrM = (char **)malloc( ((int)(strlen(*ptrA)/strlen(A))+1)*sizeof(char*) );
 //char * ptrM[ (int)(strlen(*ptrA)/strlen(A))+1 ];
 int lenA, lenB, len_ptrA, len_ptrB;
 lenA = strlen(A);
 lenB = strlen(B);
 len_ptrA = strlen(*ptrA); 
 len_ptrB = find(A, B, ptrA, ptrM, &count);		// Obtain the length of the output block and the number of searched strings to be modified.
 
 if(count != 0){
  char *ptrB = (char *)malloc(len_ptrB + 1);
  ptrB[len_ptrB] = '\0';
  
  char *pA = *ptrA;
  char *pB = ptrB;			// Create an action pointer.
  int M_A;			// The difference between the pointer to the current ptrM array and the current pA.
  
  if(number > -1){
      for(int x = 0; x < count && x < number; x++){
       
       M_A = ptrM[x] - pA;
       if(M_A > 0){
        memmove(pB, pA, M_A);		// Copy the previous block to ptrB.
        pA += M_A;
        pB += M_A;
       }
       memmove(pB, B, lenB);		// Copy B to ptrB.
       pA += lenA;
       pB += lenB;
      
      }
      if( (*ptrA+len_ptrA-1-pA) > 0 ){
       memmove(pB, pA, *ptrA+len_ptrA-pA);		// Copy the end block to ptrB.
      }
      
      free(ptrM);
      free(*ptrA);
      *ptrA = ptrB;
      return len_ptrB;
  }
  else{
  	  for(int x = 0; x < count && x < number; x++){
       
       M_A = ptrM[x] - pA;
       if(M_A > 0){
        memmove(pB, pA, M_A);		// Copy the previous block to ptrB.
        pA += M_A;
        pB += M_A;
       }
       memmove(pB, B, lenB);		// Copy B to ptrB.
       pA += lenA;
       pB += lenB;
      
      }
      if( (*ptrA+len_ptrA-1-pA) > 0 ){
       memmove(pB, pA, *ptrA+len_ptrA-pA);		// Copy the end block to ptrB.
      }
      
      free(ptrM);
      free(*ptrA);
      *ptrA = ptrB;
      return len_ptrB;
  }
 
 }
 else{
  free(ptrM);
  return len_ptrB;		// Returns the modified length.
 }

}