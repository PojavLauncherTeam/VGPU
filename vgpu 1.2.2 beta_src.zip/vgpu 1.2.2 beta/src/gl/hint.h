#ifndef _GL4ES_HINT_H_
#define _GL4ES_HINT_H_

#include "gles.h"

void gl4es_glHint(GLenum pname, GLenum mode);

#endif // _GL4ES_HINT_H_
