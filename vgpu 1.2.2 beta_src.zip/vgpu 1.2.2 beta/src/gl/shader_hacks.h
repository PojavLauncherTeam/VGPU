#ifndef __SHADER_HACKS_H__
#define __SHADER_HACKS_H__

char* ShaderHacks(char* shader);

#endif //__SHADER_HACKS_H__