#ifndef _GL4ES_VERSION_H
#define _GL4ES_VERSION_H

#define MAJOR 1
#define MINOR 1
#define REVISION 4

#endif //_GL4ES_VERSION_H
